# Design decisions & tradeoffs

Context: built autonomously as a generic chat + voice layer over **any AgentsFS
directory** (a sibling to AgentsFS), with `agentic-stocks/agentsfs` as the first
tenant. Stack and voice approach were chosen by the user up front: **TypeScript
service** and **Realtime + Claude hand-off**. The notes below record what was
adjusted to fit the actual environment, and why.

## Reasoner: OpenAI now, Claude-ready

- The stated preference was Claude as the reasoner. The `.env` available has an
  **OpenAI key but no Anthropic or Gemini key**, so the working implementation
  uses OpenAI. The reasoner is behind a provider-agnostic `Reasoner` interface
  (`src/reasoner/types.ts`); adding `src/reasoner/anthropic.ts` and one line in
  `src/reasoner/index.ts` switches the brain to Claude with no other changes.
  Provider auto-selects from whichever key is present (Anthropic preferred).
- **Responses API, not Chat Completions.** Research against current OpenAI docs
  confirmed that from GPT‑5.4, tool calling is not supported on Chat Completions
  with `reasoning: none`; the Responses API is the recommended agentic surface
  and preserves reasoning state across tool rounds. The SDK was upgraded v4→v6.
- **Model-family-aware params.** gpt‑5.x / o‑series reject `temperature`; they
  take `reasoning.effort` + `text.verbosity`. Standard models (gpt‑4.1) take
  `temperature`. `src/reasoner/openai.ts` builds params per family so calls never
  400, and replays streamed output items after stripping the SDK-only
  `parsed_arguments` field (which the API rejects on replay).

## Retrieval: agentic over the `afs` toolkit, not RAG

- AgentsFS already ships a Go CLI (`afs`) with ranked full-text search, a tree
  map, backlinks, and an optional embedding index. The agent uses these plus
  path-jailed file read/grep — it searches, reads, and cites like a person would.
  This matches AgentsFS's own design and means **the layer improves as AgentsFS
  gains capabilities**, with no separate index to maintain.
- **Semantic is automatic when present.** `searchSmart` tries semantic and falls
  back to full-text if the instance has no embedding index/provider, caching the
  result so it doesn't retry a failing call. The agentic-stocks instance has a
  full-text index only today; running `afs reindex --embeddings` there (with the
  OpenAI key) would light up semantic with zero code changes.

## Voice: OpenAI Realtime + consult_knowledge hand-off

- OpenAI Realtime (`gpt-realtime`) over WebRTC is the spoken front-end (the only
  realtime-capable key available; Gemini Live would need a Google key/ADC). The
  real key never reaches the browser: the server mints a short-lived ephemeral
  client secret bound to the session config.
- The voice model is kept lean: for anything substantive it calls
  `consult_knowledge`, which runs the **same grounded agent** over the wiki and
  returns a concise cited answer to speak — this is the "Realtime + hand-off"
  design, and it's the seam where Claude slots in later.
- `semantic_vad` by default (more natural turn-taking) with barge-in; switch to
  `server_vad` via `REALTIME_VAD=server` for lower latency.
- **Default voice model is `gpt-realtime-mini`** (~2-3x cheaper than `gpt-realtime`,
  same full-duplex feel). A June-2026 provider survey put `gpt-realtime` at the
  most-expensive end (~$0.50-0.80/min realistic); cheaper paths exist — Gemini
  2.5 Flash Native Audio (~10x, needs a Google key) or an STT→LLM→TTS pipeline
  (~15-25x, turn-based) — but mini is the no-new-vendor win on the existing
  OpenAI key. Per-turn **token + estimated-cost logging** (server console + UI)
  was added so the bigger architectural call can be made from real numbers; the
  price table lives in `src/pricing.ts`. Measured: a chat turn ≈ 5.7k in / ~100
  out tokens ≈ ~$0.015 (most of it the system prompt's instance tree map).

## Latency vs quality

- Default `CHAT_MODEL=gpt-5.1` with `reasoning.effort=low` and `verbosity=low`:
  current-gen reasoning, but dialed for snappy interactive chat. Bump effort for
  harder analysis; `gpt-4.1` is the fast fallback.
- The **final answer streams** token-by-token (SSE) for low perceived latency;
  tool rounds are capped (8 chat / 5 voice) and the last allowed round forces a
  final answer (`tool_choice: "none"`) so a turn always resolves.
- The system prompt embeds a **depth-2 tree map** so the model orients without a
  round-trip, and uses tools to go deeper.

## Instance switching (the picker)

The served AgentsFS instance is hot-swappable at runtime (`GET /api/instances`
discovers them under `AGENTSFS_SEARCH_DIR`; `POST /api/instance` switches). A
browser file input can't select a *server-side* directory, so the UI lists
server-discovered instances plus a manual path field. Switching rebuilds the
agent + tool registry for the new root and re-detects capabilities; the LLM
reasoner is reused (it isn't instance-specific). The validation that a target is
a real agentsfs (`.agentsfs/` or AGENTS.md marker) is also the security gate —
you can't point the file tools at an arbitrary directory like `/etc`.

## Security

- **Path jail**: every file path is resolved against the instance root and must
  stay inside it (`safeResolve`); traversal throws. Verified by tests and a live
  probe (`../../../../etc/passwd` → rejected).
- **No secret leakage**: the OpenAI key is only used server-side (chat,
  tool-relay, and minting the ephemeral voice token). The browser only ever holds
  the short-lived `ek_…` token.
- **No shell injection**: `afs` and `rg` are invoked via `execFile` with arg
  arrays (no shell).
- No auth by design — this is a local single-user tool. Add auth before exposing
  it on a network.
- `npm audit` reports findings only in the **dev-only** `vitest`/`vite`/`esbuild`
  chain (the esbuild dev-server advisory), which this app never runs. The runtime
  dependencies (`openai`, `yaml`, `zod`, `dotenv`, node stdlib) are clean. Left as
  is to avoid a breaking `vitest@3` upgrade; clear with `npm audit fix --force`
  if desired.

## Verification

A 5-dimension adversarial code review (correctness, security, AgentsFS-fidelity,
robustness, latency/quality) was run after the first working build; it produced
20 verified findings, all addressed. Highlights fixed: a broken model-fallback
path that leaked reasoning params (would 400 on the default gpt-5.1→gpt-4.1
fallback — now verified working), interim pre-tool prose leaking into the final
answer (now discarded via a `reset` event), sticky process-wide fallback (now
per-turn), abort handling that spawned extra work (now rethrows), and a
symlink-based path-jail escape (now realpath-checked).

Done and passing:
- 49 automated tests (parsers, path jail incl. symlink escape, web logic,
  capabilities, tools, the agent loop with a mock reasoner, and full server
  integration incl. SSE, malformed-body, and graceful tool errors).
- `npm run typecheck` clean.
- Live end-to-end (`npm run smoke`): health, config, a real streamed chat turn
  with tool calls + citations, the tool relay, and a real Realtime token mint.
- Live agent quality check: a DDOG/SNOW thesis question returned a correct,
  fully-cited answer with invalidation criteria.

Needs a human (browser + microphone), so verified manually:
- The actual spoken voice round-trip (WebRTC audio in/out). All of its server-
  side pieces — token mint, tool relay, `consult_knowledge` agent — are covered
  by tests and the smoke check; the browser glue (`app.js`) follows the verified
  OpenAI Realtime WebRTC flow, and its pure logic is unit-tested.

## Possible follow-ups

- Add `src/reasoner/anthropic.ts` to run the reasoner/hand-off on Claude.
- Build the embedding index on the stocks instance to enable semantic search.
- Persist conversations / multi-session history (currently in-memory per page).
- Portfolio personalization once `stocks/portfolio/` is populated.
- Auth + rate limiting if deployed beyond localhost.
