# Design decisions & tradeoffs

Context: built autonomously as a generic chat + voice layer over **any AgentsFS
directory** (a sibling to AgentsFS), with `agentic-stocks/agentsfs` as the first
tenant. Stack and voice approach were chosen by the user up front: **TypeScript
service** and **Realtime + Claude hand-off**. The notes below record what was
adjusted to fit the actual environment, and why.

This same code now also runs **inside each hosted user agent sprite** (one
hardware-isolated Firecracker VM per user, provisioned by the Hub), in a
write-capable **workspace mode** with a `run_bash` shell — see the workspace,
`run_bash`, and secret-handling sections below. It still runs locally over a
single KB exactly as before.

## Reasoner: OpenAI now, Claude-ready

- The stated preference was Claude as the reasoner. The `.env` available has an
  **OpenAI key but no Anthropic or Gemini key**, so the working implementation
  uses OpenAI. The reasoner is behind a provider-agnostic `Reasoner` interface
  (`src/reasoner/types.ts`); adding `src/reasoner/anthropic.ts` and one line in
  `src/reasoner/index.ts` switches the brain to Claude with no other changes.
  Provider auto-selects from whichever key is present (Anthropic preferred).
- **Responses API, not Chat Completions.** Research against current OpenAI docs
  confirmed that from GPT‑5.4, tool calling is not supported on Chat Completions
  with `reasoning: none`; the Responses API is the recommended agentic surface
  and preserves reasoning state across tool rounds. The SDK was upgraded v4→v6.
- **Model-family-aware params.** gpt‑5.x / o‑series reject `temperature`; they
  take `reasoning.effort` + `text.verbosity`. Standard models (gpt‑4.1) take
  `temperature`. `src/reasoner/openai.ts` builds params per family so calls never
  400, and replays streamed output items after stripping the SDK-only
  `parsed_arguments` field (which the API rejects on replay).

## Retrieval: agentic over the `afs` toolkit, not RAG

- AgentsFS already ships a Go CLI (`afs`) with ranked full-text search, a tree
  map, backlinks, and an optional embedding index. The agent uses these plus
  path-jailed file read/grep — it searches, reads, and cites like a person would.
  This matches AgentsFS's own design and means **the layer improves as AgentsFS
  gains capabilities**, with no separate index to maintain.
- **Semantic is automatic when present.** `searchSmart` tries semantic and falls
  back to full-text if the instance has no embedding index/provider, caching the
  result so it doesn't retry a failing call. The agentic-stocks instance has a
  full-text index only today; running `afs reindex --embeddings` there (with the
  OpenAI key) would light up semantic with zero code changes.

## Voice: OpenAI Realtime + consult_knowledge hand-off

- OpenAI Realtime (`gpt-realtime`) over WebRTC is the spoken front-end (the only
  realtime-capable key available; Gemini Live would need a Google key/ADC). The
  real key never reaches the browser: the server mints a short-lived ephemeral
  client secret bound to the session config.
- The voice model is kept lean: for anything substantive it calls
  `consult_knowledge`, which runs the **same grounded agent** over the wiki and
  returns a concise cited answer to speak — this is the "Realtime + hand-off"
  design, and it's the seam where Claude slots in later.
- `semantic_vad` by default (more natural turn-taking) with barge-in; switch to
  `server_vad` via `REALTIME_VAD=server` for lower latency.
- **Default voice model is `gpt-realtime-mini`** (~2-3x cheaper than `gpt-realtime`,
  same full-duplex feel). A June-2026 provider survey put `gpt-realtime` at the
  most-expensive end (~$0.50-0.80/min realistic); cheaper paths exist — Gemini
  2.5 Flash Native Audio (~10x, needs a Google key) or an STT→LLM→TTS pipeline
  (~15-25x, turn-based) — but mini is the no-new-vendor win on the existing
  OpenAI key. Per-turn **token + estimated-cost logging** (server console + UI)
  was added so the bigger architectural call can be made from real numbers; the
  price table lives in `src/pricing.ts`. Measured: a chat turn ≈ 5.7k in / ~100
  out tokens ≈ ~$0.015 (most of it the system prompt's instance tree map).

## Latency vs quality

- Default `CHAT_MODEL=gpt-5.1` with `reasoning.effort=low` and `verbosity=low`:
  current-gen reasoning, but dialed for snappy interactive chat. Bump effort for
  harder analysis; `gpt-4.1` is the fast fallback.
- The **final answer streams** token-by-token (SSE) for low perceived latency;
  tool rounds are capped and the last allowed round forces a final answer
  (`tool_choice: "none"`) so a turn always resolves. The cap is
  **8 chat / 5 voice, raised to 24 when the shell is on** (`maxToolIterations`
  in `src/agent/session.ts`): a coding-agent build (npm install, build, run,
  iterate) burns tool rounds fast, and a 8-round ceiling would truncate a long
  build mid-way. Read-only chat stays at 8 so a normal answer can't loop.
- The system prompt embeds a **depth-2 tree map** so the model orients without a
  round-trip, and uses tools to go deeper.

## Instance switching (the picker)

The served AgentsFS instance is hot-swappable at runtime (`GET /api/instances`
discovers them under `AGENTSFS_SEARCH_DIR`; `POST /api/instance` switches). A
browser file input can't select a *server-side* directory, so the UI lists
server-discovered instances plus a manual path field. Switching rebuilds the
agent + tool registry for the new root and re-detects capabilities; the LLM
reasoner is reused (it isn't instance-specific). The validation that a target is
a real agentsfs (`.agentsfs/` or AGENTS.md marker) is also the security gate —
you can't point the file tools at an arbitrary directory like `/etc`.

## Workspace mode + the (per-sprite) instance switch

- The same server now runs in two modes (`AGENTSFS_MODE`, `src/config.ts`).
  **single** is the local one-KB tool above. **workspace** is what the hosted
  per-user sprite runs: `AGENTSFS_ROOT` points at a workspace dir holding every
  one of the user's KBs as sibling checkouts, so the server always boots (the dir
  exists even with zero repos) and starts **unfocused** — it lists the KBs and
  asks which to work in. `list_repos` / `focus_repo` (`src/tools/registry.ts`,
  workspace-only) enumerate and switch the active KB.
- **The active root is a shared mutable box read live per tool call, and a focus
  takes effect IMMEDIATELY (same turn).** The generic tool handlers read
  `ctx.session.root` on every call (not a closure snapshot); `focus_repo` mutates
  that shared `session.root`, so the reads *after* it in the same turn hit the new
  KB. The Agent is **not** rebuilt on switch — it reads `session.root` live and
  only rebuilds its orientation prompt per active root (cached). Still global
  per-process (one user per hardware-isolated sprite, so no per-session state is
  needed), just no longer next-turn.
  - **Why this matters (2026-07-06 fix):** the first cut rebuilt the Agent and let
    the switch land on the *next* turn. That badly broke "switch to X and tell me
    about it" — the reads still hit the OLD repo, so citations mixed across KBs and
    the answer wasn't grounded in the requested KB; the UI also never showed which
    KB was active. Reproduced live on the deployed sprite + in the browser, then
    fixed to the live-per-call model. Also added: an SSE `instance` event so the
    topbar shows the active KB live, a load-time KB picker (workspace mode exposes
    `mode` + repos in `/api/config`), and `list_repos`/`focus_repo` in the voice
    tool set. Regression-guarded by a live eval (`npm run test:live`).
  - The repo-button entry (`hub.agentsfs.ai/agent/?repo=<slug>`) pre-focuses via
    `POST /api/focus`; the manual instance picker uses the same `setActiveRoot`.
- `resolveRepo` only accepts a KB actually discovered under the workspace (or a
  real agentsfs path) — the model can't focus an arbitrary path it invents, the
  same validation gate as the instance picker.

## The knowledge-base dropdown (direct switch, no reset)

- In addition to switching conversationally (the agent calls `focus_repo`), the
  workspace-mode topbar has a **KB dropdown** to pick the active knowledge base
  directly. It `POST`s `/api/focus`, which runs the same `onFocusRepo` →
  `setActiveRoot` path as the agent's tool and the `?repo=` button — one
  `setActiveRoot`, no special-casing per entry point.
- **A direct switch is *just* a focus — it does NOT reset the conversation.**
  `setActiveRoot` only mutates the shared `session.root` (and re-orients the
  prompt for the new root); it doesn't rebuild the Agent or clear history, so the
  open chat keeps going, now scoped to the new KB. The server emits the SSE
  `instance` event (`onInstanceChange` → `send("instance", …)`) so the topbar
  reflects the active KB live without a reload. In workspace mode the generic
  path-based "Instance" picker is hidden (a user shouldn't type server paths);
  with nothing focused on load, the UI shows a KB picker instead.

## `run_bash` behind its own `AGENTSFS_ALLOW_SHELL` flag

- The hosted agent can run arbitrary `/bin/sh -c` commands (`run_bash`,
  `src/agentsfs/shell.ts`) to drive `afs hub pull/list`, `git`, `rg`, `ls` across
  the workspace repos. Once the shell is on it **subsumes the per-repo git tools**:
  `git_pull` and `git_commit`/`git_push` are dropped (the agent just runs `git`);
  `git_status`/`git_diff` and `write_file`/`edit_file` are kept because they emit
  citations / clean diffs (`src/tools/registry.ts`).
- Arbitrary shell is gated on a **dedicated `AGENTSFS_ALLOW_SHELL`** flag (default
  off), **separate from `AGENTSFS_ALLOW_WRITES`**. Enabling file writes is a
  weaker grant than arbitrary code execution, so turning on writes must never
  silently also grant a shell — only the isolated per-user sprite sets
  `AGENTSFS_ALLOW_SHELL`. Both are opt-in; the local default stays read-only.

## Coding-agent mode (it builds software, not just notes)

- With the shell on, the capability grant in the prompt (`codingRules`,
  `src/agent/prompt.ts`) is explicit: `run_bash` (arbitrary shell incl. sudo),
  Node, git, ripgrep, and package managers (npm, apt) make this **a capable
  engineering agent** — asked to build/scaffold/install/run/analyze, it does the
  real work (install deps, `write_file`/`run_bash`, run and test, iterate) rather
  than describing it. This is why the tool-round cap jumps to 24 with the shell on
  (see *Latency vs quality*): builds are tool-round-heavy.
- **Preview = static file serving at `/preview/*`, deliberately NOT a live
  dev-server proxy (v1).** The agent drops its built *static* output into
  `cfg.previewDir` (env `AGENTSFS_PREVIEW_DIR`; the sprite provisioner sets
  `/home/sprite/workspace/.preview`), and the server serves that dir path-jailed
  at `/preview/*` (`servePreview`, `src/server/server.ts`): resolve-inside-base
  check, directories fall back to `index.html`, a small MIME map. For a framework
  app the agent builds first (`npm run build`) and copies the output there.
  - **Why static, not a proxy to a running dev server:** a static jail is a few
    lines with an obvious, auditable boundary (a path check on one dir); proxying
    a live dev server means picking/allocating a port, lifecycle-managing a
    long-running child, forwarding websockets/HMR, and a much larger surface to
    reason about for what v1 needs — "let the user see the thing you built." A
    built static site covers landing pages, dashboards, and most demos. Verified
    live: the agent built a coffee-shop landing page and it rendered at
    `/preview/`.
- **Scope note:** with arbitrary sudo bash and *no per-command approval gate*,
  this agent is arguably **less constrained than Claude Code**. That's acceptable
  only because of the containment below (per-user Firecracker isolation + no
  operator key on the box) — the blast radius is the user's own VM and data.

## `create_repo` — one-step new knowledge base

- `create_repo` (`src/tools/registry.ts`, workspace mode + `allowWrites`) makes a
  brand-new KB on request so "make me a knowledge base for X" is a single step:
  it slugifies the name, runs `afs init "<slug>" --yes` in the workspace dir,
  writes the one-line description into the new `AGENTS.md`, does a **best-effort**
  `git commit` + `afs hub push` to publish it, then `focus_repo`s into it so the
  agent can start adding notes in the same turn.
- **Publish and focus are both best-effort, never blocking the create.** If the
  hub push fails the KB still exists locally and the tool says to run `afs hub
  push` later; if the focus throws (it already exists) the create still succeeds.
  The point is that a failed *publish* shouldn't lose the user's new KB. Guarded:
  rejects an empty/invalid slug and a slug that already exists on disk.

## Secret handling in the hosted sprite

The threat: a (possibly prompt-injected) user agent with `run_bash` trying to
exfiltrate the operator's **shared OpenAI key**. The design makes that
impossible *architecturally*, not by hiding secrets on the box.

- **The sandbox boundary is Firecracker per-user isolation, not the shell gate.**
  Each user gets their **own** hardware-isolated Fly Sprite microVM
  (`afs-user-<user>`, one per user — see provisioning). `run_bash` is intentional
  and acceptable because its blast radius is that single user's own data + VM;
  there is no cross-tenant reach.
- **In-sprite key-hiding is futile, so we don't rely on it.** The sprite user has
  passwordless sudo to root, so `run_bash` could `sudo cat` any file or read any
  `/proc/<pid>/environ`. Therefore **the sprite holds no OpenAI key at all.**
- **Model calls are proxied through the hub (`proxy mode`).** When
  `AGENTSFS_LLM_BASE_URL` is set, the OpenAI SDK `baseURL` points at the hub's
  `/v1/agent-llm` and the `apiKey` is the sprite's own **per-user PAT**
  (`AGENTSFS_LLM_KEY`) — both the text Responses API (`src/reasoner/openai.ts`)
  and the voice ephemeral-token mint (`src/server/realtime.ts`) go this way, and
  `loadConfig` no longer requires an OpenAI key in proxy mode (`src/config.ts`).
  The hub's `handleAgentLLM` (`internal/hub/server.go`) authenticates the PAT,
  then reverse-proxies to `api.openai.com` **injecting the hub's real OpenAI
  key**, allowlisted to `responses` / `chat/completions` / `realtime/`. The
  shared key never leaves the hub — safe even multi-user.
- **The PAT is the only credential in the sprite, and that's fine.** It is
  same-user scope (authenticates only as its own owner) and is also what the
  sprite uses for `git push` and `afs hub pull`, so exposing it to the user's own
  agent grants nothing the user doesn't already have.
- **Defense-in-depth layers — explicitly NOT the boundary:** (a) `run_bash`'s
  child env is scrubbed to a small allow-list and drops anything `*_KEY` /
  `*_TOKEN` / `*SECRET*`, so `env`/`printenv` reveal nothing
  (`src/agentsfs/shell.ts`); (b) every tool result runs through a redactor that
  masks known secret values + shapes (`sk-`, `afs_`, Authorization headers)
  before the model/UI (`src/agentsfs/redact.ts`) — UI hygiene only, since any
  base64/hex/rev encoding defeats a substring match; (c) the reasoner keys are
  deleted from `process.env` after config load (`src/index.ts`) to close env
  inheritance / `/proc` reads. None of these is the security boundary — the real
  containment is the hub-proxy (no key on the box) + Firecracker isolation.

## Conversation history (persistent, server-side, gated)

- Chats now persist across page reloads and cold-wakes: `ConversationStore`
  (`src/server/conversations.ts`) writes **one JSON file per conversation** under
  `<dataDir>/conversations/` (env `AGENTSFS_DATA_DIR`; the sprite provisioner sets
  `/home/sprite/.agentsfs-chat`). `/api/chat` takes a `conversationId` and appends
  each user+assistant exchange, deriving the title from the first user message and
  remembering the focused KB. Endpoints: `GET`/`POST /api/conversations`,
  `GET`/`DELETE /api/conversations/:id`. `/api/config` exposes
  `persistConversations` (plus `mode` + workspace repos) so the UI knows whether
  to show the "Chats" drawer; the drawer lists past chats (title, time, msg count,
  KB) with delete, "New" starts a fresh one, and reopening a chat rehydrates its
  messages **and restores the KB it was in**.
- **Stored server-side, not in the browser — deliberate, because the sprite is
  persistent + single-user.** Each user has their own VM with a disk that survives
  cold-wakes, and one user per sprite means no cross-user leakage risk from a
  shared store — so the server is the natural home, and history then follows the
  user across their devices (a browser-local store wouldn't). The `id` is validated
  against `^[A-Za-z0-9-]{8,64}$` before it's used as a filename (no path
  traversal), and empty/unused conversations are skipped in the list.
- **Gated: unset `AGENTSFS_DATA_DIR` = in-memory only (the old behavior).** The
  store is constructed only when `cfg.dataDir` is set (`ctx.conversations =
  cfg.dataDir ? new ConversationStore(...) : undefined`); with it unset the append
  is a no-op, `/api/conversations` returns empty / `501`, and chat stays per-page
  in-memory exactly as before — the local single-KB tool doesn't grow a disk store
  it didn't ask for.

## Security

- **Path jail**: every file path is resolved against the active instance root and
  must stay inside it (`safeResolve`); traversal throws. In workspace mode the
  write tools are path-jailed to the *focused* repo. Verified by tests and a live
  probe (`../../../../etc/passwd` → rejected).
- **Secret handling**: see the section above. In proxy mode no OpenAI key lives
  in the sprite; the browser only ever holds the short-lived `ek_…` voice token.
- **No shell injection in the structured tools**: `afs`, `git`, and `rg` are
  invoked via `execFile` with arg arrays (no shell) so a path/message can't inject
  a command. `run_bash` is the deliberate exception — it *is* a shell — and is
  bounded by the sandbox model above, not by argv sanitization.
- **Auth / exposure**: the local single-KB use is a no-auth localhost tool. The
  hosted path is not exposed directly — the hub reverse-proxies the sprite at
  `/agent/*` (owner-only) injecting the Sprites bearer server-side, so the sprite
  stays private and the user never sees `sprites.dev`.
- `npm audit` reports findings only in the **dev-only** `vitest`/`vite`/`esbuild`
  chain (the esbuild dev-server advisory), which this app never runs. The runtime
  dependencies (`openai`, `yaml`, `zod`, `dotenv`, node stdlib) are clean. Left as
  is to avoid a breaking `vitest@3` upgrade; clear with `npm audit fix --force`
  if desired.

## Verification

A 5-dimension adversarial code review (correctness, security, AgentsFS-fidelity,
robustness, latency/quality) was run after the first working build; it produced
20 verified findings, all addressed. Highlights fixed: a broken model-fallback
path that leaked reasoning params (would 400 on the default gpt-5.1→gpt-4.1
fallback — now verified working), interim pre-tool prose leaking into the final
answer (now discarded via a `reset` event), sticky process-wide fallback (now
per-turn), abort handling that spawned extra work (now rethrows), and a
symlink-based path-jail escape (now realpath-checked).

Done and passing:
- Automated tests (parsers, path jail incl. symlink escape, web logic,
  capabilities, tools, the agent loop with a mock reasoner, and full server
  integration incl. SSE, malformed-body, and graceful tool errors).
- `npm run typecheck` clean.
- Live end-to-end (`npm run smoke`): health, config, a real streamed chat turn
  with tool calls + citations, the tool relay, and a real Realtime token mint.
- Live agent quality check: a DDOG/SNOW thesis question returned a correct,
  fully-cited answer with invalidation criteria.

Needs a human (browser + microphone), so verified manually:
- The actual spoken voice round-trip (WebRTC audio in/out). All of its server-
  side pieces — token mint, tool relay, `consult_knowledge` agent — are covered
  by tests and the smoke check; the browser glue (`app.js`) follows the verified
  OpenAI Realtime WebRTC flow, and its pure logic is unit-tested.

## Possible follow-ups

- Add `src/reasoner/anthropic.ts` to run the reasoner/hand-off on Claude.
- Build the embedding index on the stocks instance to enable semantic search.
- Portfolio personalization once `stocks/portfolio/` is populated.
- **Live dev-server preview** — v1 serves a built *static* site at `/preview/*`;
  a proxy to a running dev server (ports, child lifecycle, HMR/websockets) is the
  natural next step if demos need it.
- **Per-user rate/cost limits on the hub LLM proxy** — a valid PAT currently
  spends the hub's shared OpenAI quota with no cap.
- **Voice in the sprite**: the proxied ephemeral-token mint works in code but
  hasn't been exercised live inside a sprite yet.
