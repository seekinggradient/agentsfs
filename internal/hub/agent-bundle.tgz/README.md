# agentsfs-chat

A **chat + voice layer over any [AgentsFS](../agentsfs) directory.** Point it
at an AgentsFS instance and you get a streaming web chat and a live voice mode
that answer questions grounded in that knowledge base — with citations back to
the exact files and sources used.

It is a **sibling to AgentsFS**, not a fork of any one wiki. It reads the wiki
through the `afs` CLI and the AgentsFS conventions (frontmatter, `INDEX.md`,
`[[wikilinks]]`), so as an AgentsFS instance grows new structure, this layer
benefits automatically. The `agentic-stocks/agentsfs` wiki is its first tenant.

```
            any AgentsFS dir
                  │   (afs search/tree/backlinks + file read/grep)
        ┌─────────▼──────────┐
        │   shared engine    │   Claude/OpenAI agent loop + citation tracking
        │  (tools + reasoner)│
        └───┬────────────┬───┘
   text chat│            │voice (OpenAI Realtime, WebRTC)
     (SSE)  ▼            ▼  consult_knowledge → same agent
        browser UI    browser mic/speaker
```

## What it does

- **Chat** — streaming answers grounded only in the AgentsFS instance. Every
  answer shows citation chips; click a file chip to read the underlying markdown
  in a drawer, or a URL chip to open the source.
- **Voice** — a live, low-latency spoken conversation (OpenAI Realtime over
  WebRTC). The voice model delegates substantive questions to the same grounded
  agent via a `consult_knowledge` tool and speaks the cited answer; sources are
  pushed to the screen.
- **Capability-aware** — generic tools (`search_wiki`, `read_file`, `grep`,
  `list_dir`, `backlinks`, `tree`) work over any instance. Structured tools
  (`list_theses`, `get_thesis`) light up only when the instance exposes them
  (e.g. the stocks thesis table).

## Requirements

- Node ≥ 20 (developed on 23).
- The [`afs`](../agentsfs) CLI on `PATH` (the AgentsFS toolkit — used for
  search/tree/backlinks; the app degrades to plain file tools if it is missing).
- `ripgrep` (`rg`) on `PATH` (for the `grep` tool).
- An `OPENAI_API_KEY` (reasoner + voice). Set `ANTHROPIC_API_KEY` later to switch
  the reasoner to Claude once that implementation is added.

## Quick start

`.env` is already populated (copied from the agentic-stocks repo) and
dependencies are installed.

```bash
npm start                 # serve over AGENTSFS_ROOT, open http://localhost:8787
npm run chat "your question here"   # one-shot terminal chat
npm run chat              # interactive terminal REPL
npm run smoke             # live end-to-end check (hits OpenAI)
npm test                  # 46 unit + integration tests (offline, deterministic)
npm run typecheck
```

Point it at a different AgentsFS instance by changing `AGENTSFS_ROOT` in `.env`
(or `AGENTSFS_ROOT=/path/to/other/agentsfs npm start`).

## Configuration (`.env`)

| Variable | Default | Meaning |
|---|---|---|
| `AGENTSFS_ROOT` | — | Absolute path to the AgentsFS instance to serve. |
| `AGENTSFS_SEARCH_DIR` | parent of root | Workspace scanned to discover instances for the in-app picker. |
| `OPENAI_API_KEY` | — | Reasoner + voice + (afs) semantic embeddings. |
| `ANTHROPIC_API_KEY` | — | When set, selects the (future) Claude reasoner. |
| `CHAT_MODEL` | `gpt-5.1` | Chat agent model (Responses API). |
| `CHAT_MODEL_FALLBACK` | `gpt-4.1` | Used if the primary model errors. |
| `CHAT_REASONING_EFFORT` | `low` | `none\|low\|medium\|high\|xhigh` (gpt-5.x). |
| `CHAT_VERBOSITY` | `low` | `low\|medium\|high` (gpt-5.x). |
| `REALTIME_MODEL` | `gpt-realtime-mini` | Voice model (~2-3x cheaper than `gpt-realtime`, same live feel). |
| `REALTIME_VOICE` | `marin` | Voice id. |
| `REALTIME_VAD` | `semantic` | `semantic` (natural) or `server` (lower latency). |
| `PORT` | `8787` | HTTP port. |

## How retrieval works

The agent navigates the wiki **agentically** rather than via a prebuilt RAG
index — it searches, reads, follows links, and cites, the same way the AgentsFS
ingestion agents do. `afs search` provides ranked full-text out of the box;
**semantic search turns on automatically** when the instance has an embedding
index (`afs reindex --embeddings`), and otherwise transparently falls back to
full-text. See [DECISIONS.md](DECISIONS.md) for the rationale.

## Cost visibility

Token usage and an estimated cost print per turn:
- **Chat / voice consult** → server console, e.g. `[chat] gpt-5.1 • in 5753 / out 98 tok • ~$0.015 est`, and the chat UI shows a small `model · in+out tok · ~$ est` line under each answer.
- **Voice (realtime)** → the voice panel shows a running `session • audio … · text … · ~$ est` line (read from the realtime `response.usage`, priced client-side).

Cost figures use the editable table in [src/pricing.ts](../agentsfs-chat/src/pricing.ts) (and a matching `VOICE_PRICE` in the web client). Audio rates dominate voice; the gpt-5.x text rates are estimates — adjust to your plan. See [DECISIONS.md](DECISIONS.md) for the provider/cost comparison that informed defaulting to `gpt-realtime-mini`.

## Switching instances

Click **Instance ▾** to pick any AgentsFS directory discovered under
`AGENTSFS_SEARCH_DIR`, or paste an absolute path. The server validates the target
is a real agentsfs (has `.agentsfs/` or an AGENTS.md marker — this is also the
security gate), rebuilds the agent + tools for it, and hot-swaps without a
restart. Capability-gated tools re-detect per instance (e.g. the theses tools
appear only on a stocks wiki), and the conversation resets on switch.

## Voice

Click **Voice**. The browser mints a short-lived ephemeral token from the server
(your real API key never leaves the server), opens a WebRTC session to OpenAI
Realtime, and streams mic audio. When the model needs facts it calls
`consult_knowledge`, which the browser relays to `/api/tools/call`; the server
runs the full grounded agent and returns a concise cited answer for the model to
speak, while the citations render on screen.

> Voice requires a real browser with a microphone, so it is verified manually
> (the token-mint, tool-relay, and agent paths are covered by automated tests and
> the live smoke check). See [DECISIONS.md](DECISIONS.md#verification).

## HTTP API

| Endpoint | Purpose |
|---|---|
| `GET /api/health` | liveness + instance/model |
| `GET /api/config` | public UI config (capabilities, suggestions, voice settings) |
| `POST /api/chat` | SSE stream: `delta`, `tool`, `done`, `error` events |
| `POST /api/tools/call` | `{name,args}` → `{content,citations}` (voice relay + file drawer) |
| `POST /api/realtime/token` | mint an ephemeral Realtime client secret (optional `{history}` seeds voice with the text conversation) |
| `GET /api/instances` | discovered AgentsFS instances under the search dir + the active one |
| `POST /api/instance` | `{path}` → hot-swap the served instance (validated as a real agentsfs) |

## Project structure

```
src/
  config.ts            env + runtime config
  agentsfs/            afs CLI wrapper, path-jailed fs, frontmatter, capabilities
  tools/               tool registry + citation types + structured (theses) tools
  reasoner/            provider-agnostic Reasoner + OpenAI (Responses API) impl
  agent/               system-prompt builder + agent session (loop + citations)
  server/              node:http server (SSE chat, tool relay, realtime token)
  web/                 vanilla UI (app.js) + pure helpers (lib.js) + styles
  cli.ts, index.ts     terminal chat + server entry
scripts/               dev-check.ts (read-only probe), smoke.ts (live e2e)
test/                  46 tests + a mini-agentsfs fixture
```

## Adding a provider (Claude)

Implement `Reasoner` (see `src/reasoner/types.ts`) in `src/reasoner/anthropic.ts`
and wire it in `src/reasoner/index.ts`. Everything above the reasoner — tools,
citations, server, UI, voice hand-off — is unchanged. The voice loop can then
route `consult_knowledge` to Claude while OpenAI Realtime remains the spoken
front-end.
