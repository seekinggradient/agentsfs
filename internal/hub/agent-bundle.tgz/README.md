# agentsfs-chat

A **chat + voice layer over any [AgentsFS](../agentsfs) directory.** Point it
at an AgentsFS instance and you get a streaming web chat and a live voice mode
that answer questions grounded in that knowledge base — with citations back to
the exact files and sources used.

It is a **sibling to AgentsFS**, not a fork of any one wiki. It reads the wiki
through the `afs` CLI and the AgentsFS conventions (frontmatter, `INDEX.md`,
`[[wikilinks]]`), so as an AgentsFS instance grows new structure, this layer
benefits automatically. The `agentic-stocks/agentsfs` wiki is its first tenant.

The **same code runs in two modes:**

- **single** (default) — pinned to one AgentsFS instance (`AGENTSFS_ROOT`), for
  local chat/voice over a single knowledge base. This is what the quick-start
  below sets up.
- **workspace** — the exact same app running inside a per-user **Hub agent
  sprite**, over *many* knowledge bases cloned as siblings. It boots unfocused,
  asks which repo to work in, switches with `list_repos` / `focus_repo`, and can
  edit + commit + push, plus run a `run_bash` shell across all the repos. See
  [Workspace mode](#workspace-mode).

```
            any AgentsFS dir
                  │   (afs search/tree/backlinks + file read/grep)
        ┌─────────▼──────────┐
        │   shared engine    │   Claude/OpenAI agent loop + citation tracking
        │  (tools + reasoner)│
        └───┬────────────┬───┘
   text chat│            │voice (OpenAI Realtime, WebRTC)
     (SSE)  ▼            ▼  consult_knowledge → same agent
        browser UI    browser mic/speaker
```

## What it does

- **Chat** — streaming answers grounded only in the AgentsFS instance. Every
  answer shows citation chips; click a file chip to read the underlying markdown
  in a drawer, or a URL chip to open the source.
- **Voice** — a live, low-latency spoken conversation (OpenAI Realtime over
  WebRTC). The voice model delegates substantive questions to the same grounded
  agent via a `consult_knowledge` tool and speaks the cited answer; sources are
  pushed to the screen.
- **Capability-aware** — read tools (`search_wiki`, `read_file`, `grep`,
  `list_dir`, `backlinks`, `tree`) work over any instance and are always on.
  Structured tools (`list_theses`, `get_thesis`) light up only when the instance
  exposes them (e.g. the stocks thesis table).
- **Write-capable** (opt-in, `AGENTSFS_ALLOW_WRITES`) — `write_file` and
  `edit_file` (path-jailed to the active repo, emitting clean diffs + citations);
  `git_status` / `git_diff` are always available to review changes.
- **Shell** (opt-in, `AGENTSFS_ALLOW_SHELL`) — `run_bash` runs arbitrary
  commands from the workspace root (`afs hub pull`, `git`, `rg`, `ls`, …). When
  the shell is on it subsumes the git mutation tools, so `git_pull`, `git_commit`
  and `git_push` are folded into `run_bash` (the agent just runs `git` directly).
  This also makes it a **coding agent**: with the shell, Node, git and package
  managers on hand, `run_bash` can build, install and run real software (not just
  notes), so the chat tool-iteration cap is raised from 8 to 24 to let long
  builds finish. See [live preview](#live-preview).
- **Workspace** (mode = `workspace`) — `list_repos` and `focus_repo` enumerate
  and switch the active knowledge base among the sibling checkouts, and
  `create_repo` (workspace + writes) spins up a **brand-new** knowledge base in
  one step: `afs init <slug>`, set its description, best-effort `afs hub push` to
  publish it, then focus it — so "make me a new knowledge base for X" is a single
  request.

## Requirements

- Node ≥ 20 (developed on 23).
- The [`afs`](../agentsfs) CLI on `PATH` (the AgentsFS toolkit — used for
  search/tree/backlinks; the app degrades to plain file tools if it is missing).
- `ripgrep` (`rg`) on `PATH` (for the `grep` tool).
- An `OPENAI_API_KEY` (reasoner + voice). Set `ANTHROPIC_API_KEY` later to switch
  the reasoner to Claude once that implementation is added. **In proxy mode
  (`AGENTSFS_LLM_BASE_URL` set — how the sprite runs) no OpenAI key is needed: all
  model calls go through the hub, which holds the key** (see [Workspace mode](#workspace-mode)).

## Quick start

`.env` is already populated (copied from the agentic-stocks repo) and
dependencies are installed.

```bash
npm start                 # serve over AGENTSFS_ROOT, open http://localhost:8787
npm run chat "your question here"   # one-shot terminal chat
npm run chat              # interactive terminal REPL
npm run smoke             # live end-to-end check (hits OpenAI)
npm test                  # unit + integration tests (offline, deterministic)
npm run typecheck
```

Point it at a different AgentsFS instance by changing `AGENTSFS_ROOT` in `.env`
(or `AGENTSFS_ROOT=/path/to/other/agentsfs npm start`).

## Configuration (`.env`)

| Variable | Default | Meaning |
|---|---|---|
| `AGENTSFS_ROOT` | — | Absolute path to the AgentsFS instance to serve (in workspace mode, the workspace dir — which always exists — so the agent can boot unfocused). |
| `AGENTSFS_SEARCH_DIR` | parent of root | Workspace scanned to discover instances for the in-app picker. |
| `AGENTSFS_MODE` | `single` | `single` (pin one instance) or `workspace` (per-user sprite over many sibling repos; enables `list_repos`/`focus_repo`). |
| `AGENTSFS_WORKSPACE` | search dir | In workspace mode, the parent dir holding every repo checkout; `run_bash` runs from here. |
| `AGENTSFS_ALLOW_WRITES` | off | When on, enables `write_file`/`edit_file` (path-jailed) — git is the safety net. |
| `AGENTSFS_ALLOW_SHELL` | off | When on, enables `run_bash` (arbitrary commands). Strictly stronger than writes, so it's a separate opt-in; only safe inside an isolated per-user sprite. |
| `AGENTSFS_PREVIEW_DIR` | — | When set, its contents are served path-jailed at `/preview/*` so the coding agent can drop a built static site there and you open it at `<agent-url>/preview/` (sprite = `/home/sprite/workspace/.preview`). |
| `AGENTSFS_DATA_DIR` | — | When set, conversations persist here (one JSON file per chat) and the **Chats** drawer + multi-conversation history turn on; unset = in-memory only (sprite = `/home/sprite/.agentsfs-chat`). |
| `AGENTSFS_LLM_BASE_URL` | — | Proxy mode: point model calls at the hub's authenticated OpenAI proxy (`…/v1/agent-llm`) instead of `api.openai.com`. When set, no OpenAI key lives in the process. |
| `AGENTSFS_LLM_KEY` | — | In proxy mode, the per-user hub PAT used as the Bearer to the proxy (in place of an OpenAI key). |
| `OPENAI_API_KEY` | — | Reasoner + voice + (afs) semantic embeddings. Not required in proxy mode. |
| `ANTHROPIC_API_KEY` | — | When set, selects the (future) Claude reasoner. |
| `CHAT_MODEL` | `gpt-5.1` | Chat agent model (Responses API). |
| `CHAT_MODEL_FALLBACK` | `gpt-4.1` | Used if the primary model errors. |
| `CHAT_REASONING_EFFORT` | `low` | `none\|low\|medium\|high\|xhigh` (gpt-5.x). |
| `CHAT_VERBOSITY` | `low` | `low\|medium\|high` (gpt-5.x). |
| `REALTIME_MODEL` | `gpt-realtime-mini` | Voice model (~2-3x cheaper than `gpt-realtime`, same live feel). |
| `REALTIME_VOICE` | `marin` | Voice id. |
| `REALTIME_VAD` | `semantic` | `semantic` (natural) or `server` (lower latency). |
| `PORT` | `8787` | HTTP port. |

## How retrieval works

The agent navigates the wiki **agentically** rather than via a prebuilt RAG
index — it searches, reads, follows links, and cites, the same way the AgentsFS
ingestion agents do. `afs search` provides ranked full-text out of the box;
**semantic search turns on automatically** when the instance has an embedding
index (`afs reindex --embeddings`), and otherwise transparently falls back to
full-text. See [DECISIONS.md](DECISIONS.md) for the rationale.

## Cost visibility

Token usage and an estimated cost print per turn:
- **Chat / voice consult** → server console, e.g. `[chat] gpt-5.1 • in 5753 / out 98 tok • ~$0.015 est`, and the chat UI shows a small `model · in+out tok · ~$ est` line under each answer.
- **Voice (realtime)** → the voice panel shows a running `session • audio … · text … · ~$ est` line (read from the realtime `response.usage`, priced client-side).

Cost figures use the editable table in [src/pricing.ts](../agentsfs-chat/src/pricing.ts) (and a matching `VOICE_PRICE` in the web client). Audio rates dominate voice; the gpt-5.x text rates are estimates — adjust to your plan. See [DECISIONS.md](DECISIONS.md) for the provider/cost comparison that informed defaulting to `gpt-realtime-mini`.

## Switching instances

Click **Instance ▾** to pick any AgentsFS directory discovered under
`AGENTSFS_SEARCH_DIR`, or paste an absolute path. The server validates the target
is a real agentsfs (has `.agentsfs/` or an AGENTS.md marker — this is also the
security gate), rebuilds the agent + tools for it, and hot-swaps without a
restart. Capability-gated tools re-detect per instance (e.g. the theses tools
appear only on a stocks wiki), and the conversation resets on switch. (This is
the single-mode UI picker; in [workspace mode](#workspace-mode) it is hidden. There
you switch KBs either conversationally, letting the agent call `focus_repo`, or
directly via the **knowledge-base dropdown** in the topbar (which posts
`/api/focus`). Either way the switch takes effect immediately, in the same turn,
and the server emits an SSE `instance` event so the topbar always reflects the
active KB; on load with nothing focused the UI shows a KB picker.)

## Workspace mode

The same app also runs as the **hosted Hub agent** — one per-user Fly Sprite
(a hardware-isolated Firecracker microVM) that clones *all* of your Hub repos as
siblings under a workspace dir and runs agentsfs-chat with `AGENTSFS_MODE=workspace`,
writes + shell on. You reach it at `hub.agentsfs.ai/agent/` (owner-only), which
reverse-proxies the sprite so you never see sprites.dev.

- **Boots unfocused** over the workspace dir, calls `list_repos`, and asks which
  knowledge base to work in. `focus_repo` switches the active KB (reusing the
  single-mode instance-swap machinery; the switch is global, which is fine
  because there's exactly one user per sprite). A repo link pre-focuses via
  `?repo=`.
- Once focused it reads/searches the active KB and can `write_file`/`edit_file`
  (path-jailed to that repo). Every change is a **real git commit pushed back to
  the hub**, so `git clone` / `git pull` stay the source of truth and the exit
  ramp.
- `run_bash` runs `afs hub pull`/`list`, `git`, `rg`, `ls` across all workspace
  repos — the sprite is the sandbox boundary, so arbitrary shell is intentional
  and its blast radius is just that one user's data.

**No OpenAI key lives in the sprite.** The sprite holds only its own per-user
PAT (same-user scope — also used for `git push` and `afs hub pull`). Model calls
(text + the voice ephemeral-token mint) run in **proxy mode**: the OpenAI SDK's
`baseURL` points at the hub (`AGENTSFS_LLM_BASE_URL`) and the Bearer is the PAT
(`AGENTSFS_LLM_KEY`); the hub authenticates the PAT and reverse-proxies to
OpenAI, injecting the real shared key. So the shared key never leaves the hub —
which matters because the sprite user has passwordless sudo and `run_bash` could
otherwise read any in-VM secret. Defense-in-depth (a scrubbed `run_bash` child
env in `src/agentsfs/shell.ts`, a tool-result redactor in `src/agentsfs/redact.ts`,
and deleting reasoner keys from `process.env` after config load in `src/index.ts`)
backs this up, but the real boundary is the hub proxy + per-user Firecracker
isolation. See the AgentsFS hosted-agent doc for the full architecture.

## Live preview

When `AGENTSFS_PREVIEW_DIR` is set, the server serves that directory path-jailed
at `/preview/*` (directories fall back to `index.html`). Because the shell-on
agent is a coding agent, it can **build a static site and drop it there**, then
you open it at `<agent-url>/preview/`. In the sprite the dir is
`/home/sprite/workspace/.preview`; until the agent has built something, `/preview/`
just returns a "nothing here yet" placeholder.

## Conversation history

When `AGENTSFS_DATA_DIR` is set, chats **persist** — one JSON file per
conversation under that dir (`src/server/conversations.ts`), surviving cold-wakes
and shared across your devices (one user per sprite). `/api/chat` takes a
`conversationId` and appends each exchange, titling the conversation from your
first message and remembering the KB it was focused in. A **Chats** drawer lists
past conversations (title, time, message count, KB) with delete; **New** starts a
fresh one; reopening a chat rehydrates its messages *and* restores the KB it was
in. `/api/config` exposes `persistConversations` so the UI knows the drawer is
live. Endpoints: `GET`/`POST /api/conversations` and `GET`/`DELETE
/api/conversations/:id`. Leaving `AGENTSFS_DATA_DIR` unset keeps the old
in-memory-only behavior.

## Voice

Click **Voice**. The browser mints a short-lived ephemeral token from the server
(your real API key never leaves the server), opens a WebRTC session to OpenAI
Realtime, and streams mic audio. When the model needs facts it calls
`consult_knowledge`, which the browser relays to `/api/tools/call`; the server
runs the full grounded agent and returns a concise cited answer for the model to
speak, while the citations render on screen.

> Voice requires a real browser with a microphone, so it is verified manually
> (the token-mint, tool-relay, and agent paths are covered by automated tests and
> the live smoke check). See [DECISIONS.md](DECISIONS.md#verification).

## HTTP API

| Endpoint | Purpose |
|---|---|
| `GET /api/health` | liveness + instance/model |
| `GET /api/config` | public UI config (capabilities, suggestions, voice settings) |
| `POST /api/chat` | SSE stream: `delta`, `tool`, `done`, `error` events |
| `POST /api/tools/call` | `{name,args}` → `{content,citations}` (voice relay + file drawer) |
| `POST /api/realtime/token` | mint an ephemeral Realtime client secret (optional `{history}` seeds voice with the text conversation) |
| `GET /api/instances` | discovered AgentsFS instances under the search dir + the active one |
| `POST /api/instance` | `{path}` → hot-swap the served instance (validated as a real agentsfs) |
| `POST /api/focus` | `{repo}` → focus a workspace KB by name (the topbar KB dropdown; emits an SSE `instance` event) |
| `GET /api/conversations` | list persisted conversations (when `AGENTSFS_DATA_DIR` is set); `POST` creates a new one |
| `GET /api/conversations/:id` | fetch one conversation to rehydrate; `DELETE` removes it |
| `GET /preview/*` | the coding agent's built artifact from `AGENTSFS_PREVIEW_DIR` (path-jailed) |

## Project structure

```
src/
  config.ts            env + runtime config
  agentsfs/            afs CLI wrapper, path-jailed fs, frontmatter, capabilities,
                       git, run_bash shell (scrubbed env), secret redactor
  tools/               tool registry + citation types + structured (theses) tools
  reasoner/            provider-agnostic Reasoner + OpenAI (Responses API) impl
  agent/               system-prompt builder + agent session (loop + citations)
  server/              node:http server (SSE chat, tool relay, realtime token)
  web/                 vanilla UI (app.js) + pure helpers (lib.js) + styles
  cli.ts, index.ts     terminal chat + server entry
scripts/               dev-check.ts (read-only probe), smoke.ts (live e2e)
test/                  offline test suite + a mini-agentsfs fixture
```

## Adding a provider (Claude)

Implement `Reasoner` (see `src/reasoner/types.ts`) in `src/reasoner/anthropic.ts`
and wire it in `src/reasoner/index.ts`. Everything above the reasoner — tools,
citations, server, UI, voice hand-off — is unchanged. The voice loop can then
route `consult_knowledge` to Claude while OpenAI Realtime remains the spoken
front-end.
