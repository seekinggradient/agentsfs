import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import { readFile as fsReadFile } from "node:fs/promises";
import { existsSync, statSync } from "node:fs";
import { basename, extname, resolve, sep } from "node:path";
import { z } from "zod";
import type { Config } from "../config.js";
import { Agent, type AskResult } from "../agent/session.js";
import { createReasoner, type Reasoner } from "../reasoner/index.js";
import { estimateTextCostUsd, fmtUsd } from "../pricing.js";
import { buildToolRegistry } from "../tools/registry.js";
import { detectCapabilities } from "../agentsfs/capabilities.js";
import { discoverInstances, isAgentsfs } from "../agentsfs/discover.js";
import { redactSecrets } from "../agentsfs/redact.js";
import * as git from "../agentsfs/git.js";
import { clearFreshness } from "../agentsfs/freshness.js";
import { ConversationStore } from "./conversations.js";
import type { Citation, ToolContext, ToolRegistry } from "../tools/types.js";
import { mintEphemeralToken, type PriorTurn } from "./realtime.js";
import type { Usage } from "../reasoner/types.js";

/**
 * Minimal dependency-free HTTP server: a streaming (SSE) chat endpoint, a
 * tool-call relay used by the voice data channel, realtime token minting, and
 * static hosting of the web UI. No framework — matches the repo's stdlib style
 * and keeps the surface easy to audit.
 */

export interface AppContext {
  cfg: Config;
  agent: Agent;
  registry: ToolRegistry;
  toolCtx: ToolContext;
  /** The LLM client, reused across instance switches (it's not instance-specific). */
  reasoner: Reasoner;
  /** The live active-root box, shared with the Agent + ToolContext. Switching a
   *  repo just mutates session.root — the Agent + tools read it live, so a focus
   *  takes effect immediately (mid-turn) with no rebuild. */
  session: { root: string };
  /** Workspace mode: resolve a repo name to its checkout and focus it. */
  onFocusRepo?: (target: string) => Promise<{ name: string }>;
  /** Persistent conversation store, when cfg.dataDir is set (else undefined =
   *  in-memory chat only). */
  conversations?: ConversationStore;
}

export async function createApp(
  cfg: Config,
  reasoner?: Reasoner,
): Promise<AppContext> {
  const r = reasoner ?? createReasoner(cfg);
  const session = { root: cfg.agentsfsRoot };
  const ctx = { cfg, reasoner: r, session } as AppContext;
  ctx.onFocusRepo =
    cfg.mode === "workspace" ? (target: string) => focusRepo(ctx, target) : undefined;
  ctx.agent = await Agent.create(cfg, r, { session, onFocusRepo: ctx.onFocusRepo });
  ctx.registry = buildToolRegistry(cfg);
  ctx.toolCtx = {
    cfg,
    caps: detectCapabilities(session.root),
    session,
    focusRepo: ctx.onFocusRepo,
  };
  ctx.conversations = cfg.dataDir ? new ConversationStore(cfg.dataDir) : undefined;
  return ctx;
}

/** Point the served instance at `resolved`. Just mutates the shared session (the
 *  Agent reads it live) + refreshes the tool-relay caps — no agent rebuild. */
function setActiveRoot(ctx: AppContext, resolved: string): void {
  ctx.session.root = resolved;
  ctx.toolCtx = {
    cfg: ctx.cfg,
    caps: detectCapabilities(resolved),
    session: ctx.session,
    focusRepo: ctx.onFocusRepo,
  };
}

/**
 * Switch the served AgentsFS instance by path (the manual picker). Validates the
 * target is a real agentsfs (the security gate) and takes effect immediately.
 */
export async function switchInstance(ctx: AppContext, root: string): Promise<void> {
  const resolved = resolve(root);
  if (!isAgentsfs(resolved)) {
    throw new Error(`Not an AgentsFS instance: ${resolved}`);
  }
  setActiveRoot(ctx, resolved);
}

/**
 * Resolve a repo the model named (from list_repos) to its checkout dir. Only
 * repos discovered under the workspace (or a real agentsfs path) are accepted —
 * never an arbitrary path the model invents.
 */
function resolveRepo(ctx: AppContext, target: string): string {
  const instances = discoverInstances(ctx.cfg.searchDir);
  const match = instances.find(
    (i) => i.name === target || i.path === resolve(target),
  );
  if (match) return match.path;
  const abs = resolve(target);
  if (isAgentsfs(abs)) return abs;
  throw new Error(`no knowledge base named "${target}" in this workspace`);
}

/** The working-tree state a turn boundary found. */
type TreeSync = "clean" | "dirty" | "skipped";

/** ADVISORY freshness sync at conversation/turn boundaries — never a gate.
 *  Clean tree → fast-forward pull + freshness + context invalidation, so a
 *  conversation never STARTS from a stale checkout. Dirty tree → skip the pull
 *  and report it (never clobber, never throw): the edits are in-progress work —
 *  a pending review proposal or the agent's own batched draft awaiting its next
 *  checkpoint commit — and the caller decides what to do with the status
 *  (handleChat threads a WIP note into the model's context; review turns treat
 *  the dirt as the pending proposal). Pull failures are logged, not thrown: a
 *  turn is never failed for freshness reasons. */
async function syncWorkspaceRepo(ctx: AppContext, root: string): Promise<TreeSync> {
  if (ctx.cfg.mode !== "workspace" || !existsSync(resolve(root, ".git"))) return "skipped";
  if (await git.status(root)) return "dirty";
  try {
    await git.pull(root);
    clearFreshness(root);
    ctx.agent.invalidateContext(root);
  } catch (e) {
    console.log(`[sync] pull skipped for ${basename(root)}: ${(e as Error).message}`);
  }
  return "clean";
}

async function focusRepo(ctx: AppContext, target: string): Promise<{ name: string }> {
  const resolved = resolveRepo(ctx, target);
  // Advisory: a dirty destination checkout is in-progress work — typically a
  // pending review proposal or a batched draft — and focus must never strand
  // the user away from their own pending work (a dropdown switch-back and a
  // re-handoff with added comments both hit this). The per-turn sync in
  // handleChat handles freshness from there.
  await syncWorkspaceRepo(ctx, resolved);
  setActiveRoot(ctx, resolved);
  return { name: ctx.agent.instanceName };
}

const MAX_BODY = 1 * 1024 * 1024;

/** Log the text-model token usage + estimated cost for one agent turn. */
function logUsage(label: string, r: AskResult): number | null {
  if (!r.usage) return null;
  const cost = estimateTextCostUsd(r.model, r.usage.inputTokens, r.usage.outputTokens);
  console.log(
    `[${label}] ${r.model} • in ${r.usage.inputTokens} / out ${r.usage.outputTokens} tok` +
      (cost != null ? ` • ~${fmtUsd(cost)} est` : ""),
  );
  return cost;
}

function readBody(req: IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    let data = "";
    let size = 0;
    req.on("data", (chunk: Buffer) => {
      size += chunk.length;
      if (size > MAX_BODY) {
        reject(new Error("request body too large"));
        req.destroy();
        return;
      }
      data += chunk.toString("utf8");
    });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const text = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Content-Length": Buffer.byteLength(text),
  });
  res.end(text);
}

/** Execute a named tool (registry tool or the consult_knowledge hand-off). */
export async function executeNamedTool(
  ctx: AppContext,
  name: string,
  args: Record<string, unknown>,
): Promise<{
  content: string;
  citations: Citation[];
  usage?: Usage | null;
  costUsd?: number | null;
}> {
  if (name === "consult_knowledge") {
    const question = String(args["question"] ?? args["query"] ?? "").trim();
    if (!question) return { content: "No question provided.", citations: [] };
    const r = await ctx.agent.ask({ message: question, mode: "voice" });
    const costUsd = logUsage("voice/consult", r);
    return { content: redactSecrets(r.text), citations: r.citations, usage: r.usage ?? null, costUsd };
  }
  const tool = ctx.registry.byName.get(name);
  if (!tool) return { content: `Unknown tool: ${name}`, citations: [] };
  try {
    const result = await tool.handler(args, ctx.toolCtx);
    return { content: redactSecrets(result.content), citations: result.citations ?? [] };
  } catch (e) {
    // Return a usable tool error rather than a 500, so the voice model and the
    // file drawer both get a sensible message — redacted like the success paths.
    return { content: redactSecrets(`Tool error: ${(e as Error).message}`), citations: [] };
  }
}

function suggestedPrompts(ctx: AppContext): string[] {
  const caps = ctx.toolCtx.caps;
  if (caps.domains.includes("stocks")) {
    return [
      "What does the system currently believe about the AI infrastructure trade?",
      "Summarize the active buy theses and their conviction.",
      "What's the bear case on the strongest thesis, and what would invalidate it?",
      "Which companies are flagged as most at risk right now?",
    ];
  }
  return [
    `What is the "${ctx.agent.instanceName}" knowledge base about?`,
    "What are the main topics covered here?",
    "What changed most recently?",
  ];
}

function publicConfig(ctx: AppContext) {
  const caps = ctx.toolCtx.caps;
  return {
    instanceName: ctx.agent.instanceName,
    provider: ctx.cfg.provider,
    model: ctx.cfg.chatModel,
    domains: caps.domains,
    capabilities: {
      theses: !!caps.thesesJsonPath,
      portfolio: caps.hasPortfolio,
      education: caps.hasEducation,
      index: caps.hasIndex,
    },
    realtime: {
      model: ctx.cfg.realtimeModel,
      voice: ctx.cfg.realtimeVoice,
      vad: ctx.cfg.realtimeVad,
    },
    mode: ctx.cfg.mode,
    persistConversations: !!ctx.conversations,
    // Workspace mode: the KBs the user can pick + whether one is focused yet
    // (unfocused = still sitting on the workspace dir).
    workspace:
      ctx.cfg.mode === "workspace"
        ? {
            repos: discoverInstances(ctx.cfg.searchDir).map((i) => i.name),
            active: ctx.session.root === ctx.cfg.workspaceDir ? null : basename(ctx.session.root),
          }
        : undefined,
    suggestedPrompts: suggestedPrompts(ctx),
  };
}

// --- static assets ---------------------------------------------------------
const WEB_DIR_URL = new URL("../web/", import.meta.url);
const STATIC: Record<string, string> = {
  "/": "index.html",
  "/index.html": "index.html",
  "/app.js": "app.js",
  "/lib.js": "lib.js",
  "/styles.css": "styles.css",
};
const MIME: Record<string, string> = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
};

async function serveStatic(res: ServerResponse, pathname: string): Promise<boolean> {
  const file = STATIC[pathname];
  if (!file) return false;
  try {
    const buf = await fsReadFile(new URL(file, WEB_DIR_URL));
    res.writeHead(200, { "Content-Type": MIME[extname(file)] ?? "application/octet-stream" });
    res.end(buf);
  } catch {
    res.writeHead(404).end("not found");
  }
  return true;
}

// Broader MIME set for previewed artifacts (a site the coding agent built).
const PREVIEW_MIME: Record<string, string> = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
  ".txt": "text/plain; charset=utf-8",
  ".md": "text/plain; charset=utf-8",
};

// Preview files are authored by the coding agent, so treat every response as
// untrusted even though the hub has to expose it below its authenticated
// /agent proxy. The CSP sandbox intentionally omits allow-same-origin: scripts
// still run, but the document gets an opaque origin and cannot read hub cookies,
// localStorage, or authenticated API responses. The remaining directives make
// the supported artifact deliberately self-contained: only inline script/style
// and embedded image/font/media data are usable; forms, frames, workers,
// plugins, base-URL rewriting, and all network connections are denied.
const PREVIEW_CSP =
  "default-src 'none'; " +
  "script-src 'unsafe-inline'; style-src 'unsafe-inline'; " +
  "img-src data: blob:; font-src data:; media-src data: blob:; " +
  "worker-src 'none'; connect-src 'none'; frame-src 'none'; object-src 'none'; " +
  "base-uri 'none'; form-action 'none'; " +
  "sandbox allow-scripts";

function setPreviewSecurityHeaders(res: ServerResponse): void {
  res.setHeader("Content-Security-Policy", PREVIEW_CSP);
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
}

/**
 * Serve the coding agent's built artifact from cfg.previewDir at /preview/*, so
 * the user can view a site it built at <agent-url>/preview/. Path-jailed to the
 * preview dir; directories fall back to index.html.
 */
async function servePreview(ctx: AppContext, res: ServerResponse, pathname: string): Promise<boolean> {
  const dir = ctx.cfg.previewDir;
  if (!dir) return false;
  setPreviewSecurityHeaders(res);
  const base = resolve(dir);
  let rel = "";
  try {
    rel = decodeURIComponent(pathname.replace(/^\/preview\/?/, ""));
  } catch {
    res.writeHead(400).end("bad path");
    return true;
  }
  let target = resolve(base, rel || ".");
  if (target !== base && !target.startsWith(base + sep)) {
    res.writeHead(403).end("forbidden");
    return true;
  }
  try {
    if (statSync(target).isDirectory()) target = resolve(target, "index.html");
    const buf = await fsReadFile(target);
    res.writeHead(200, { "Content-Type": PREVIEW_MIME[extname(target).toLowerCase()] ?? "application/octet-stream" });
    res.end(buf);
  } catch {
    res.writeHead(404).end("Nothing here yet — the agent hasn't built a preview.");
  }
  return true;
}

function isPreviewPath(pathname: string): boolean {
  return pathname === "/preview" || pathname.startsWith("/preview/");
}

const chatSchema = z.object({
  message: z.string().min(1),
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() }))
    .optional(),
  mode: z.enum(["chat", "voice"]).optional(),
  /** When set (+ persistence enabled), the turn is saved to this conversation. */
  conversationId: z.string().optional(),
  /** Agentic co-editing "review mode": restrict the tool set (read +
   *  write_file/edit_file, no commit/push/shell) and, after the turn, emit a
   *  `proposal` SSE event with the working-tree diff for the user to approve. */
  review: z.boolean().optional(),
});

const reviewCommitSchema = z.object({
  message: z.string().optional(),
  /** The repo the proposal was made against. In workspace mode the server
   *  verifies it still matches the focused checkout, so approving can never
   *  commit a DIFFERENT repo's dirty tree after a focus switch. */
  repo: z.string().optional(),
});
const reviewDiscardSchema = z.object({ repo: z.string().optional() });

const toolSchema = z.object({
  name: z.string().min(1),
  args: z.record(z.string(), z.unknown()).optional(),
});

const instanceSchema = z.object({ path: z.string().min(1) });
const focusSchema = z.object({ repo: z.string().min(1) });

/** Read + JSON-parse a body, mapping failures to 400/413 instead of 500. */
async function parseBody(
  req: IncomingMessage,
  res: ServerResponse,
): Promise<unknown | undefined> {
  let raw: string;
  try {
    raw = await readBody(req);
  } catch (e) {
    const tooLarge = /too large/i.test((e as Error).message);
    sendJson(res, tooLarge ? 413 : 400, {
      error: tooLarge ? "request body too large" : "could not read body",
    });
    return undefined;
  }
  try {
    return JSON.parse(raw);
  } catch {
    sendJson(res, 400, { error: "invalid JSON body" });
    return undefined;
  }
}

/**
 * Extract the agent's suggested commit message from a review reply: the LAST
 * line of the form `Commit: <message>` (the review prompt asks for exactly one,
 * as the final line, only when files were edited). Returns null when absent so
 * the client falls back to its default prefill. Exported for unit tests.
 */
export function extractCommitMessage(text: string): string | null {
  let out: string | null = null;
  for (const line of String(text).split("\n")) {
    const m = line.match(/^Commit:\s*(.+?)\s*$/);
    if (m && m[1]!.trim()) out = m[1]!.trim(); // last matching line wins
  }
  return out;
}

async function handleChat(ctx: AppContext, req: IncomingMessage, res: ServerResponse) {
  const body = await parseBody(req, res);
  if (body === undefined) return;
  const parsed = chatSchema.safeParse(body);
  if (!parsed.success) return sendJson(res, 400, { error: parsed.error.message });
  const { message, history, mode, conversationId, review } = parsed.data;

  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache, no-transform",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no",
  });
  const send = (event: string, data: unknown) =>
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);

  const controller = new AbortController();
  req.on("close", () => controller.abort());

  try {
    // The hosted agent may stay warm for days. Advisory sync at the turn
    // boundary: a clean tree fast-forwards so the turn never starts stale; a
    // dirty tree proceeds untouched. On a non-review turn a dirty tree gets a
    // WIP note threaded into the model's context (it is likely the agent's own
    // batched draft awaiting a checkpoint commit); on a review turn the dirt
    // IS the pending proposal, so no note is needed.
    const treeState = await syncWorkspaceRepo(ctx, ctx.session.root);
    const result = await ctx.agent.ask({
      message,
      history: history ?? [],
      mode: mode ?? "chat",
      review,
      dirtyTree: !review && treeState === "dirty",
      signal: controller.signal,
      onTextDelta: (text) => send("delta", { text }),
      onReset: () => send("reset", {}),
      onToolCall: (name, args) => send("tool", { name, args }),
      onInstanceChange: (name) => send("instance", { name }),
    });
    const costUsd = logUsage("chat", result);
    // Persist the exchange (best effort) so the conversation survives reloads.
    if (ctx.conversations && conversationId && mode !== "voice") {
      const repo = ctx.cfg.mode === "workspace" ? basename(ctx.session.root) : undefined;
      ctx.conversations.append(conversationId, message, result.text, repo).catch(() => {});
    }
    // Post-turn working-tree surface.
    // - Review turn: a dirty tree is the PROPOSAL (diff + counts + the model's
    //   suggested commit message) for the approve/discard card. Clean → no
    //   event — which is also what an answer-only review turn looks like.
    // - Non-review chat turn: ALWAYS emit a `tree` event — {files, diff} when
    //   dirty (drives the persistent uncommitted-changes banner), and
    //   {files: [], diff: ""} when clean so the client dismisses the banner.
    try {
      const root = ctx.session.root;
      const dirty = !!(await git.status(root));
      if (review) {
        if (dirty) {
          const [diffText, stats] = await Promise.all([git.diff(root), git.numstat(root)]);
          // The model ends an editing reply with a `Commit: <message>` line —
          // its own description of the change, offered as the card's prefill.
          const suggestedMessage = extractCommitMessage(result.text);
          send("proposal", {
            files: stats.map((s) => ({
              path: s.path,
              additions: s.additions,
              deletions: s.deletions,
            })),
            diff: diffText,
            ...(suggestedMessage ? { suggestedMessage } : {}),
          });
        }
      } else {
        // `ahead` surfaces committed-but-unpushed work (a checkpoint whose
        // push failed) — invisible in dirty/clean terms but very much not on
        // the hub yet. aheadCount tolerates no-upstream → 0.
        const ahead = await git.aheadCount(root);
        if (dirty) {
          const [diffText, stats] = await Promise.all([git.diff(root), git.numstat(root)]);
          send("tree", {
            files: stats.map((s) => ({
              path: s.path,
              additions: s.additions,
              deletions: s.deletions,
            })),
            diff: diffText,
            ahead,
          });
        } else {
          send("tree", { files: [], diff: "", ahead });
        }
      }
    } catch (e) {
      console.log(`[review] could not report working-tree state: ${(e as Error).message}`);
    }
    send("done", {
      text: result.text,
      citations: result.citations,
      model: result.model,
      toolCallCount: result.toolCallCount,
      usage: result.usage ?? null,
      costUsd,
    });
  } catch (e) {
    send("error", { message: (e as Error).message });
  } finally {
    res.end();
  }
}

async function handleToolCall(ctx: AppContext, req: IncomingMessage, res: ServerResponse) {
  const body = await parseBody(req, res);
  if (body === undefined) return;
  const parsed = toolSchema.safeParse(body);
  if (!parsed.success) return sendJson(res, 400, { error: parsed.error.message });
  const out = await executeNamedTool(ctx, parsed.data.name, parsed.data.args ?? {});
  sendJson(res, 200, out);
}

async function handleRealtimeToken(
  ctx: AppContext,
  req: IncomingMessage,
  res: ServerResponse,
) {
  // Optional body { history } seeds the voice session with the text conversation.
  let history: PriorTurn[] = [];
  try {
    const body = JSON.parse(await readBody(req));
    if (body && Array.isArray(body.history)) {
      history = body.history.filter(
        (m: unknown): m is PriorTurn =>
          !!m &&
          ((m as PriorTurn).role === "user" || (m as PriorTurn).role === "assistant") &&
          typeof (m as PriorTurn).content === "string",
      );
    }
  } catch {
    /* no/invalid body — start voice without prior context */
  }
  try {
    // Voice sessions bypass /api/chat, so run the same ADVISORY sync before
    // minting: a clean checkout fast-forwards, a dirty one proceeds untouched —
    // a dirty tree must never 502 the mint. Later focus_repo calls also sync
    // the destination checkout before switching the live root.
    await syncWorkspaceRepo(ctx, ctx.session.root);
    const token = await mintEphemeralToken(ctx.cfg, ctx.agent, history);
    sendJson(res, 200, token);
  } catch (e) {
    sendJson(res, 502, { error: (e as Error).message });
  }
}

function handleInstances(ctx: AppContext, res: ServerResponse) {
  const instances = discoverInstances(ctx.cfg.searchDir);
  // Always include the active instance, even if it's outside the search dir.
  if (!instances.some((i) => i.path === ctx.session.root)) {
    instances.unshift({
      path: ctx.session.root,
      name: basename(ctx.session.root),
    });
  }
  sendJson(res, 200, {
    current: ctx.session.root,
    searchDir: ctx.cfg.searchDir,
    instances,
  });
}

async function handleSwitchInstance(
  ctx: AppContext,
  req: IncomingMessage,
  res: ServerResponse,
) {
  const body = await parseBody(req, res);
  if (body === undefined) return;
  const parsed = instanceSchema.safeParse(body);
  if (!parsed.success) return sendJson(res, 400, { error: parsed.error.message });
  try {
    await switchInstance(ctx, parsed.data.path);
    sendJson(res, 200, publicConfig(ctx));
  } catch (e) {
    sendJson(res, 400, { error: (e as Error).message });
  }
}

/** Focus a repo by name (workspace mode) — used by the repo-button ?repo= hint
 *  so the agent lands already scoped to that knowledge base. */
async function handleFocus(ctx: AppContext, req: IncomingMessage, res: ServerResponse) {
  const body = await parseBody(req, res);
  if (body === undefined) return;
  const parsed = focusSchema.safeParse(body);
  if (!parsed.success) return sendJson(res, 400, { error: parsed.error.message });
  if (!ctx.onFocusRepo) return sendJson(res, 400, { error: "not in workspace mode" });
  try {
    await ctx.onFocusRepo(parsed.data.repo);
    sendJson(res, 200, publicConfig(ctx));
  } catch (e) {
    sendJson(res, 400, { error: (e as Error).message });
  }
}

// --- deterministic commit/discard endpoints (no LLM) ---
// Born as the review-mode approve/discard pair, now DUAL-USE: the uncommitted-
// changes banner (checkpoint drafts left by normal chat turns) drives the same
// two endpoints. The no-commit gate for review stays structural: the agent can
// only leave edits in the working tree; these endpoints are the only way tree
// state gets committed or thrown away, and both are plain git — no model.

/** Workspace-mode guard: when the client names the repo its proposal targets,
 *  refuse (409) if the focused checkout is a different one — the user may have
 *  switched KBs in the panel between the proposal and the approve/discard. */
function reviewRepoMismatch(ctx: AppContext, repo: string | undefined): string | null {
  if (!repo || ctx.cfg.mode !== "workspace") return null;
  const active = basename(ctx.session.root);
  if (active === repo) return null;
  return `the agent is focused on "${active}", not "${repo}" — switch back to "${repo}" before approving or discarding this proposal`;
}

/** Push, and if the remote moved, attempt exactly one `git pull --rebase`
 *  (aborted on conflict, leaving the tree/commits intact) then one more push.
 *  Reports truthfully whether the changes landed on the remote. */
async function pushWithRebaseRetry(root: string): Promise<boolean> {
  try {
    await git.push(root);
    return true;
  } catch (e) {
    console.log(`[review] push failed: ${(e as Error).message} — trying pull --rebase`);
  }
  if (!(await git.pullRebase(root))) {
    console.log("[review] pull --rebase failed (aborted); keeping local commits for a manual retry");
    return false;
  }
  try {
    await git.push(root);
    return true;
  } catch (e) {
    console.log(`[review] push after rebase failed: ${(e as Error).message}`);
    return false;
  }
}

/**
 * Approve pending changes (a review proposal OR the banner's checkpoint draft):
 * stage everything, commit with the agent identity, and push — rebasing once if
 * the remote moved. Idempotent/retryable: a clean tree with commits stranded
 * ahead of the upstream (a previous approve committed but the push failed)
 * retries the push and reports the current HEAD. A clean, fully-pushed tree
 * returns {commit:null, pushed:false} (nothing to do).
 */
async function handleReviewCommit(ctx: AppContext, req: IncomingMessage, res: ServerResponse) {
  const body = await parseBody(req, res);
  if (body === undefined) return;
  const parsed = reviewCommitSchema.safeParse(body);
  if (!parsed.success) return sendJson(res, 400, { error: parsed.error.message });
  const mismatch = reviewRepoMismatch(ctx, parsed.data.repo);
  if (mismatch) return sendJson(res, 409, { error: mismatch });
  const root = ctx.session.root;
  try {
    if (!(await git.status(root))) {
      if ((await git.aheadCount(root)) === 0) {
        return sendJson(res, 200, { commit: null, pushed: false });
      }
      // Retry path: committed earlier but the push didn't land on the hub.
      const pushed = await pushWithRebaseRetry(root);
      return sendJson(res, 200, { commit: await git.headShort(root), pushed });
    }
    const message = parsed.data.message?.trim() || "Resolve review comments";
    await git.commitAll(root, message, {
      name: ctx.cfg.agentName,
      email: ctx.cfg.agentEmail,
    });
    // Remote may be unreachable / moved / not configured; a rebase is attempted
    // once, the commit always stands, and a re-POST takes the retry path above.
    const pushed = await pushWithRebaseRetry(root);
    // Report HEAD *after* the push attempt — a successful rebase rewrote the sha.
    sendJson(res, 200, { commit: await git.headShort(root), pushed });
  } catch (e) {
    sendJson(res, 500, { error: (e as Error).message });
  }
}

/** Discard pending changes — a review proposal or the banner's checkpoint
 *  draft: revert the working tree to HEAD (jailed to root). */
async function handleReviewDiscard(ctx: AppContext, req: IncomingMessage, res: ServerResponse) {
  const body = await parseBody(req, res);
  if (body === undefined) return;
  const parsed = reviewDiscardSchema.safeParse(body);
  if (!parsed.success) return sendJson(res, 400, { error: parsed.error.message });
  const mismatch = reviewRepoMismatch(ctx, parsed.data.repo);
  if (mismatch) return sendJson(res, 409, { error: mismatch });
  try {
    await git.discard(ctx.session.root);
    sendJson(res, 200, { ok: true });
  } catch (e) {
    sendJson(res, 500, { error: (e as Error).message });
  }
}

// --- conversations (persistent, when cfg.dataDir is set) ---
async function handleConversations(ctx: AppContext, req: IncomingMessage, res: ServerResponse) {
  if (!ctx.conversations) {
    if (req.method === "GET") return sendJson(res, 200, { conversations: [] });
    return sendJson(res, 501, { error: "conversation history is not enabled" });
  }
  if (req.method === "GET") {
    return sendJson(res, 200, { conversations: await ctx.conversations.list() });
  }
  const c = await ctx.conversations.create();
  sendJson(res, 200, { id: c.id, title: c.title });
}

async function handleConversation(ctx: AppContext, req: IncomingMessage, res: ServerResponse, id: string) {
  if (!ctx.conversations) return sendJson(res, 404, { error: "not found" });
  if (req.method === "DELETE") {
    await ctx.conversations.remove(id);
    return sendJson(res, 200, { ok: true });
  }
  const c = await ctx.conversations.get(id);
  if (!c) return sendJson(res, 404, { error: "not found" });
  sendJson(res, 200, c);
}

export function makeRequestHandler(ctx: AppContext) {
  return async (req: IncomingMessage, res: ServerResponse) => {
    try {
      const url = new URL(req.url ?? "/", "http://localhost");
      const { pathname } = url;

      if (req.method === "GET" && (await serveStatic(res, pathname))) return;
      if (
        (req.method === "GET" || req.method === "HEAD") &&
        isPreviewPath(pathname) &&
        (await servePreview(ctx, res, pathname))
      ) return;

      if (req.method === "GET" && pathname === "/api/health") {
        return sendJson(res, 200, {
          ok: true,
          provider: ctx.cfg.provider,
          model: ctx.cfg.chatModel,
          root: ctx.session.root,
          instanceName: ctx.agent.instanceName,
        });
      }
      if (req.method === "GET" && pathname === "/api/config") {
        return sendJson(res, 200, publicConfig(ctx));
      }
      if (req.method === "GET" && pathname === "/api/instances") {
        return handleInstances(ctx, res);
      }
      if (req.method === "POST" && pathname === "/api/instance") {
        return await handleSwitchInstance(ctx, req, res);
      }
      if (req.method === "POST" && pathname === "/api/focus") {
        return await handleFocus(ctx, req, res);
      }
      if (pathname === "/api/conversations" && (req.method === "GET" || req.method === "POST")) {
        return await handleConversations(ctx, req, res);
      }
      if (pathname.startsWith("/api/conversations/") && (req.method === "GET" || req.method === "DELETE")) {
        return await handleConversation(ctx, req, res, pathname.slice("/api/conversations/".length));
      }
      if (req.method === "POST" && pathname === "/api/chat") {
        return await handleChat(ctx, req, res);
      }
      if (req.method === "POST" && pathname === "/api/review/commit") {
        return await handleReviewCommit(ctx, req, res);
      }
      if (req.method === "POST" && pathname === "/api/review/discard") {
        return await handleReviewDiscard(ctx, req, res);
      }
      if (req.method === "POST" && pathname === "/api/tools/call") {
        return await handleToolCall(ctx, req, res);
      }
      if (req.method === "POST" && pathname === "/api/realtime/token") {
        return await handleRealtimeToken(ctx, req, res);
      }
      sendJson(res, 404, { error: "not found" });
    } catch (e) {
      if (!res.headersSent) sendJson(res, 500, { error: (e as Error).message });
      else res.end();
    }
  };
}

export function startServer(
  ctx: AppContext,
  port?: number,
  host = "127.0.0.1",
): Promise<Server> {
  // Bind to loopback by default: this is an unauthenticated local tool that can
  // read files and spend API quota — it must not be reachable from the LAN.
  const server = createServer(makeRequestHandler(ctx));
  return new Promise((resolve) => {
    server.listen(port ?? ctx.cfg.port, host, () => resolve(server));
  });
}
