import { mkdir, readFile, writeFile, readdir, unlink } from "node:fs/promises";
import { join } from "node:path";
import { randomUUID } from "node:crypto";

/**
 * Persistent conversation store — one JSON file per conversation under
 * <dataDir>/conversations/. The sprite's disk survives cold-wakes, so chats
 * persist across reloads and (since one user per sprite) across the user's
 * devices. Only enabled when cfg.dataDir is set; otherwise chat is in-memory.
 */

export interface StoredMessage {
  role: "user" | "assistant";
  content: string;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  /** The KB focused when the conversation was last active (workspace mode). */
  activeRepo?: string;
  messages: StoredMessage[];
}

export interface ConversationSummary {
  id: string;
  title: string;
  updatedAt: number;
  messageCount: number;
  activeRepo?: string;
}

/** Conversation ids are randomUUIDs; validate before using one as a filename. */
function safeId(id: string): string {
  if (!/^[A-Za-z0-9-]{8,64}$/.test(id)) throw new Error("bad conversation id");
  return id;
}

export class ConversationStore {
  private readonly dir: string;
  constructor(dataDir: string) {
    this.dir = join(dataDir, "conversations");
  }
  private file(id: string): string {
    return join(this.dir, safeId(id) + ".json");
  }

  async create(title = ""): Promise<Conversation> {
    await mkdir(this.dir, { recursive: true });
    const now = Date.now();
    const c: Conversation = {
      id: randomUUID(),
      title: title.slice(0, 80),
      createdAt: now,
      updatedAt: now,
      messages: [],
    };
    await writeFile(this.file(c.id), JSON.stringify(c));
    return c;
  }

  async get(id: string): Promise<Conversation | null> {
    try {
      return JSON.parse(await readFile(this.file(id), "utf8")) as Conversation;
    } catch {
      return null;
    }
  }

  /** Append one user+assistant exchange, updating the title (from the first user
   *  message) and the last active repo. No-op if the conversation is gone. */
  async append(
    id: string,
    user: string,
    assistant: string,
    activeRepo?: string,
  ): Promise<void> {
    const c = await this.get(id);
    if (!c) return;
    c.messages.push({ role: "user", content: user }, { role: "assistant", content: assistant });
    c.updatedAt = Date.now();
    if (activeRepo) c.activeRepo = activeRepo;
    if (!c.title && user) c.title = user.replace(/\s+/g, " ").trim().slice(0, 80);
    await writeFile(this.file(c.id), JSON.stringify(c));
  }

  async list(): Promise<ConversationSummary[]> {
    let files: string[];
    try {
      files = (await readdir(this.dir)).filter((f) => f.endsWith(".json"));
    } catch {
      return [];
    }
    const out: ConversationSummary[] = [];
    for (const f of files) {
      try {
        const c = JSON.parse(await readFile(join(this.dir, f), "utf8")) as Conversation;
        if (c.messages.length === 0) continue; // skip empty/unused conversations
        out.push({
          id: c.id,
          title: c.title || "Untitled chat",
          updatedAt: c.updatedAt,
          messageCount: c.messages.length,
          activeRepo: c.activeRepo,
        });
      } catch {
        /* skip unreadable */
      }
    }
    return out.sort((a, b) => b.updatedAt - a.updatedAt);
  }

  async remove(id: string): Promise<void> {
    try {
      await unlink(this.file(id));
    } catch {
      /* already gone */
    }
  }
}
