import type { Config } from "../config.js";
import type { Agent } from "../agent/session.js";
import type { ToolSpec } from "../reasoner/types.js";

/**
 * OpenAI Realtime helpers for the voice mode. The browser never sees the real
 * API key: the server mints a short-lived ephemeral client secret bound to a
 * session config (model, voice, VAD, tools). The voice model's hard work is
 * delegated to the consult_knowledge tool, which runs the full grounded agent.
 */

const TOKEN_URL = "https://api.openai.com/v1/realtime/client_secrets";

/** The lean tool set the realtime model is given. */
export function voiceToolSpecs(agent: Agent): ToolSpec[] {
  const consult: ToolSpec = {
    name: "consult_knowledge",
    description:
      "Deeply research the knowledge base to answer a question. Searches, " +
      "reads, and cites multiple files and returns a concise spoken answer " +
      "with sources. Use this for any substantive question.",
    parameters: {
      type: "object",
      properties: {
        question: {
          type: "string",
          description: "A clear, self-contained question to research.",
        },
      },
      required: ["question"],
      additionalProperties: false,
    },
  };
  const search = agent.toolSpecs.find((t) => t.name === "search_wiki");
  return search ? [consult, search] : [consult];
}

function turnDetection(cfg: Config) {
  return cfg.realtimeVad === "server"
    ? {
        type: "server_vad",
        threshold: 0.5,
        prefix_padding_ms: 300,
        silence_duration_ms: 500,
        create_response: true,
        interrupt_response: true,
      }
    : {
        type: "semantic_vad",
        eagerness: "auto",
        create_response: true,
        interrupt_response: true,
      };
}

export interface EphemeralToken {
  value: string;
  expires_at?: number;
  [k: string]: unknown;
}

/**
 * Mint an ephemeral client secret for the browser. Throws on non-2xx with the
 * upstream error text so the caller can surface a useful message.
 */
export interface PriorTurn {
  role: "user" | "assistant";
  content: string;
}

export async function mintEphemeralToken(
  cfg: Config,
  agent: Agent,
  history: PriorTurn[] = [],
): Promise<EphemeralToken> {
  if (!cfg.openaiApiKey) throw new Error("OPENAI_API_KEY is required for voice.");
  const tools = voiceToolSpecs(agent).map((t) => ({
    type: "function",
    name: t.name,
    description: t.description,
    parameters: t.parameters,
  }));

  // Seed the voice session with the recent text conversation so starting voice
  // continues the same thread instead of starting cold.
  let instructions = agent.realtimeInstructions();
  if (history.length) {
    const ctx = history
      .slice(-8)
      .map((m) => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`)
      .join("\n");
    instructions +=
      `\n\nThe user was just chatting with you in text. Recent conversation so ` +
      `far (continue it naturally; don't re-introduce yourself):\n${ctx}`;
  }

  const body = {
    expires_after: { anchor: "created_at", seconds: 600 },
    session: {
      type: "realtime",
      model: cfg.realtimeModel,
      instructions,
      output_modalities: ["audio"],
      audio: {
        input: {
          transcription: { model: "gpt-4o-mini-transcribe" },
          turn_detection: turnDetection(cfg),
        },
        output: { voice: cfg.realtimeVoice },
      },
      tools,
      tool_choice: "auto",
    },
  };

  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${cfg.openaiApiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(10_000),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`realtime token mint failed (${res.status}): ${text}`);
  }
  return (await res.json()) as EphemeralToken;
}
