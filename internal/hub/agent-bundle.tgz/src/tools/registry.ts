import { z } from "zod";
import type { Config } from "../config.js";
import { detectCapabilities } from "../agentsfs/capabilities.js";
import * as afs from "../agentsfs/afs.js";
import {
  editFileSafe,
  grep,
  listDir,
  readFile,
  safeResolve,
  writeFileSafe,
} from "../agentsfs/files.js";
import * as git from "../agentsfs/git.js";
import { clearFreshness } from "../agentsfs/freshness.js";
import { runShell } from "../agentsfs/shell.js";
import { redactSecrets } from "../agentsfs/redact.js";
import { discoverInstances } from "../agentsfs/discover.js";
import { basename, dirname, join } from "node:path";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { description, extractSources } from "../agentsfs/frontmatter.js";
import { readFile as fsReadFile } from "node:fs/promises";
import { buildStructuredTools } from "./structured.js";
import type { Citation, Tool, ToolRegistry } from "./types.js";

/**
 * The generic AgentsFS tool set. These work over any AgentsFS instance:
 * search, read, grep, list, backlinks, tree. Capability-gated structured tools
 * (e.g. theses) are appended when the instance exposes them.
 *
 * Every handler returns citations so the chat/voice layer can show exactly
 * which files and URLs grounded an answer.
 */

function fileCitation(path: string, label?: string, line?: number): Citation {
  return { type: "file", path, label, line };
}

/** One-line description from a repo's root AGENTS.md, for the workspace picker. */
function repoDescription(dir: string): string {
  try {
    return description(readFileSync(join(dir, "AGENTS.md"), "utf8")) ?? "";
  } catch {
    return "";
  }
}

export function buildToolRegistry(cfg: Config): ToolRegistry {
  // Build-time root (gates capability-specific structured tools). The ACTIVE
  // root that read/write handlers use is ctx.session.root, resolved live per call.
  const caps = detectCapabilities(cfg.agentsfsRoot);
  const tools: Tool[] = [];

  // --- search_wiki ---------------------------------------------------------
  const searchArgs = z.object({
    query: z.string().min(1),
    semantic: z.boolean().optional(),
    limit: z.number().int().positive().max(25).optional(),
  });
  tools.push({
    name: "search_wiki",
    description:
      "Search the AgentsFS knowledge base and get ranked file matches with " +
      "snippets. Set semantic=true for meaning-based recall (falls back to " +
      "full-text automatically if no embedding index exists). This is usually " +
      "the first tool to call. Then read_file the most relevant results.",
    parameters: {
      type: "object",
      properties: {
        query: { type: "string", description: "What to search for." },
        semantic: {
          type: "boolean",
          description: "Use semantic (meaning-based) search when available.",
        },
        limit: { type: "number", description: "Max results (default 8)." },
      },
      required: ["query"],
      additionalProperties: false,
    },
    async handler(raw, ctx) {
      const args = searchArgs.parse(raw ?? {});
      let smart: afs.SmartSearch;
      try {
        smart = await afs.searchSmart(ctx.session.root, args.query, {
          semantic: args.semantic,
          limit: args.limit ?? 8,
        });
      } catch {
        // afs unavailable — degrade to a ripgrep text search so the agent can
        // still find content on instances without the afs CLI.
        const matches = await grep(ctx.session.root, args.query, {
          maxResults: args.limit ?? 8,
        });
        if (matches.length === 0) {
          return { content: `No matches for "${args.query}".` };
        }
        const seen = new Set<string>();
        const cites: Citation[] = [];
        for (const m of matches) {
          if (seen.has(m.path)) continue;
          seen.add(m.path);
          cites.push(fileCitation(m.path));
        }
        const body = matches.map((m) => `${m.path}:${m.line}: ${m.text}`).join("\n");
        return { content: `(afs unavailable — text search)\n${body}`, citations: cites };
      }
      const { results, mode, fellBack } = smart;
      if (results.length === 0) {
        return { content: `No matches for "${args.query}".` };
      }
      const lines = results.map((r) => {
        const head = `${r.rank}. ${r.path}${
          r.section ? `  §${r.section}` : ""
        }${r.score !== undefined ? `  (score ${r.score.toFixed(3)})` : ""}`;
        return `${head}\n   ${r.snippet}`;
      });
      const note =
        fellBack && mode === "fulltext"
          ? "(semantic index unavailable — used full-text)\n"
          : "";
      return {
        content: `${note}${lines.join("\n")}`,
        citations: results.map((r) => fileCitation(r.path)),
      };
    },
  });

  // --- read_file -----------------------------------------------------------
  const readArgs = z.object({ path: z.string().min(1) });
  tools.push({
    name: "read_file",
    description:
      "Read a file from the knowledge base by its instance-relative path " +
      "(as returned by search_wiki). Returns the full markdown including " +
      "frontmatter sources you should cite.",
    parameters: {
      type: "object",
      properties: {
        path: { type: "string", description: "Instance-relative file path." },
      },
      required: ["path"],
      additionalProperties: false,
    },
    async handler(raw, ctx) {
      const { path } = readArgs.parse(raw ?? {});
      const file = await readFile(ctx.session.root, path);
      const citations: Citation[] = [fileCitation(file.path)];
      for (const s of extractSources(file.content).slice(0, 15)) {
        if (/^https?:\/\//.test(s)) citations.push({ type: "url", url: s });
      }
      const prefix = file.truncated
        ? `[truncated to ${Math.round(file.content.length / 1024)}KB of ${Math.round(file.bytes / 1024)}KB]\n\n`
        : "";
      return { content: prefix + file.content, citations };
    },
  });

  // --- grep ----------------------------------------------------------------
  const grepArgs = z.object({
    pattern: z.string().min(1),
    glob: z.string().optional(),
    regex: z.boolean().optional(),
    limit: z.number().int().positive().max(120).optional(),
  });
  tools.push({
    name: "grep",
    description:
      "Exact/regex text search across the knowledge base (ripgrep). Use when " +
      "you need every occurrence of a precise string (a ticker, a name, a " +
      "phrase). search_wiki is better for conceptual questions.",
    parameters: {
      type: "object",
      properties: {
        pattern: { type: "string", description: "Literal text (or regex)." },
        glob: {
          type: "string",
          description: "Optional path glob, e.g. 'stocks/**/*.md'.",
        },
        regex: { type: "boolean", description: "Treat pattern as regex." },
        limit: { type: "number", description: "Max matches (default 60)." },
      },
      required: ["pattern"],
      additionalProperties: false,
    },
    async handler(raw, ctx) {
      const args = grepArgs.parse(raw ?? {});
      const matches = await grep(ctx.session.root, args.pattern, {
        glob: args.glob,
        isRegex: args.regex,
        maxResults: args.limit ?? 60,
      });
      if (matches.length === 0) {
        return { content: `No matches for "${args.pattern}".` };
      }
      const body = matches
        .map((m) => `${m.path}:${m.line}: ${m.text}`)
        .join("\n");
      const seen = new Set<string>();
      const citations: Citation[] = [];
      for (const m of matches) {
        if (seen.has(m.path)) continue;
        seen.add(m.path);
        citations.push(fileCitation(m.path));
      }
      return { content: `${matches.length} match(es):\n${body}`, citations };
    },
  });

  // --- list_dir ------------------------------------------------------------
  const listArgs = z.object({ path: z.string().optional() });
  tools.push({
    name: "list_dir",
    description:
      "List a directory in the knowledge base. Each directory has an INDEX.md " +
      "describing it; this returns child entries (dirs first). Use tree for a " +
      "whole-subtree overview.",
    parameters: {
      type: "object",
      properties: {
        path: { type: "string", description: "Instance-relative dir (default root)." },
      },
      additionalProperties: false,
    },
    async handler(raw, ctx) {
      const { path } = listArgs.parse(raw ?? {});
      const rel = path ?? ".";
      const entries = await listDir(ctx.session.root, rel);
      const lines: string[] = [];
      for (const e of entries) {
        if (e.type === "dir") {
          // Best-effort: pull the directory's INDEX.md description.
          let desc = "";
          try {
            const idxAbs = safeResolve(
              ctx.session.root,
              `${rel === "." ? "" : rel + "/"}${e.name}/INDEX.md`,
            );
            desc = description(await fsReadFile(idxAbs, "utf8")) ?? "";
          } catch {
            /* no INDEX.md */
          }
          lines.push(`${e.name}/${desc ? ` — ${desc}` : ""}`);
        } else {
          lines.push(e.name);
        }
      }
      return { content: lines.join("\n") || "(empty)" };
    },
  });

  // --- backlinks -----------------------------------------------------------
  const backlinkArgs = z.object({ name: z.string().min(1) });
  tools.push({
    name: "backlinks",
    description:
      "Find every [[wikilink]] pointing at an entity (by file name, e.g. " +
      "'Datadog' or 'NVIDIA'). Reveals what references a company/theme/thesis.",
    parameters: {
      type: "object",
      properties: {
        name: { type: "string", description: "Entity/file name to find links to." },
      },
      required: ["name"],
      additionalProperties: false,
    },
    async handler(raw, ctx) {
      const { name } = backlinkArgs.parse(raw ?? {});
      let links: afs.Backlink[];
      try {
        links = await afs.backlinks(ctx.session.root, name);
      } catch {
        return { content: "Backlinks are unavailable (the afs CLI is not installed)." };
      }
      if (links.length === 0) {
        return { content: `No backlinks to "${name}".` };
      }
      const body = links.map((l) => `${l.source}:${l.line}`).join("\n");
      const seen = new Set<string>();
      const citations: Citation[] = [];
      for (const l of links) {
        if (seen.has(l.source)) continue;
        seen.add(l.source);
        citations.push(fileCitation(l.source, undefined, l.line));
      }
      return {
        content: `${links.length} backlink(s) to "${name}":\n${body}`,
        citations,
      };
    },
  });

  // --- tree ----------------------------------------------------------------
  tools.push({
    name: "tree",
    description:
      "Show the whole instance directory tree with one-line descriptions and " +
      "freshness. Good for orienting before searching. Use list_dir to inspect " +
      "one directory.",
    parameters: { type: "object", properties: {}, additionalProperties: false },
    async handler(_raw, ctx) {
      const text = await afs.tree(ctx.session.root);
      const capped =
        text.length > 12_000 ? text.slice(0, 12_000) + "\n… (truncated)" : text;
      return { content: capped };
    },
  });

  // --- git inspection (read-only; always available) ------------------------
  tools.push({
    name: "git_status",
    description:
      "Show the working-tree status of the knowledge base (which files the " +
      "agent has changed but not yet committed). Use before committing.",
    parameters: { type: "object", properties: {}, additionalProperties: false },
    async handler(_raw, ctx) {
      const st = await git.status(ctx.session.root);
      return { content: st || "Working tree clean — no uncommitted changes." };
    },
  });

  const diffArgs = z.object({ path: z.string().optional() });
  tools.push({
    name: "git_diff",
    description:
      "Show a unified diff of uncommitted changes (optionally for one path). " +
      "Use to review edits before committing.",
    parameters: {
      type: "object",
      properties: {
        path: { type: "string", description: "Limit the diff to this instance-relative path." },
      },
      additionalProperties: false,
    },
    async handler(raw, ctx) {
      const args = diffArgs.parse(raw ?? {});
      const d = await git.diff(ctx.session.root, args.path);
      const capped = d.length > 12_000 ? d.slice(0, 12_000) + "\n… (truncated)" : d;
      return { content: capped || "No uncommitted changes." };
    },
  });

  // git_pull is redundant once run_bash exists (the agent just runs `git pull`),
  // so it's only registered when there's no shell.
  if (!cfg.allowShell) {
    tools.push({
      name: "git_pull",
      description:
        "Update this checkout from the hub (fast-forward). Use when a heads-up " +
        "says the hub has newer commits, or before editing if the checkout might " +
        "be stale, so you're working against the latest knowledge.",
      parameters: { type: "object", properties: {}, additionalProperties: false },
      async handler(_raw, ctx) {
        const out = await git.pull(ctx.session.root);
        clearFreshness(ctx.session.root);
        return { content: out };
      },
    });
  }

  // --- run_bash (arbitrary shell; gated on the dedicated allowShell flag) ---
  if (cfg.allowShell) {
    const bashArgs = z.object({
      command: z.string().min(1),
      timeout_seconds: z.number().int().positive().max(600).optional(),
    });
    tools.push({
      name: "run_bash",
      description:
        "Run a shell command. cwd is your workspace root (which contains each " +
        "knowledge base as a subdirectory); `cd` into a repo to run git/afs " +
        "there. Returns combined stdout+stderr and the exit code (truncated). " +
        "Use this for `afs` subcommands (`afs hub list`, `afs hub pull <slug>` to " +
        "add or refresh a knowledge base), git plumbing (status/diff/pull/commit/" +
        "push), and cross-repo `ls`/`rg`. Prefer the structured tools " +
        "(search_wiki/read_file/grep/tree) when they suffice — they cite sources.",
      mutating: true,
      parameters: {
        type: "object",
        properties: {
          command: { type: "string", description: "The shell command to run." },
          timeout_seconds: {
            type: "number",
            description: "Max seconds before the command is killed (default 60).",
          },
        },
        required: ["command"],
        additionalProperties: false,
      },
      async handler(raw, ctx) {
        const args = bashArgs.parse(raw ?? {});
        const cwd = cfg.workspaceDir ?? ctx.session.root;
        const { output } = await runShell(cwd, args.command, {
          timeoutMs: (args.timeout_seconds ?? 60) * 1000,
        });
        const safe = redactSecrets(output);
        const capped =
          safe.length > 12_000 ? safe.slice(0, 12_000) + "\n… (truncated)" : safe;
        return { content: capped };
      },
    });
  }

  // --- workspace tools (choose / switch the active knowledge base) ----------
  if (cfg.mode === "workspace") {
    tools.push({
      name: "list_repos",
      description:
        "List the knowledge bases (AgentsFS repos) available in this workspace, " +
        "with a one-line description of each. Call this to see what you can work " +
        "with, e.g. after the user asks or after `afs hub pull` adds a new one.",
      parameters: { type: "object", properties: {}, additionalProperties: false },
      async handler(_raw, ctx) {
        const found = discoverInstances(cfg.searchDir);
        if (found.length === 0) {
          return {
            content:
              "No knowledge bases in this workspace yet. Use run_bash with " +
              "`afs hub list` to see what's on the hub and `afs hub pull <slug>` " +
              "to add one.",
          };
        }
        const active = basename(ctx.session.root);
        const lines = found.map((i) => {
          const d = repoDescription(i.path);
          return `- ${i.name}${i.name === active ? " (current)" : ""}${d ? ` — ${d}` : ""}`;
        });
        return { content: `Knowledge bases here:\n${lines.join("\n")}` };
      },
    });

    tools.push({
      name: "focus_repo",
      description:
        "Focus a knowledge base so your structured tools (search_wiki, read_file, " +
        "tree, grep) operate on it. Pass the repo name from list_repos. Takes " +
        "effect IMMEDIATELY — right after this returns, read/search from the new " +
        "KB in the SAME turn (use plain paths relative to it). Call this whenever " +
        "the user names or switches to a different knowledge base.",
      parameters: {
        type: "object",
        properties: {
          repo: { type: "string", description: "Repo name (from list_repos)." },
        },
        required: ["repo"],
        additionalProperties: false,
      },
      async handler(raw, ctx) {
        const repo = z.object({ repo: z.string().min(1) }).parse(raw ?? {}).repo;
        if (!ctx.focusRepo) {
          return { content: "Focusing isn't available in this session." };
        }
        try {
          const { name } = await ctx.focusRepo(repo);
          return {
            content: `Focused on "${name}". Your search/read tools now operate on it — read from it right away.`,
          };
        } catch (e) {
          return { content: `Couldn't focus "${repo}": ${(e as Error).message}` };
        }
      },
    });

    // Create a brand-new knowledge base on request (workspace + writes).
    if (cfg.allowWrites) {
      const createArgs = z.object({
        name: z.string().min(1),
        description: z.string().optional(),
      });
      tools.push({
        name: "create_repo",
        description:
          "Create a BRAND-NEW AgentsFS knowledge base in this workspace and focus " +
          "it. Use when the user asks to start a new knowledge base / notebook / " +
          "space for a topic. Pass a short slug name (lowercase-with-hyphens) and a " +
          "one-line description. It runs `afs init`, publishes it to the hub, and " +
          "switches you into it so you can start adding notes immediately.",
        mutating: true,
        parameters: {
          type: "object",
          properties: {
            name: { type: "string", description: "Short slug, e.g. 'trip-japan-2027'." },
            description: { type: "string", description: "One-line description of the KB." },
          },
          required: ["name"],
          additionalProperties: false,
        },
        async handler(raw, ctx) {
          const args = createArgs.parse(raw ?? {});
          const slug = args.name.trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "");
          if (!slug) return { content: "Give the knowledge base a name (letters, digits, hyphens)." };
          const wsDir = cfg.workspaceDir ?? dirname(ctx.session.root);
          const dir = join(wsDir, slug);
          if (existsSync(dir)) return { content: `A knowledge base named "${slug}" already exists.` };

          const init = await runShell(wsDir, `afs init "${slug}" --yes`, { timeoutMs: 60_000 });
          if (init.code !== 0 || !existsSync(dir)) {
            return { content: `Couldn't create it: ${redactSecrets(init.output).slice(0, 400)}` };
          }
          if (args.description) {
            try {
              const p = join(dir, "AGENTS.md");
              const desc = args.description.replace(/\s+/g, " ").slice(0, 200);
              writeFileSync(p, readFileSync(p, "utf8").replace(/^description:.*$/m, `description: ${desc}`));
            } catch { /* keep the default description */ }
          }
          // Publish to the hub (best effort — never blocks the create).
          const push = await runShell(
            dir,
            `git add -A && git -c user.name="AgentsFS Agent" -c user.email="agent@agentsfs.ai" commit -q -m "Describe knowledge base" >/dev/null 2>&1; afs hub push "${slug}"`,
            { timeoutMs: 120_000 },
          );
          const published = push.code === 0 ? " and published it to your hub" : " (couldn't push to the hub yet — run `afs hub push` later)";
          let focusNote = "";
          if (ctx.focusRepo) {
            try {
              await ctx.focusRepo(slug);
              focusNote = ` You're now focused on "${slug}" — ready for notes.`;
            } catch { /* it exists; focus is best-effort */ }
          }
          return { content: `Created a new knowledge base "${slug}"${published}.${focusNote}` };
        },
      });
    }
  }

  // --- write tools (mutating; gated on allowWrites) ------------------------
  if (cfg.allowWrites) {
    const writeArgs = z.object({ path: z.string().min(1), content: z.string() });
    tools.push({
      name: "write_file",
      description:
        "Create or overwrite a file in the knowledge base with full content. " +
        "For markdown notes, include YAML frontmatter with a one-line " +
        "`description:` and use [[wikilinks]] to related notes, per the AGENTS.md " +
        "contract. To change part of an existing file, prefer edit_file. After a " +
        "meaningful unit of work, git_commit.",
      mutating: true,
      parameters: {
        type: "object",
        properties: {
          path: { type: "string", description: "Instance-relative file path (e.g. people/Akshay.md)." },
          content: { type: "string", description: "The full UTF-8 file content." },
        },
        required: ["path", "content"],
        additionalProperties: false,
      },
      async handler(raw, ctx) {
        const args = writeArgs.parse(raw ?? {});
        const written = await writeFileSafe(ctx.session.root, args.path, args.content);
        return {
          content: `Wrote ${written} (${args.content.length} chars). Uncommitted — call git_commit when done.`,
          citations: [fileCitation(written)],
        };
      },
    });

    const editArgs = z.object({
      path: z.string().min(1),
      old_text: z.string().min(1),
      new_text: z.string(),
      replace_all: z.boolean().optional(),
    });
    tools.push({
      name: "edit_file",
      description:
        "Replace an exact substring in an existing file. old_text must match " +
        "exactly and be unique (unless replace_all). Read the file first and " +
        "copy the exact text. Preferred over write_file for surgical changes.",
      mutating: true,
      parameters: {
        type: "object",
        properties: {
          path: { type: "string", description: "Instance-relative file path." },
          old_text: { type: "string", description: "Exact text to replace (must be unique unless replace_all)." },
          new_text: { type: "string", description: "Replacement text." },
          replace_all: { type: "boolean", description: "Replace every occurrence (default false)." },
        },
        required: ["path", "old_text", "new_text"],
        additionalProperties: false,
      },
      async handler(raw, ctx) {
        const args = editArgs.parse(raw ?? {});
        const res = await editFileSafe(
          ctx.session.root,
          args.path,
          args.old_text,
          args.new_text,
          args.replace_all ?? false,
        );
        return {
          content: `Edited ${res.path} (${res.replacements} replacement${res.replacements === 1 ? "" : "s"}). Uncommitted — call git_commit when done.`,
          citations: [fileCitation(res.path)],
        };
      },
    });

    // git commit/push are redundant with run_bash; when the shell is on, the
    // agent commits/pushes via bash and these structured tools are dropped.
    if (!cfg.allowShell) {
    const commitArgs = z.object({ message: z.string().min(1) });
    tools.push({
      name: "git_commit",
      description:
        "Stage all changes and commit them with a clear, specific message " +
        "(imperative mood, e.g. 'Add Akshay travel preferences'). Do this after " +
        "a coherent unit of work so each change is a reviewable git commit.",
      mutating: true,
      parameters: {
        type: "object",
        properties: {
          message: { type: "string", description: "Commit message." },
        },
        required: ["message"],
        additionalProperties: false,
      },
      async handler(raw, ctx) {
        const args = commitArgs.parse(raw ?? {});
        const res = await git.commitAll(ctx.session.root, args.message, {
          name: cfg.agentName,
          email: cfg.agentEmail,
        });
        return {
          content: res.committed ? `Committed ${res.sha}: ${args.message}` : res.summary,
        };
      },
    });

    tools.push({
      name: "git_push",
      description:
        "Push committed changes to the hub/remote so they're backed up and " +
        "visible everywhere. Only after committing, and typically when the user " +
        "asks to save/sync/publish.",
      mutating: true,
      parameters: { type: "object", properties: {}, additionalProperties: false },
      async handler(_raw, ctx) {
        const out = await git.push(ctx.session.root);
        return { content: out };
      },
    });
    } // end if (!cfg.allowShell)
  }

  // --- capability-gated structured tools -----------------------------------
  tools.push(...buildStructuredTools(caps));

  const byName = new Map(tools.map((t) => [t.name, t]));
  return { tools, byName };
}
