import type { Config } from "../config.js";
import type { Capabilities } from "../agentsfs/capabilities.js";

/**
 * One provenance pointer behind an answer. `file` citations are clickable in the
 * UI (they open the underlying AgentsFS file); `url` citations are external
 * sources pulled from a file's frontmatter or body.
 */
export interface Citation {
  type: "file" | "url";
  /** Instance-relative path for file citations. */
  path?: string;
  /** Absolute URL for url citations. */
  url?: string;
  /** Human label (defaults to the path/url). */
  label?: string;
  /** Optional line number for grep/backlink hits. */
  line?: number;
}

export interface ToolResult {
  /** Text returned to the model. */
  content: string;
  /** Provenance surfaced to the user; aggregated across the turn. */
  citations?: Citation[];
}

export interface ToolContext {
  cfg: Config;
  caps: Capabilities;
}

/** A JSON Schema object for tool parameters. */
export type JsonSchema = Record<string, unknown>;

export interface Tool {
  name: string;
  description: string;
  parameters: JsonSchema;
  /** True for tools that change the wiki (write/edit/commit/push). Gated on
   *  cfg.allowWrites and surfaced distinctly in the UI. */
  mutating?: boolean;
  handler: (args: Record<string, unknown>, ctx: ToolContext) => Promise<ToolResult>;
}

export interface ToolRegistry {
  tools: Tool[];
  byName: Map<string, Tool>;
}

export function citationKey(c: Citation): string {
  return `${c.type}:${c.path ?? c.url ?? ""}${c.line ? `:${c.line}` : ""}`;
}

export function dedupeCitations(citations: Citation[]): Citation[] {
  const seen = new Set<string>();
  const out: Citation[] = [];
  for (const c of citations) {
    const k = citationKey(c);
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(c);
  }
  return out;
}
