import { readFile as fsReadFile } from "node:fs/promises";
import { z } from "zod";
import type { Capabilities } from "../agentsfs/capabilities.js";
import { readFile, safeResolve } from "../agentsfs/files.js";
import { extractSources } from "../agentsfs/frontmatter.js";
import type { Citation, Tool } from "./types.js";

/**
 * Capability-gated structured tools. These only exist when the AgentsFS
 * instance exposes the matching convention (here: the stocks thesis table). A
 * plain notes vault never sees them. Add more detectors in capabilities.ts and
 * more tools here as AgentsFS grows.
 */

interface ThesisRow {
  thesis_id?: string;
  title?: string;
  description?: string;
  stance?: string;
  conviction?: string;
  status?: string;
  horizon?: string;
  implementation_type?: string;
  instruments?: string[];
  thesis_file?: string;
  what_to_watch?: string;
  why?: string;
}

async function loadTheses(root: string, jsonRel: string): Promise<ThesisRow[]> {
  const abs = safeResolve(root, jsonRel);
  const raw = await fsReadFile(abs, "utf8");
  const parsed = JSON.parse(raw);
  return Array.isArray(parsed) ? (parsed as ThesisRow[]) : [];
}

function formatRow(r: ThesisRow): string {
  const parts = [
    `- ${r.title ?? r.thesis_id ?? "(untitled)"}`,
    r.stance ? `[${r.stance}]` : "",
    r.conviction ? `conviction=${r.conviction}` : "",
    r.status ? `status=${r.status}` : "",
    r.horizon ? `horizon=${r.horizon}` : "",
    r.instruments?.length ? `instruments=${r.instruments.join(",")}` : "",
  ].filter(Boolean);
  let line = parts.join(" ");
  if (r.thesis_id) line += `\n  id: ${r.thesis_id}`;
  return line;
}

export function buildStructuredTools(caps: Capabilities): Tool[] {
  if (!caps.thesesJsonPath) return [];
  const jsonRel = caps.thesesJsonPath;
  const tools: Tool[] = [];

  const listArgs = z.object({
    stance: z.string().optional(),
    instrument: z.string().optional(),
    status: z.string().optional(),
    limit: z.number().int().positive().max(200).optional(),
  });

  tools.push({
    name: "list_theses",
    description:
      "List the current actionable investment theses (buy/avoid/short/etc.) " +
      "with stance, conviction, status, and instruments. Optionally filter by " +
      "stance, instrument ticker, or status. Use get_thesis to read the full " +
      "rationale for one.",
    parameters: {
      type: "object",
      properties: {
        stance: {
          type: "string",
          description: "Filter by stance, e.g. buy, avoid, short, trim, add.",
        },
        instrument: {
          type: "string",
          description: "Filter to theses referencing this ticker, e.g. NVDA.",
        },
        status: {
          type: "string",
          description: "Filter by lifecycle status, e.g. active.",
        },
        limit: { type: "number", description: "Max rows (default 50)." },
      },
      additionalProperties: false,
    },
    async handler(rawArgs, ctx) {
      const args = listArgs.parse(rawArgs ?? {});
      let rows = await loadTheses(ctx.cfg.agentsfsRoot, jsonRel);
      if (args.stance) {
        const s = args.stance.toLowerCase();
        rows = rows.filter((r) => (r.stance ?? "").toLowerCase() === s);
      }
      if (args.status) {
        const s = args.status.toLowerCase();
        rows = rows.filter((r) => (r.status ?? "").toLowerCase() === s);
      }
      if (args.instrument) {
        const t = args.instrument.toUpperCase();
        rows = rows.filter((r) =>
          (r.instruments ?? []).some((i) => i.toUpperCase() === t),
        );
      }
      const limit = args.limit ?? 50;
      const shown = rows.slice(0, limit);
      const header = `${rows.length} thesis/theses${
        shown.length < rows.length ? ` (showing ${shown.length})` : ""
      }:`;
      const body = shown.map(formatRow).join("\n");
      const citations: Citation[] = [
        { type: "file", path: jsonRel, label: "thesis table" },
      ];
      return { content: `${header}\n${body}`, citations };
    },
  });

  const getArgs = z.object({ query: z.string().min(1) });

  tools.push({
    name: "get_thesis",
    description:
      "Read the full text of one thesis. Match by thesis_id, an instrument " +
      "ticker it acts on, or a substring of its title.",
    parameters: {
      type: "object",
      properties: {
        query: {
          type: "string",
          description: "thesis_id, ticker, or title substring.",
        },
      },
      required: ["query"],
      additionalProperties: false,
    },
    async handler(rawArgs, ctx) {
      const { query } = getArgs.parse(rawArgs ?? {});
      const rows = await loadTheses(ctx.cfg.agentsfsRoot, jsonRel);
      const q = query.trim();
      const qUpper = q.toUpperCase();
      const qLower = q.toLowerCase();

      const match =
        rows.find((r) => r.thesis_id === q) ??
        rows.find((r) =>
          (r.instruments ?? []).some((i) => i.toUpperCase() === qUpper),
        ) ??
        rows.find((r) => (r.title ?? "").toLowerCase().includes(qLower)) ??
        rows.find((r) => (r.description ?? "").toLowerCase().includes(qLower));

      if (!match || !match.thesis_file) {
        return {
          content: `No thesis matched "${query}". Try list_theses to see available ones.`,
        };
      }
      // thesis_file may be stored repo-relative (e.g. "agentsfs/stocks/...") or
      // already instance-relative. Try as-is, then with the first path segment
      // stripped — no hardcoded prefix, so it works across instances.
      const candidates = [
        match.thesis_file,
        match.thesis_file.replace(/^[^/]+\//, ""),
      ];
      for (const rel of candidates) {
        try {
          const file = await readFile(ctx.cfg.agentsfsRoot, rel);
          const citations: Citation[] = [
            { type: "file", path: file.path, label: match.title ?? rel },
          ];
          for (const s of extractSources(file.content).slice(0, 12)) {
            if (/^https?:\/\//.test(s)) citations.push({ type: "url", url: s });
          }
          return { content: file.content, citations };
        } catch {
          /* try the next candidate path */
        }
      }
      // Fall back to the snapshot fields if the file is missing/renamed.
      const summary = [
        `# ${match.title ?? match.thesis_id}`,
        match.description ? `\n${match.description}` : "",
        match.why ? `\n## Why\n${match.why}` : "",
        match.what_to_watch ? `\n## What to watch\n${match.what_to_watch}` : "",
      ].join("\n");
      return {
        content: summary,
        citations: [{ type: "file", path: jsonRel, label: "thesis table" }],
      };
    },
  });

  return tools;
}
