/**
 * Best-effort price table for cost estimation in logs, $ per 1M tokens (June
 * 2026). Audio rates dominate realtime cost. The gpt-5.x text rates are
 * ESTIMATES (not published on the model page at time of writing) — edit these to
 * match your actual OpenAI plan. Cost figures in logs are labelled "~est".
 */
export interface ModelPrice {
  inputPerM: number;
  outputPerM: number;
  audioInPerM?: number;
  audioOutPerM?: number;
}

export const PRICING: Record<string, ModelPrice> = {
  // Reasoning / chat (text). Estimates — adjust to your plan.
  "gpt-5.1": { inputPerM: 2.5, outputPerM: 10 },
  "gpt-5": { inputPerM: 2.5, outputPerM: 10 },
  "gpt-4.1": { inputPerM: 2.0, outputPerM: 8 },
  "gpt-4o-mini": { inputPerM: 0.15, outputPerM: 0.6 },
  // Realtime (voice). gpt-realtime confirmed; mini audio from a secondary source.
  "gpt-realtime-mini": { inputPerM: 0.6, outputPerM: 2.4, audioInPerM: 10, audioOutPerM: 20 },
  "gpt-realtime": { inputPerM: 4, outputPerM: 24, audioInPerM: 32, audioOutPerM: 64 },
};

/** Longest-prefix match so dated snapshots (gpt-5.1-2025-…) resolve. */
export function priceFor(model: string): ModelPrice | undefined {
  if (PRICING[model]) return PRICING[model];
  const keys = Object.keys(PRICING).sort((a, b) => b.length - a.length);
  for (const k of keys) if (model.startsWith(k)) return PRICING[k];
  return undefined;
}

/** Estimated USD for a text turn. Returns null if the model isn't priced. */
export function estimateTextCostUsd(
  model: string,
  inputTokens: number,
  outputTokens: number,
): number | null {
  const p = priceFor(model);
  if (!p) return null;
  return (inputTokens * p.inputPerM + outputTokens * p.outputPerM) / 1_000_000;
}

/** Format a small USD figure for logs/UI (e.g. $0.0123). */
export function fmtUsd(usd: number): string {
  return `$${usd < 0.01 ? usd.toFixed(4) : usd.toFixed(3)}`;
}
