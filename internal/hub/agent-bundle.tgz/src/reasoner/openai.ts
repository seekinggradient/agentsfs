import OpenAI from "openai";
import type { Config } from "../config.js";
import type {
  ChatMessage,
  Reasoner,
  RunTurnOptions,
  ToolSpec,
  TurnResult,
  Usage,
} from "./types.js";

/**
 * OpenAI reasoner on the Responses API. Uses an agentic loop that streams the
 * final answer while resolving tool calls across rounds. Handles the gpt-5.x /
 * o-series parameter rules (no temperature; reasoning.effort + verbosity) and
 * standard models (temperature) so requests never 400 on the wrong params.
 */

const DEFAULT_MAX_ITERATIONS = 8;
const MAX_OUTPUT_TOKENS = 4000;

function isReasoningModel(model: string): boolean {
  return /^(gpt-5|o\d)/i.test(model);
}

type ModelParams = Record<string, unknown>;

function modelParams(model: string, cfg: Config): ModelParams {
  if (isReasoningModel(model)) {
    let effort = cfg.reasoningEffort;
    // xhigh is gpt-5.5-only; o-series has no "none".
    if (effort === "xhigh" && !/^gpt-5\.5/i.test(model)) effort = "high";
    if (effort === "none" && /^o\d/i.test(model)) effort = "low";
    return {
      reasoning: { effort },
      text: { verbosity: cfg.verbosity },
    };
  }
  // Standard model (e.g. gpt-4.1): supports temperature, no reasoning/verbosity.
  return { temperature: 0.2 };
}

function toResponseTools(tools: ToolSpec[]): OpenAI.Responses.Tool[] {
  return tools.map((t) => ({
    type: "function",
    name: t.name,
    description: t.description,
    parameters: t.parameters as Record<string, unknown>,
    strict: false,
  })) as OpenAI.Responses.Tool[];
}

/**
 * Strip SDK-only fields before replaying streamed output items as input. The
 * streaming parser adds `parsed_arguments` to function_call items and the API
 * rejects it ("Unknown parameter: input[n].parsed_arguments"); `created_by` is
 * likewise output-only.
 */
function sanitizeForReplay(
  items: OpenAI.Responses.ResponseOutputItem[],
): OpenAI.Responses.ResponseInputItem[] {
  return items.map((it) => {
    const rec = { ...(it as unknown as Record<string, unknown>) };
    delete rec["parsed_arguments"];
    delete rec["created_by"];
    return rec as unknown as OpenAI.Responses.ResponseInputItem;
  });
}

function historyToInput(
  history: ChatMessage[],
  userMessage: string,
): OpenAI.Responses.ResponseInputItem[] {
  const items: OpenAI.Responses.ResponseInputItem[] = history.map((m) => ({
    role: m.role,
    content: m.content,
  }));
  items.push({ role: "user", content: userMessage });
  return items;
}

export class OpenAIReasoner implements Reasoner {
  readonly name = "openai";
  /** Advertised primary model. Fallback is decided per-turn, not sticky. */
  readonly model: string;
  private readonly fallback: string;
  private readonly client: OpenAI;
  private readonly cfg: Config;

  constructor(cfg: Config) {
    if (!cfg.openaiApiKey) throw new Error("OPENAI_API_KEY is required.");
    this.cfg = cfg;
    this.client = new OpenAI({ apiKey: cfg.openaiApiKey });
    this.model = cfg.chatModel;
    this.fallback = cfg.chatModelFallback;
  }

  async runTurn(opts: RunTurnOptions): Promise<TurnResult> {
    const tools = toResponseTools(opts.tools);
    const input = historyToInput(opts.history, opts.userMessage);
    const maxIters = opts.maxToolIterations ?? DEFAULT_MAX_ITERATIONS;

    // Fallback is per-turn and local: a transient error on one turn must not
    // permanently downgrade the model for the lifetime of the process.
    let activeModel = this.model;
    let triedFallback = false;
    let answer = "";
    let toolCallCount = 0;
    const usage: Usage = { inputTokens: 0, outputTokens: 0 };

    for (let iter = 0; iter < maxIters; iter++) {
      // On the last allowed iteration, force a final answer (no more tools).
      const forceAnswer = iter === maxIters - 1;

      const round = await this.runRound(
        input,
        tools,
        opts,
        forceAnswer,
        activeModel,
        !triedFallback,
      );
      activeModel = round.model;
      if (round.usedFallback) triedFallback = true;
      usage.inputTokens += round.usage.inputTokens;
      usage.outputTokens += round.usage.outputTokens;

      const functionCalls = round.output.filter(
        (o): o is OpenAI.Responses.ResponseFunctionToolCall =>
          (o as { type?: string }).type === "function_call",
      );

      // Replay all output items (incl. reasoning) so the next round has context,
      // sanitized of SDK-only fields the API would reject.
      input.push(...sanitizeForReplay(round.output));

      if (functionCalls.length === 0) {
        // Terminal round: its streamed text is the real answer.
        answer = round.text;
        break;
      }

      // A tool-calling round may also emit interim "let me look that up" prose.
      // That was streamed live, so tell the caller to discard it — only the
      // terminal round's text is the answer.
      if (round.text) opts.onReset?.();

      for (const fc of functionCalls) {
        toolCallCount++;
        let args: Record<string, unknown> = {};
        try {
          args = fc.arguments ? JSON.parse(fc.arguments) : {};
        } catch {
          args = {};
        }
        opts.onToolCall?.(fc.name, args);
        let result: string;
        try {
          result = await opts.executeTool(fc.name, args);
        } catch (e) {
          result = `ERROR: ${(e as Error).message}`;
        }
        input.push({
          type: "function_call_output",
          call_id: fc.call_id,
          output: typeof result === "string" ? result : JSON.stringify(result),
        });
      }
    }

    if (!answer.trim()) answer = "I couldn't produce an answer for that.";
    return { text: answer, toolCallCount, model: activeModel, usage };
  }

  private buildParams(
    model: string,
    input: OpenAI.Responses.ResponseInputItem[],
    tools: OpenAI.Responses.Tool[],
    opts: RunTurnOptions,
    forceAnswer: boolean,
  ): OpenAI.Responses.ResponseCreateParamsStreaming {
    // Built fresh per model so family-specific params (reasoning/verbosity vs
    // temperature) never leak across a fallback and 400 the request.
    return {
      model,
      instructions: opts.system,
      input,
      tools,
      tool_choice: forceAnswer ? "none" : "auto",
      max_output_tokens: MAX_OUTPUT_TOKENS,
      ...modelParams(model, this.cfg),
    } as OpenAI.Responses.ResponseCreateParamsStreaming;
  }

  /** Run one streamed model round, with a single per-turn fallback on hard
   *  (non-abort) errors. Returns the model actually used. */
  private async runRound(
    input: OpenAI.Responses.ResponseInputItem[],
    tools: OpenAI.Responses.Tool[],
    opts: RunTurnOptions,
    forceAnswer: boolean,
    model: string,
    allowFallback: boolean,
  ): Promise<{
    output: OpenAI.Responses.ResponseOutputItem[];
    text: string;
    usage: Usage;
    model: string;
    usedFallback: boolean;
  }> {
    try {
      const r = await this.consumeStream(this.buildParams(model, input, tools, opts, forceAnswer), opts);
      return { ...r, model, usedFallback: false };
    } catch (e) {
      // Never "recover" from a client-initiated abort by spawning more work.
      if (opts.signal?.aborted || (e as Error)?.name === "AbortError") throw e;
      if (allowFallback && this.fallback && this.fallback !== model) {
        const r = await this.consumeStream(
          this.buildParams(this.fallback, input, tools, opts, forceAnswer),
          opts,
        );
        return { ...r, model: this.fallback, usedFallback: true };
      }
      throw e;
    }
  }

  private async consumeStream(
    params: OpenAI.Responses.ResponseCreateParamsStreaming,
    opts: RunTurnOptions,
  ): Promise<{
    output: OpenAI.Responses.ResponseOutputItem[];
    text: string;
    usage: Usage;
  }> {
    const stream = this.client.responses.stream(params);
    if (opts.signal) {
      if (opts.signal.aborted) stream.abort();
      else opts.signal.addEventListener("abort", () => stream.abort(), {
        once: true,
      });
    }

    let text = "";
    stream.on("response.output_text.delta", (e) => {
      const delta = (e as { delta?: string }).delta ?? "";
      if (delta) {
        text += delta;
        opts.onTextDelta?.(delta);
      }
    });

    const final = await stream.finalResponse();
    const usage: Usage = {
      inputTokens: final.usage?.input_tokens ?? 0,
      outputTokens: final.usage?.output_tokens ?? 0,
    };
    return { output: final.output ?? [], text, usage };
  }
}
