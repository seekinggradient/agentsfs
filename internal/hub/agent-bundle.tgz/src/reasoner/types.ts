/**
 * Provider-agnostic reasoner. The agentic tool-loop and conversation-state
 * management are provider-specific (OpenAI Responses replays reasoning items;
 * Anthropic uses tool_use/tool_result blocks), so the Reasoner owns the whole
 * turn and calls back into `executeTool`. Swapping providers means adding one
 * implementation of this interface — nothing above it changes.
 */

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export interface ToolSpec {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
}

export interface RunTurnOptions {
  /** System prompt / instructions. */
  system: string;
  /** Prior conversation turns (provider-neutral). */
  history: ChatMessage[];
  /** The new user message. */
  userMessage: string;
  tools: ToolSpec[];
  /** Execute a tool and return its textual result for the model. */
  executeTool: (name: string, args: Record<string, unknown>) => Promise<string>;
  /** Stream the final answer text to the caller, token by token. */
  onTextDelta?: (delta: string) => void;
  /** Discard any text streamed so far this turn: a pre-tool round emitted
   *  interim prose that is not the final answer. The caller should clear the
   *  in-progress assistant text. */
  onReset?: () => void;
  /** Notified when the model decides to call a tool. */
  onToolCall?: (name: string, args: Record<string, unknown>) => void;
  signal?: AbortSignal;
  /** Hard cap on tool rounds before forcing a final answer. */
  maxToolIterations?: number;
}

export interface Usage {
  inputTokens: number;
  outputTokens: number;
}

export interface TurnResult {
  text: string;
  toolCallCount: number;
  model: string;
  /** Token usage summed across all rounds of the turn, if the provider reports it. */
  usage?: Usage;
}

export interface Reasoner {
  readonly name: string;
  readonly model: string;
  runTurn(opts: RunTurnOptions): Promise<TurnResult>;
}
