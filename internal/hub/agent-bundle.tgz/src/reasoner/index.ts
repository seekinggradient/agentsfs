import type { Config } from "../config.js";
import { OpenAIReasoner } from "./openai.js";
import type { Reasoner } from "./types.js";

export type { Reasoner, RunTurnOptions, ChatMessage, ToolSpec, TurnResult } from "./types.js";

/**
 * Build the reasoner for the configured provider. OpenAI is implemented today;
 * the interface is provider-agnostic, so adding `anthropic.ts` (a Claude
 * implementation of {@link Reasoner}) is the only change needed to honor the
 * "Realtime + Claude hand-off" design once an ANTHROPIC_API_KEY is available.
 */
export function createReasoner(cfg: Config): Reasoner {
  switch (cfg.provider) {
    case "openai":
      return new OpenAIReasoner(cfg);
    case "anthropic":
      throw new Error(
        "Anthropic reasoner not yet implemented. The Reasoner interface is " +
          "ready — add src/reasoner/anthropic.ts and wire it here. For now, " +
          "unset ANTHROPIC_API_KEY to use OpenAI.",
      );
    default:
      throw new Error(`Unknown provider: ${cfg.provider}`);
  }
}
