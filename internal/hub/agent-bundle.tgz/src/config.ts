import { existsSync, statSync } from "node:fs";
import { dirname, resolve } from "node:path";
import dotenv from "dotenv";

dotenv.config();

export type Provider = "openai" | "anthropic";
export type ReasoningEffort = "none" | "low" | "medium" | "high" | "xhigh";
export type Verbosity = "low" | "medium" | "high";
export type Vad = "semantic" | "server";

export interface Config {
  /** Absolute path to the AgentsFS instance being served. */
  agentsfsRoot: string;
  /** Display name for the instance (topbar + prompt). Defaults to the root
   *  folder name; set AGENTSFS_NAME to override (e.g. the hub repo name, since
   *  the sprite clones into a generic "wiki" directory). */
  name?: string;
  /** Directory scanned to discover other AgentsFS instances for the picker. */
  searchDir: string;
  /** Which LLM provider backs the reasoner + voice hand-off. */
  provider: Provider;
  openaiApiKey?: string;
  anthropicApiKey?: string;
  /** Primary model for the chat agent / consult_knowledge hand-off. */
  chatModel: string;
  /** Faster fallback model if the primary errors. */
  chatModelFallback: string;
  /** Reasoning effort for gpt-5.x/o-series models (ignored by standard models). */
  reasoningEffort: ReasoningEffort;
  /** Output verbosity for gpt-5.x models (ignored by standard models). */
  verbosity: Verbosity;
  /** OpenAI Realtime model id for voice. */
  realtimeModel: string;
  realtimeVoice: string;
  /** Voice turn detection strategy. */
  realtimeVad: Vad;
  port: number;
  /** Interface to bind the server to. Loopback locally; 0.0.0.0 in a sandbox. */
  host: string;
  /** When true, the agent may write/edit files and commit/push (git is the
   *  safety net). When false the agent is read-only (the original behavior). */
  allowWrites: boolean;
  /** Git identity used for the agent's commits. */
  agentName: string;
  agentEmail: string;
}

function detectProvider(): Provider {
  // Anthropic is preferred when available (the user's stated choice for the
  // reasoner). We fall back to OpenAI, which is what is wired today.
  if (process.env.ANTHROPIC_API_KEY) return "anthropic";
  if (process.env.OPENAI_API_KEY) return "openai";
  throw new Error(
    "No LLM key found. Set OPENAI_API_KEY (or ANTHROPIC_API_KEY) in .env.",
  );
}

/**
 * Resolve and validate runtime configuration. `overrides.agentsfsRoot` lets the
 * CLI and tests point at a different instance without mutating the environment.
 */
export function loadConfig(overrides: Partial<Config> = {}): Config {
  const provider = overrides.provider ?? detectProvider();

  const rawRoot = overrides.agentsfsRoot ?? process.env.AGENTSFS_ROOT;
  if (!rawRoot) {
    throw new Error("AGENTSFS_ROOT is not set (path to an AgentsFS instance).");
  }
  const agentsfsRoot = resolve(rawRoot);
  if (!existsSync(agentsfsRoot) || !statSync(agentsfsRoot).isDirectory()) {
    throw new Error(`AGENTSFS_ROOT is not a directory: ${agentsfsRoot}`);
  }

  const searchDir = resolve(
    overrides.searchDir ?? process.env.AGENTSFS_SEARCH_DIR ?? dirname(agentsfsRoot),
  );

  return {
    agentsfsRoot,
    name: overrides.name ?? process.env.AGENTSFS_NAME ?? undefined,
    searchDir,
    provider,
    openaiApiKey: process.env.OPENAI_API_KEY,
    anthropicApiKey: process.env.ANTHROPIC_API_KEY,
    chatModel: overrides.chatModel ?? process.env.CHAT_MODEL ?? "gpt-5.1",
    chatModelFallback:
      overrides.chatModelFallback ??
      process.env.CHAT_MODEL_FALLBACK ??
      "gpt-4.1",
    reasoningEffort:
      overrides.reasoningEffort ??
      (process.env.CHAT_REASONING_EFFORT as ReasoningEffort | undefined) ??
      "low",
    verbosity:
      overrides.verbosity ??
      (process.env.CHAT_VERBOSITY as Verbosity | undefined) ??
      "low",
    realtimeModel:
      overrides.realtimeModel ?? process.env.REALTIME_MODEL ?? "gpt-realtime-mini",
    realtimeVoice:
      overrides.realtimeVoice ?? process.env.REALTIME_VOICE ?? "marin",
    realtimeVad:
      overrides.realtimeVad ??
      (process.env.REALTIME_VAD as Vad | undefined) ??
      "semantic",
    port: overrides.port ?? Number(process.env.PORT ?? 8787),
    host: overrides.host ?? process.env.HOST ?? "127.0.0.1",
    allowWrites:
      overrides.allowWrites ??
      // Writes are opt-in via env; default off preserves the read-only behavior
      // for anyone who just wants chat. The launcher/sandbox sets it on.
      /^(1|true|yes|on)$/i.test(process.env.AGENTSFS_ALLOW_WRITES ?? ""),
    agentName:
      overrides.agentName ?? process.env.AGENTSFS_AGENT_NAME ?? "AgentsFS Agent",
    agentEmail:
      overrides.agentEmail ??
      process.env.AGENTSFS_AGENT_EMAIL ??
      "agent@agentsfs.ai",
  };
}
