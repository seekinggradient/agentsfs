import { existsSync, statSync } from "node:fs";
import { dirname, resolve } from "node:path";
import dotenv from "dotenv";

dotenv.config();

export type Provider = "openai" | "anthropic";
export type ReasoningEffort = "none" | "low" | "medium" | "high" | "xhigh";
export type Verbosity = "low" | "medium" | "high";
export type Vad = "semantic" | "server";

export interface Config {
  /** Absolute path to the AgentsFS instance being served. */
  agentsfsRoot: string;
  /** Display name for the instance (topbar + prompt). Defaults to the root
   *  folder name; set AGENTSFS_NAME to override (e.g. the hub repo name, since
   *  the sprite clones into a generic "wiki" directory). */
  name?: string;
  /** Directory scanned to discover other AgentsFS instances for the picker. */
  searchDir: string;
  /** 'workspace' = a per-user sprite holding many repo checkouts under
   *  workspaceDir; the agent focuses one repo at a time and can switch between
   *  them. 'single' (default) = pinned to one agentsfsRoot (original behavior). */
  mode: "single" | "workspace";
  /** In workspace mode, the parent dir holding every repo checkout (siblings).
   *  run_bash runs from here so `afs hub pull` lands new repos alongside. */
  workspaceDir?: string;
  /** Which LLM provider backs the reasoner + voice hand-off. */
  provider: Provider;
  openaiApiKey?: string;
  anthropicApiKey?: string;
  /** When set, model calls go through this base URL (the hub's authenticated
   *  OpenAI proxy) instead of api.openai.com, and openaiApiKey holds the hub PAT
   *  rather than a real OpenAI key — so no OpenAI key ever lives in the sprite. */
  llmBaseUrl?: string;
  /** Primary model for the chat agent / consult_knowledge hand-off. */
  chatModel: string;
  /** Faster fallback model if the primary errors. */
  chatModelFallback: string;
  /** Reasoning effort for gpt-5.x/o-series models (ignored by standard models). */
  reasoningEffort: ReasoningEffort;
  /** Output verbosity for gpt-5.x models (ignored by standard models). */
  verbosity: Verbosity;
  /** OpenAI Realtime model id for voice. */
  realtimeModel: string;
  realtimeVoice: string;
  /** Voice turn detection strategy. */
  realtimeVad: Vad;
  port: number;
  /** Interface to bind the server to. Loopback locally; 0.0.0.0 in a sandbox. */
  host: string;
  /** When true, the agent may write/edit files and commit/push (git is the
   *  safety net). When false the agent is read-only (the original behavior). */
  allowWrites: boolean;
  /** When true, the agent may run arbitrary shell commands via run_bash. This is
   *  strictly stronger than allowWrites (arbitrary code execution), so it's a
   *  separate opt-in and only safe inside an isolated per-user sprite. */
  allowShell: boolean;
  /** Git identity used for the agent's commits. */
  agentName: string;
  agentEmail: string;
}

function detectProvider(): Provider {
  // Anthropic is preferred when available (the user's stated choice for the
  // reasoner). We fall back to OpenAI, which is what is wired today.
  if (process.env.ANTHROPIC_API_KEY) return "anthropic";
  if (process.env.OPENAI_API_KEY) return "openai";
  throw new Error(
    "No LLM key found. Set OPENAI_API_KEY (or ANTHROPIC_API_KEY) in .env.",
  );
}

/**
 * Resolve and validate runtime configuration. `overrides.agentsfsRoot` lets the
 * CLI and tests point at a different instance without mutating the environment.
 */
export function loadConfig(overrides: Partial<Config> = {}): Config {
  // Proxy mode: model calls go through the hub (which holds the OpenAI key). The
  // sprite authenticates with its per-user PAT (AGENTSFS_LLM_KEY), so there is no
  // OpenAI key to detect or leak.
  const llmBaseUrl = overrides.llmBaseUrl ?? process.env.AGENTSFS_LLM_BASE_URL ?? undefined;
  const proxyKey = process.env.AGENTSFS_LLM_KEY;
  const provider = overrides.provider ?? (llmBaseUrl ? "openai" : detectProvider());

  const rawRoot = overrides.agentsfsRoot ?? process.env.AGENTSFS_ROOT;
  if (!rawRoot) {
    throw new Error("AGENTSFS_ROOT is not set (path to an AgentsFS instance).");
  }
  const agentsfsRoot = resolve(rawRoot);
  if (!existsSync(agentsfsRoot) || !statSync(agentsfsRoot).isDirectory()) {
    throw new Error(`AGENTSFS_ROOT is not a directory: ${agentsfsRoot}`);
  }

  const searchDir = resolve(
    overrides.searchDir ?? process.env.AGENTSFS_SEARCH_DIR ?? dirname(agentsfsRoot),
  );

  const mode: Config["mode"] =
    overrides.mode ??
    (process.env.AGENTSFS_MODE === "workspace" ? "workspace" : "single");
  const workspaceDir =
    mode === "workspace"
      ? resolve(overrides.workspaceDir ?? process.env.AGENTSFS_WORKSPACE ?? searchDir)
      : undefined;

  return {
    agentsfsRoot,
    name: overrides.name ?? process.env.AGENTSFS_NAME ?? undefined,
    searchDir,
    mode,
    workspaceDir,
    provider,
    // In proxy mode the "OpenAI key" is actually the hub PAT (used as the Bearer
    // to the hub proxy); otherwise it's a real OpenAI key.
    openaiApiKey: llmBaseUrl ? proxyKey ?? process.env.OPENAI_API_KEY : process.env.OPENAI_API_KEY,
    anthropicApiKey: process.env.ANTHROPIC_API_KEY,
    llmBaseUrl,
    chatModel: overrides.chatModel ?? process.env.CHAT_MODEL ?? "gpt-5.1",
    chatModelFallback:
      overrides.chatModelFallback ??
      process.env.CHAT_MODEL_FALLBACK ??
      "gpt-4.1",
    reasoningEffort:
      overrides.reasoningEffort ??
      (process.env.CHAT_REASONING_EFFORT as ReasoningEffort | undefined) ??
      "low",
    verbosity:
      overrides.verbosity ??
      (process.env.CHAT_VERBOSITY as Verbosity | undefined) ??
      "low",
    realtimeModel:
      overrides.realtimeModel ?? process.env.REALTIME_MODEL ?? "gpt-realtime-mini",
    realtimeVoice:
      overrides.realtimeVoice ?? process.env.REALTIME_VOICE ?? "marin",
    realtimeVad:
      overrides.realtimeVad ??
      (process.env.REALTIME_VAD as Vad | undefined) ??
      "semantic",
    port: overrides.port ?? Number(process.env.PORT ?? 8787),
    host: overrides.host ?? process.env.HOST ?? "127.0.0.1",
    allowWrites:
      overrides.allowWrites ??
      // Writes are opt-in via env; default off preserves the read-only behavior
      // for anyone who just wants chat. The launcher/sandbox sets it on.
      /^(1|true|yes|on)$/i.test(process.env.AGENTSFS_ALLOW_WRITES ?? ""),
    allowShell:
      overrides.allowShell ??
      // Arbitrary shell is a separate, stronger opt-in than writes; only the
      // isolated per-user sprite sets it on.
      /^(1|true|yes|on)$/i.test(process.env.AGENTSFS_ALLOW_SHELL ?? ""),
    agentName:
      overrides.agentName ?? process.env.AGENTSFS_AGENT_NAME ?? "AgentsFS Agent",
    agentEmail:
      overrides.agentEmail ??
      process.env.AGENTSFS_AGENT_EMAIL ??
      "agent@agentsfs.ai",
  };
}
