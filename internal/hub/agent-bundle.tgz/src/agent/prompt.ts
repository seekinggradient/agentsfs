import { readFile as fsReadFile } from "node:fs/promises";
import { basename, join } from "node:path";
import type { Config } from "../config.js";
import type { Capabilities } from "../agentsfs/capabilities.js";
import { description } from "../agentsfs/frontmatter.js";

export type Mode = "chat" | "voice";

/** Keep only tree lines up to `maxDepth` levels deep, for a compact map. */
export function trimTree(tree: string, maxDepth = 2): string {
  const lines = tree.split("\n");
  const kept: string[] = [];
  for (const line of lines) {
    const idx = line.search(/[├└]/);
    if (idx === -1) {
      kept.push(line); // root line (".")
      continue;
    }
    const depth = Math.floor(idx / 4) + 1;
    if (depth <= maxDepth) kept.push(line);
  }
  return kept.join("\n");
}

export interface PromptContext {
  /** Display name of the instance (its root folder name). */
  instanceName: string;
  /** One-line description from the root AGENTS.md, if any. */
  rootDescription?: string;
  /** Trimmed tree used as the orientation map. */
  map: string;
  caps: Capabilities;
  /** Whether write/edit/commit/push tools are available this session. */
  allowWrites: boolean;
}

/** Read AGENTS.md description + a trimmed tree to orient the model. Done once. */
export async function buildPromptContext(
  cfg: Config,
  caps: Capabilities,
  fullTree: string,
): Promise<PromptContext> {
  let rootDescription: string | undefined;
  try {
    const agents = await fsReadFile(join(cfg.agentsfsRoot, "AGENTS.md"), "utf8");
    rootDescription = description(agents);
  } catch {
    /* no AGENTS.md */
  }
  return {
    instanceName: basename(cfg.agentsfsRoot),
    rootDescription,
    map: trimTree(fullTree, 2),
    caps,
    allowWrites: cfg.allowWrites,
  };
}

const WRITE_RULES = `You can MAINTAIN this knowledge base, not just read it. When the user asks you to record, update, correct, reorganize, or capture knowledge, do the work:
- Use write_file to create a note or edit_file to change part of one. Read a file before editing it and copy exact text.
- Every markdown file starts with YAML frontmatter containing a one-line \`description:\`. Link related entities with [[wikilinks]]. Give a new directory an INDEX.md describing it. Keep notes dense and factual; improve an existing note instead of duplicating it; cite sources.
- After a coherent unit of work, git_commit with a clear, specific message (imperative mood). Make one commit per logical change. When the user asks to save, sync, back up, or publish, git_push.
- git history is the undo, but be deliberate: don't delete or overwrite large content unless asked, and prefer surgical edits. Follow this instance's own AGENTS.md contract if it adds conventions.
Confirm briefly what you changed (files + commit) so the user can see the trail.`;

const BASE_RULES = `Grounding rules:
- Answer ONLY from this knowledge base and your tool results. Do not invent facts.
- If the answer is not in the knowledge base, say so plainly and suggest what to search or read next.
- Cite every material claim with the source file path (and the external URL when the file provides one). Prefer the most specific file. Use the EXACT path a tool returned — never construct, guess, or shorten a path (a thesis_id is not a path).
- Separate evidence (what a source says) from interpretation (what it implies). Preserve uncertainty and note disconfirming evidence when present.
- Start with search_wiki (use semantic=true for conceptual questions), then read_file the most relevant results before answering. Use grep for exact strings, backlinks to see what references an entity.`;

function domainGuidance(caps: Capabilities): string {
  const parts: string[] = [];
  if (caps.domains.includes("stocks")) {
    parts.push(
      "This instance contains market research (companies, beliefs, theses). " +
        "When discussing theses or holdings, this is the system's research and " +
        "reasoning, NOT personalized financial advice. Explain how the view is " +
        "reasoned and what would prove it wrong; never tell the user to buy or " +
        "sell. Use list_theses/get_thesis for actionable thesis questions.",
    );
  }
  if (caps.domains.includes("education")) {
    parts.push(
      "An education/ area holds derived explainers; treat it as teaching " +
        "material, not a source of new market truth.",
    );
  }
  return parts.join("\n");
}

export function buildSystemPrompt(ctx: PromptContext, mode: Mode): string {
  const header =
    `You are a careful research assistant answering questions over an AgentsFS ` +
    `knowledge base named "${ctx.instanceName}"` +
    (ctx.rootDescription ? ` — ${ctx.rootDescription}` : "") +
    `.\n\nAgentsFS is durable markdown memory: every file has YAML frontmatter ` +
    `with a one-line description and often a sources list; directories have an ` +
    `INDEX.md; entities are linked with [[wikilinks]]. You read this knowledge ` +
    `through tools — you cannot see files you have not opened.`;

  const domains = domainGuidance(ctx.caps);

  const map = `Orientation map (top levels; use tree/list_dir/search to go deeper):\n${ctx.map}`;

  if (mode === "voice") {
    return [
      header,
      domains,
      map,
      BASE_RULES,
      ctx.allowWrites ? WRITE_RULES : "",
      `Voice mode: you are being spoken aloud. Answer in 1-4 short, natural ` +
        `spoken sentences — no markdown, no bullet lists, no URLs read aloud. ` +
        `Lead with the answer. Mention at most one or two source names in ` +
        `passing (the screen shows full citations). If the user needs detail, ` +
        `offer to put it on screen.`,
    ]
      .filter(Boolean)
      .join("\n\n");
  }

  return [
    header,
    domains,
    map,
    BASE_RULES,
    ctx.allowWrites ? WRITE_RULES : "",
    `Style: clear and dense, written for a knowledgeable reader. Use short ` +
      `markdown sections or bullets when it aids scanning. End material claims ` +
      `with their source path in parentheses, e.g. (stocks/knowledge/companies/Datadog.md).`,
  ]
    .filter(Boolean)
    .join("\n\n");
}
