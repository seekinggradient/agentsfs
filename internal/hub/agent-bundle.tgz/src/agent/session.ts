import { basename } from "node:path";
import type { Config } from "../config.js";
import { detectCapabilities, type Capabilities } from "../agentsfs/capabilities.js";
import { tree as afsTree } from "../agentsfs/afs.js";
import { primeFreshness, pullHint } from "../agentsfs/freshness.js";
import { redactSecrets } from "../agentsfs/redact.js";

// Tools whose results are knowledge the agent will reason from; a "checkout is
// behind the hub" hint is appended to these so the agent knows to git_pull.
const READ_TOOLS = new Set(["search_wiki", "read_file", "grep", "list_dir", "backlinks", "tree"]);
import { buildToolRegistry } from "../tools/registry.js";
import {
  dedupeCitations,
  type Citation,
  type ToolContext,
  type ToolRegistry,
} from "../tools/types.js";
import { createReasoner } from "../reasoner/index.js";
import type { ChatMessage, Reasoner, ToolSpec, Usage } from "../reasoner/types.js";
import {
  buildPromptContext,
  buildSystemPrompt,
  type Mode,
  type PromptContext,
} from "./prompt.js";

/**
 * The agent: one per AgentsFS instance. Owns the tool registry, the reasoner,
 * and the cached prompt context (instance map + description). `ask()` runs one
 * grounded turn, streaming text and aggregating citations from every tool the
 * model used.
 */

export interface AskOptions {
  message: string;
  history?: ChatMessage[];
  mode?: Mode;
  onTextDelta?: (delta: string) => void;
  onReset?: () => void;
  onToolCall?: (name: string, args: Record<string, unknown>) => void;
  /** Fired when focus_repo changes the active KB mid-turn, so the UI can update
   *  which workspace is shown as active. */
  onInstanceChange?: (name: string) => void;
  signal?: AbortSignal;
}

export interface AskResult {
  text: string;
  citations: Citation[];
  toolCallCount: number;
  model: string;
  usage?: Usage;
}

export interface CreateOpts {
  /** Workspace mode: focus a repo by name. Threaded into ToolContext so the
   *  focus_repo tool can trigger it; it mutates the shared session.root. */
  onFocusRepo?: (target: string) => Promise<{ name: string }>;
  /** Shared, mutable active-root box. In workspace mode the server owns it and
   *  mutates `.root` on focus, so a switch is seen live by tools and by the next
   *  turn's prompt. Defaults to { root: cfg.agentsfsRoot } (single mode). */
  session?: { root: string };
}

export class Agent {
  /** Orientation prompt per root, so switching between KBs doesn't re-pay the
   *  afs tree read every turn. */
  private readonly promptCache = new Map<string, PromptContext>();

  private constructor(
    readonly cfg: Config,
    private readonly registry: ToolRegistry,
    private readonly reasoner: Reasoner,
    /** The live active-root box, shared with the server. Read every turn. */
    private readonly session: { root: string },
    private readonly onFocusRepo?: (target: string) => Promise<{ name: string }>,
  ) {}

  static async create(
    cfg: Config,
    reasoner?: Reasoner,
    opts: CreateOpts = {},
  ): Promise<Agent> {
    const session = opts.session ?? { root: cfg.agentsfsRoot };
    const registry = buildToolRegistry(cfg);
    const r = reasoner ?? createReasoner(cfg);
    const agent = new Agent(cfg, registry, r, session, opts.onFocusRepo);
    await agent.promptCtxFor(session.root); // warm the initial prompt + freshness
    return agent;
  }

  /** Build (and cache) the orientation prompt for a root. Primes freshness too. */
  private async promptCtxFor(root: string): Promise<PromptContext> {
    const hit = this.promptCache.get(root);
    if (hit) return hit;
    primeFreshness(root);
    const caps = detectCapabilities(root);
    let fullTree = "";
    try {
      fullTree = await afsTree(root);
    } catch {
      fullTree = ".";
    }
    const pc = await buildPromptContext({ ...this.cfg, agentsfsRoot: root }, caps, fullTree);
    this.promptCache.set(root, pc);
    return pc;
  }

  get toolSpecs(): ToolSpec[] {
    return this.registry.tools.map((t) => ({
      name: t.name,
      description: t.description,
      parameters: t.parameters,
    }));
  }

  get capabilities(): Capabilities {
    return detectCapabilities(this.session.root);
  }

  /** The active KB's display name (follows focus). */
  get instanceName(): string {
    return this.cfg.name || basename(this.session.root);
  }

  /** Concise instructions for the realtime voice model, for the CURRENTLY active
   *  KB (voice tokens are re-minted on focus, so this follows the switch). */
  realtimeInstructions(): string {
    const pc = this.promptCache.get(this.session.root);
    const name = this.instanceName;
    const desc = pc?.rootDescription ? ` (${pc.rootDescription})` : "";
    const finance = this.capabilities.domains.includes("stocks")
      ? " Never give personalized financial advice; explain the research and reasoning instead."
      : "";
    return (
      `You are the voice interface for the "${name}" ` +
      `AgentsFS knowledge base${desc}. For ANY substantive question about its ` +
      `content, call consult_knowledge with a clear, self-contained question and ` +
      `speak its answer aloud. Use search_wiki only for quick lookups. To change ` +
      `knowledge base, call focus_repo. Keep replies short and conversational — a ` +
      `sentence or two — and lead with the answer. Do not read URLs or file paths ` +
      `aloud; tell the user the sources are shown on screen. If something isn't in ` +
      `the knowledge base, say so.` +
      finance
    );
  }

  async ask(opts: AskOptions): Promise<AskResult> {
    const mode = opts.mode ?? "chat";
    const startRoot = this.session.root;
    // `session` is the SHARED box: if focus_repo runs mid-turn it mutates
    // session.root, so subsequent tool calls in THIS turn read the new root.
    // Wrap focus so a mid-turn switch also notifies the UI (which workspace is active).
    const focusRepo = this.onFocusRepo
      ? async (t: string) => {
          const res = await this.onFocusRepo!(t);
          opts.onInstanceChange?.(res.name);
          return res;
        }
      : undefined;
    const ctx: ToolContext = {
      cfg: this.cfg,
      caps: detectCapabilities(startRoot),
      session: this.session,
      focusRepo,
    };
    const collected: Citation[] = [];

    const executeTool = async (
      name: string,
      args: Record<string, unknown>,
    ): Promise<string> => {
      const tool = this.registry.byName.get(name);
      if (!tool) return `Unknown tool: ${name}`;
      const result = await tool.handler(args, ctx);
      if (result.citations) collected.push(...result.citations);
      // Redact any secret that slipped into tool output (bash, file reads, …)
      // before the model — and thus the user — ever sees it.
      const content = redactSecrets(result.content);
      // Hint against the CURRENTLY active root (focus_repo may have changed it).
      return READ_TOOLS.has(name)
        ? content + pullHint(this.session.root)
        : content;
    };

    const system = buildSystemPrompt(await this.promptCtxFor(startRoot), mode);

    const turn = await this.reasoner.runTurn({
      system,
      history: opts.history ?? [],
      userMessage: opts.message,
      tools: this.toolSpecs,
      executeTool,
      onTextDelta: opts.onTextDelta,
      onReset: opts.onReset,
      onToolCall: opts.onToolCall,
      signal: opts.signal,
      // Voice answers should resolve faster; cap tool rounds lower.
      maxToolIterations: mode === "voice" ? 5 : 8,
    });

    return {
      text: turn.text,
      citations: dedupeCitations(collected),
      toolCallCount: turn.toolCallCount,
      model: turn.model,
      usage: turn.usage,
    };
  }
}
