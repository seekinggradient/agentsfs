import type { Config } from "../config.js";
import { detectCapabilities, type Capabilities } from "../agentsfs/capabilities.js";
import { tree as afsTree } from "../agentsfs/afs.js";
import { walkTree } from "../agentsfs/tree.js";
import { buildToolRegistry } from "../tools/registry.js";
import {
  dedupeCitations,
  type Citation,
  type ToolContext,
  type ToolRegistry,
} from "../tools/types.js";
import { createReasoner } from "../reasoner/index.js";
import type { ChatMessage, Reasoner, ToolSpec, Usage } from "../reasoner/types.js";
import {
  buildPromptContext,
  buildSystemPrompt,
  type Mode,
  type PromptContext,
} from "./prompt.js";

/**
 * The agent: one per AgentsFS instance. Owns the tool registry, the reasoner,
 * and the cached prompt context (instance map + description). `ask()` runs one
 * grounded turn, streaming text and aggregating citations from every tool the
 * model used.
 */

export interface AskOptions {
  message: string;
  history?: ChatMessage[];
  mode?: Mode;
  onTextDelta?: (delta: string) => void;
  onReset?: () => void;
  onToolCall?: (name: string, args: Record<string, unknown>) => void;
  signal?: AbortSignal;
}

export interface AskResult {
  text: string;
  citations: Citation[];
  toolCallCount: number;
  model: string;
  usage?: Usage;
}

export class Agent {
  private constructor(
    readonly cfg: Config,
    private readonly caps: Capabilities,
    private readonly registry: ToolRegistry,
    private readonly reasoner: Reasoner,
    private readonly promptCtx: PromptContext,
  ) {}

  static async create(cfg: Config, reasoner?: Reasoner): Promise<Agent> {
    const caps = detectCapabilities(cfg.agentsfsRoot);
    const registry = buildToolRegistry(cfg);
    const r = reasoner ?? createReasoner(cfg);
    let fullTree = "";
    try {
      fullTree = await afsTree(cfg.agentsfsRoot);
    } catch {
      fullTree = "";
    }
    if (!fullTree.trim()) {
      // afs CLI unavailable — orient from a filesystem walk instead.
      try {
        fullTree = await walkTree(cfg.agentsfsRoot);
      } catch {
        fullTree = ".";
      }
    }
    const promptCtx = await buildPromptContext(cfg, caps, fullTree);
    return new Agent(cfg, caps, registry, r, promptCtx);
  }

  get toolSpecs(): ToolSpec[] {
    return this.registry.tools.map((t) => ({
      name: t.name,
      description: t.description,
      parameters: t.parameters,
    }));
  }

  get capabilities(): Capabilities {
    return this.caps;
  }

  get instanceName(): string {
    return this.promptCtx.instanceName;
  }

  /** Concise instructions for the realtime voice model. The heavy lifting is
   *  delegated to the consult_knowledge tool, so this stays short. */
  realtimeInstructions(): string {
    const desc = this.promptCtx.rootDescription
      ? ` (${this.promptCtx.rootDescription})`
      : "";
    const finance = this.caps.domains.includes("stocks")
      ? " Never give personalized financial advice; explain the research and reasoning instead."
      : "";
    return (
      `You are the voice interface for the "${this.promptCtx.instanceName}" ` +
      `AgentsFS knowledge base${desc}. For ANY substantive question about its ` +
      `content, call consult_knowledge with a clear, self-contained question and ` +
      `speak its answer aloud. Use search_wiki only for quick lookups. Keep ` +
      `replies short and conversational — a sentence or two — and lead with the ` +
      `answer. Do not read URLs or file paths aloud; tell the user the sources ` +
      `are shown on screen. If something isn't in the knowledge base, say so.` +
      finance
    );
  }

  async ask(opts: AskOptions): Promise<AskResult> {
    const mode = opts.mode ?? "chat";
    const ctx: ToolContext = { cfg: this.cfg, caps: this.caps };
    const collected: Citation[] = [];

    const executeTool = async (
      name: string,
      args: Record<string, unknown>,
    ): Promise<string> => {
      const tool = this.registry.byName.get(name);
      if (!tool) return `Unknown tool: ${name}`;
      const result = await tool.handler(args, ctx);
      if (result.citations) collected.push(...result.citations);
      return result.content;
    };

    const system = buildSystemPrompt(this.promptCtx, mode);

    const turn = await this.reasoner.runTurn({
      system,
      history: opts.history ?? [],
      userMessage: opts.message,
      tools: this.toolSpecs,
      executeTool,
      onTextDelta: opts.onTextDelta,
      onReset: opts.onReset,
      onToolCall: opts.onToolCall,
      signal: opts.signal,
      // Voice answers should resolve faster; cap tool rounds lower.
      maxToolIterations: mode === "voice" ? 5 : 8,
    });

    return {
      text: turn.text,
      citations: dedupeCitations(collected),
      toolCallCount: turn.toolCallCount,
      model: turn.model,
      usage: turn.usage,
    };
  }
}
