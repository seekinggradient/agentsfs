import { createInterface } from "node:readline/promises";
import { loadConfig } from "./config.js";
import { Agent } from "./agent/session.js";
import type { ChatMessage } from "./reasoner/types.js";

/**
 * Terminal chat over the configured AgentsFS instance. One-shot when a question
 * is passed as args; otherwise an interactive REPL. Great for testing the agent
 * without the browser.
 */

const dim = (s: string) => `\x1b[2m${s}\x1b[0m`;
const cyan = (s: string) => `\x1b[36m${s}\x1b[0m`;

async function main() {
  const cfg = loadConfig();
  process.stderr.write(
    dim(`agentsfs-chat • ${cfg.provider}/${cfg.chatModel} • ${cfg.agentsfsRoot}\n`),
  );
  const agent = await Agent.create(cfg);

  const askOnce = async (message: string, history: ChatMessage[]) => {
    const result = await agent.ask({
      message,
      history,
      onTextDelta: (d) => process.stdout.write(d),
      onToolCall: (name, args) =>
        process.stderr.write(dim(`\n  ↳ ${name}(${JSON.stringify(args)})\n`)),
    });
    process.stdout.write("\n");
    if (result.citations.length) {
      process.stdout.write(dim("\nsources:\n"));
      for (const c of result.citations.slice(0, 12)) {
        process.stdout.write(
          dim(`  • ${c.path ?? c.url}${c.line ? `:${c.line}` : ""}\n`),
        );
      }
    }
    process.stderr.write(
      dim(`\n[${result.toolCallCount} tool calls • ${result.model}]\n`),
    );
    return result.text;
  };

  const argQuestion = process.argv.slice(2).join(" ").trim();
  if (argQuestion) {
    await askOnce(argQuestion, []);
    return;
  }

  const rl = createInterface({ input: process.stdin, output: process.stdout });
  const history: ChatMessage[] = [];
  process.stdout.write(cyan("Ask about the knowledge base (Ctrl+C to exit).\n"));
  for (;;) {
    const q = (await rl.question(cyan("\n› "))).trim();
    if (!q) continue;
    const answer = await askOnce(q, history);
    history.push({ role: "user", content: q });
    history.push({ role: "assistant", content: answer });
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
