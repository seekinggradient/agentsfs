import { parse as parseYaml } from "yaml";

/**
 * AgentsFS files carry shallow YAML frontmatter (a one-line `description:`, a
 * `sources:` list, etc.) and link entities with `[[wikilinks]]`. These helpers
 * extract that provenance so chat answers can cite real sources and follow the
 * link graph.
 */

export interface Frontmatter {
  data: Record<string, unknown>;
  body: string;
  hasFrontmatter: boolean;
}

export function parseFrontmatter(text: string): Frontmatter {
  if (!text.startsWith("---")) {
    return { data: {}, body: text, hasFrontmatter: false };
  }
  // Match a real closing fence line (exactly --- with optional trailing
  // whitespace), not any line that merely starts with ---.
  const close = /\n---[ \t]*(?:\r?\n|$)/.exec(text);
  if (!close) return { data: {}, body: text, hasFrontmatter: false };
  const end = close.index;
  const raw = text.slice(3, end).replace(/^\r?\n/, "");
  // Body starts after the whole closing-fence match; drop any leading blanks.
  const body = text.slice(end + close[0].length).replace(/^\r?\n+/, "");
  let data: Record<string, unknown> = {};
  try {
    const parsed = parseYaml(raw);
    if (parsed && typeof parsed === "object") {
      data = parsed as Record<string, unknown>;
    }
  } catch {
    data = {};
  }
  return { data, body, hasFrontmatter: true };
}

/** Returns the file's one-line `description:` if present. */
export function description(text: string): string | undefined {
  const { data } = parseFrontmatter(text);
  const d = data["description"];
  return typeof d === "string" ? d : undefined;
}

/** Extract `[[wikilink]]` targets (deduped, original order). Ignores URLs. */
export function extractWikilinks(text: string): string[] {
  const out: string[] = [];
  const seen = new Set<string>();
  const re = /\[\[([^\]]+)\]\]/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    const target = (m[1] ?? "").trim();
    if (!target || seen.has(target)) continue;
    seen.add(target);
    out.push(target);
  }
  return out;
}

/**
 * Source citations for a file: the `sources:` frontmatter list (strings), plus
 * any bare URLs found in the body. Wikilink-style sources are returned verbatim
 * (e.g. `[[Datadog]]`) so the caller can resolve them to files.
 */
export function extractSources(text: string): string[] {
  const { data, body } = parseFrontmatter(text);
  const out: string[] = [];
  const seen = new Set<string>();
  const add = (s: string) => {
    const v = s.trim();
    if (v && !seen.has(v)) {
      seen.add(v);
      out.push(v);
    }
  };

  const fmSources = data["sources"];
  if (Array.isArray(fmSources)) {
    for (const s of fmSources) if (typeof s === "string") add(s);
  } else if (typeof fmSources === "string") {
    add(fmSources);
  }

  // Bare URLs in the body (markdown links and naked links).
  const urlRe = /https?:\/\/[^\s)\]}>"']+/g;
  let m: RegExpExecArray | null;
  while ((m = urlRe.exec(body)) !== null) add(m[0]);

  return out;
}
