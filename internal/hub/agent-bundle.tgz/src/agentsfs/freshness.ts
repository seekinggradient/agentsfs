import { execFile } from "node:child_process";

/**
 * Freshness check: has the hub gained commits this checkout doesn't have? The
 * result is appended as a short hint to knowledge-read tool results so the agent
 * knows to git_pull before trusting stale content. The check runs in the
 * background and is cached, so it NEVER blocks a tool call — the model reads the
 * last known status while a refresh runs behind it.
 */

interface Entry {
  behind: number;
  ts: number;
  checking: boolean;
}

const cache = new Map<string, Entry>();
const TTL_MS = 45_000;

function git(root: string, args: string[], timeoutMs = 15_000): Promise<string> {
  return new Promise((resolve) => {
    execFile(
      "git",
      args,
      { cwd: root, timeout: timeoutMs, env: { ...process.env, GIT_TERMINAL_PROMPT: "0" } },
      (err, stdout) => resolve(err ? "" : (stdout || "").trim()),
    );
  });
}

async function countBehind(root: string): Promise<number> {
  // Fetch quietly (uses the repo's configured auth), then count how many commits
  // the upstream branch has that we don't.
  await git(root, ["fetch", "--quiet", "origin"], 20_000);
  const n = parseInt(await git(root, ["rev-list", "--count", "HEAD..@{u}"]), 10);
  return Number.isFinite(n) ? n : 0;
}

function refresh(root: string): void {
  const cur = cache.get(root) || { behind: 0, ts: 0, checking: false };
  if (cur.checking) return;
  cur.checking = true;
  cache.set(root, cur);
  countBehind(root)
    .then((behind) => cache.set(root, { behind, ts: Date.now(), checking: false }))
    .catch(() => cache.set(root, { ...cur, ts: Date.now(), checking: false }));
}

/** Warm the cache (fire-and-forget) so the first tool call likely has a result. */
export function primeFreshness(root: string): void {
  refresh(root);
}

/** Mark a checkout fresh — call right after a successful pull. */
export function clearFreshness(root: string): void {
  cache.set(root, { behind: 0, ts: Date.now(), checking: false });
}

/** A short notice to append to a knowledge-read result when the checkout is
 *  behind the hub, else "". Triggers a background refresh; never blocks. */
export function pullHint(root: string): string {
  const c = cache.get(root);
  if (!c || Date.now() - c.ts > TTL_MS) refresh(root);
  if (c && c.behind > 0) {
    return `\n\n⟳ Heads up: the hub has ${c.behind} newer commit${c.behind === 1 ? "" : "s"} not in this checkout. Call git_pull to update before relying on the above — your reads may be stale.`;
  }
  return "";
}
