import { readFile as fsReadFile, readdir } from "node:fs/promises";
import { join } from "node:path";
import { description } from "./frontmatter.js";

/**
 * A filesystem tree of the instance with one-line descriptions, so the agent can
 * orient itself even when the `afs` CLI isn't installed (afs.tree returns "").
 * Mirrors the shape of `afs tree`: files first, then directories; a directory is
 * labeled by its INDEX.md description, and INDEX.md itself is not listed.
 */

const SKIP = new Set([".git", ".agentsfs", "node_modules", ".DS_Store"]);

async function descOf(abs: string): Promise<string> {
  try {
    return description(await fsReadFile(abs, "utf8")) ?? "";
  } catch {
    return "";
  }
}

export async function walkTree(root: string, maxDepth = 4): Promise<string> {
  const lines: string[] = ["."];

  async function walk(dir: string, prefix: string, depth: number): Promise<void> {
    let entries;
    try {
      entries = await readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }
    const items = entries
      .filter((e) => !SKIP.has(e.name) && !(e.name === "INDEX.md" && !e.isDirectory()))
      .sort((a, b) => {
        const ad = a.isDirectory(), bd = b.isDirectory();
        if (ad !== bd) return ad ? 1 : -1; // files before dirs
        return a.name.localeCompare(b.name);
      });

    for (let i = 0; i < items.length; i++) {
      const e = items[i];
      if (!e) continue;
      const last = i === items.length - 1;
      const branch = last ? "└── " : "├── ";
      const abs = join(dir, e.name);
      if (e.isDirectory()) {
        const idx = await descOf(join(abs, "INDEX.md"));
        lines.push(`${prefix}${branch}${e.name}/${idx ? ` — ${idx}` : ""}`);
        if (depth < maxDepth) {
          await walk(abs, prefix + (last ? "    " : "│   "), depth + 1);
        }
      } else {
        const d = e.name.toLowerCase().endsWith(".md") ? await descOf(abs) : "";
        lines.push(`${prefix}${branch}${e.name}${d ? ` — ${d}` : ""}`);
      }
    }
  }

  await walk(root, "", 1);
  return lines.join("\n");
}
