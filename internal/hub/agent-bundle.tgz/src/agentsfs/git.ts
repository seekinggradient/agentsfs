import { execFile } from "node:child_process";

/**
 * Minimal git wrapper for the write-capable agent. Mirrors the shell-out shape
 * of afs.ts (execFile with an args array — never a shell string — so a path or
 * message can't inject a command), always scoped to the AgentsFS root via cwd.
 *
 * The agent uses these to commit and push its edits so every change it makes is
 * a reviewable, revertible git commit — git history is the safety net.
 */

interface GitResult {
  stdout: string;
  stderr: string;
  code: number;
}

export interface CommitIdentity {
  name: string;
  email: string;
}

function run(root: string, args: string[], timeoutMs = 30_000): Promise<GitResult> {
  return new Promise((resolve) => {
    execFile(
      "git",
      args,
      {
        cwd: root,
        timeout: timeoutMs,
        maxBuffer: 16 * 1024 * 1024,
        env: { ...process.env, GIT_TERMINAL_PROMPT: "0" },
      },
      (err, stdout, stderr) => {
        const e = err as NodeJS.ErrnoException | null;
        if (e && e.code === "ENOENT") {
          resolve({ stdout: "", stderr: "git not found on PATH", code: 127 });
          return;
        }
        const code = e && typeof e.code === "number" ? e.code : err ? 1 : 0;
        resolve({ stdout: stdout ?? "", stderr: stderr ?? "", code });
      },
    );
  });
}

/** Porcelain status of the working tree (empty string means clean). */
export async function status(root: string): Promise<string> {
  const { stdout } = await run(root, ["status", "--porcelain=v1"]);
  return stdout.trimEnd();
}

/** Diff of the working tree. Staged + unstaged; optionally scoped to a path. */
export async function diff(root: string, path?: string): Promise<string> {
  const args = ["diff", "HEAD", "--stat=200", "-p", "--"];
  if (path) args.push(path);
  const { stdout } = await run(root, args);
  return stdout;
}

/** Current branch name, or "" if detached/unborn. */
export async function currentBranch(root: string): Promise<string> {
  const { stdout, code } = await run(root, ["symbolic-ref", "--short", "HEAD"]);
  return code === 0 ? stdout.trim() : "";
}

export interface CommitResult {
  committed: boolean;
  sha?: string;
  summary: string;
}

/**
 * Stage every change and commit it. Returns committed:false (not an error) when
 * the tree is clean. Uses an explicit identity via -c so it works in a fresh
 * clone that has no git config.
 */
export async function commitAll(
  root: string,
  message: string,
  who: CommitIdentity,
): Promise<CommitResult> {
  const dirty = await status(root);
  if (!dirty) return { committed: false, summary: "nothing to commit — the working tree is clean" };

  const add = await run(root, ["add", "-A"]);
  if (add.code !== 0) throw new Error(`git add failed: ${add.stderr.trim() || add.stdout.trim()}`);

  const commit = await run(root, [
    "-c",
    `user.name=${who.name}`,
    "-c",
    `user.email=${who.email}`,
    "commit",
    "-m",
    message,
  ]);
  if (commit.code !== 0) {
    throw new Error(`git commit failed: ${commit.stderr.trim() || commit.stdout.trim()}`);
  }
  const rev = await run(root, ["rev-parse", "--short", "HEAD"]);
  return {
    committed: true,
    sha: rev.stdout.trim(),
    summary: commit.stdout.trim(),
  };
}

/** Push the current branch to its remote (origin by default). */
export async function push(root: string): Promise<string> {
  const branch = await currentBranch(root);
  const args = branch ? ["push", "origin", `HEAD:${branch}`] : ["push"];
  const { stdout, stderr, code } = await run(root, args, 120_000);
  if (code !== 0) {
    throw new Error(`git push failed: ${stderr.trim() || stdout.trim()}`);
  }
  return (stderr.trim() || stdout.trim() || `pushed ${branch || "HEAD"}`).trim();
}
