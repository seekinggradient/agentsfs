import { execFile } from "node:child_process";

/**
 * Minimal git wrapper for the write-capable agent. Mirrors the shell-out shape
 * of afs.ts (execFile with an args array — never a shell string — so a path or
 * message can't inject a command), always scoped to the AgentsFS root via cwd.
 *
 * The agent uses these to commit and push its edits so every change it makes is
 * a reviewable, revertible git commit — git history is the safety net.
 */

interface GitResult {
  stdout: string;
  stderr: string;
  code: number;
}

export interface CommitIdentity {
  name: string;
  email: string;
}

function run(root: string, args: string[], timeoutMs = 30_000): Promise<GitResult> {
  return new Promise((resolve) => {
    execFile(
      "git",
      args,
      {
        cwd: root,
        timeout: timeoutMs,
        maxBuffer: 16 * 1024 * 1024,
        env: { ...process.env, GIT_TERMINAL_PROMPT: "0" },
      },
      (err, stdout, stderr) => {
        const e = err as NodeJS.ErrnoException | null;
        if (e && e.code === "ENOENT") {
          resolve({ stdout: "", stderr: "git not found on PATH", code: 127 });
          return;
        }
        const code = e && typeof e.code === "number" ? e.code : err ? 1 : 0;
        resolve({ stdout: stdout ?? "", stderr: stderr ?? "", code });
      },
    );
  });
}

/** Porcelain status of the working tree (empty string means clean). */
export async function status(root: string): Promise<string> {
  const { stdout } = await run(root, ["status", "--porcelain=v1"]);
  return stdout.trimEnd();
}

/** Diff of the working tree. Staged + unstaged; optionally scoped to a path. */
export async function diff(root: string, path?: string): Promise<string> {
  const args = ["diff", "HEAD", "--stat=200", "-p", "--"];
  if (path) args.push(path);
  const { stdout } = await run(root, args);
  return stdout;
}

export interface FileStat {
  path: string;
  additions: number;
  deletions: number;
}

/**
 * Per-file added/deleted line counts for the working tree vs HEAD (the same
 * scope as {@link diff}). Parses `git diff --numstat`; binary files report "-"
 * for both counts, which we surface as 0. Used to build the review proposal's
 * per-file summary. Note: like `git diff HEAD`, this covers tracked changes —
 * a brand-new untracked file shows up in `status` but not here.
 */
export async function numstat(root: string): Promise<FileStat[]> {
  const { stdout } = await run(root, ["diff", "HEAD", "--numstat"]);
  const out: FileStat[] = [];
  for (const line of stdout.split("\n")) {
    if (!line.trim()) continue;
    // Format: <additions>\t<deletions>\t<path>  ("-" for binary files).
    const m = line.match(/^(\d+|-)\t(\d+|-)\t(.+)$/);
    if (!m) continue;
    out.push({
      path: m[3]!,
      additions: m[1] === "-" ? 0 : Number(m[1]),
      deletions: m[2] === "-" ? 0 : Number(m[2]),
    });
  }
  return out;
}

/** Short sha of HEAD ("" on an unborn branch). */
export async function headShort(root: string): Promise<string> {
  const { stdout, code } = await run(root, ["rev-parse", "--short", "HEAD"]);
  return code === 0 ? stdout.trim() : "";
}

/**
 * How many local commits haven't reached the upstream branch. Returns 0 when no
 * upstream is configured or the branch is unborn (nothing to retry pushing).
 * Makes the review commit endpoint idempotent: a re-POST after a failed push
 * finds a clean tree but a positive ahead-count and retries the push, instead
 * of reporting "nothing to commit" while the hub never got the changes.
 */
export async function aheadCount(root: string): Promise<number> {
  const { stdout, code } = await run(root, ["rev-list", "--count", "@{u}..HEAD"]);
  if (code !== 0) return 0; // no upstream / unborn branch — nothing to retry
  return Number(stdout.trim()) || 0;
}

/**
 * Revert the working tree to HEAD, deterministically and jailed to `root` via
 * cwd: `git checkout -- .` drops tracked modifications, `git clean -fd` removes
 * untracked files/dirs the agent created. Used by the review "Discard" action to
 * throw away a proposal the user rejected. Never touches anything outside root.
 */
export async function discard(root: string): Promise<void> {
  const co = await run(root, ["checkout", "--", "."]);
  if (co.code !== 0 && !/did not match any file/i.test(co.stderr)) {
    throw new Error(`git checkout failed: ${co.stderr.trim() || co.stdout.trim()}`);
  }
  const clean = await run(root, ["clean", "-fd"]);
  if (clean.code !== 0) {
    throw new Error(`git clean failed: ${clean.stderr.trim() || clean.stdout.trim()}`);
  }
}

/** Current branch name, or "" if detached/unborn. */
export async function currentBranch(root: string): Promise<string> {
  const { stdout, code } = await run(root, ["symbolic-ref", "--short", "HEAD"]);
  return code === 0 ? stdout.trim() : "";
}

export interface CommitResult {
  committed: boolean;
  sha?: string;
  summary: string;
}

/**
 * Stage every change and commit it. Returns committed:false (not an error) when
 * the tree is clean. Uses an explicit identity via -c so it works in a fresh
 * clone that has no git config.
 */
export async function commitAll(
  root: string,
  message: string,
  who: CommitIdentity,
): Promise<CommitResult> {
  const dirty = await status(root);
  if (!dirty) return { committed: false, summary: "nothing to commit — the working tree is clean" };

  const add = await run(root, ["add", "-A"]);
  if (add.code !== 0) throw new Error(`git add failed: ${add.stderr.trim() || add.stdout.trim()}`);

  const commit = await run(root, [
    "-c",
    `user.name=${who.name}`,
    "-c",
    `user.email=${who.email}`,
    "commit",
    "-m",
    message,
  ]);
  if (commit.code !== 0) {
    throw new Error(`git commit failed: ${commit.stderr.trim() || commit.stdout.trim()}`);
  }
  const rev = await run(root, ["rev-parse", "--short", "HEAD"]);
  return {
    committed: true,
    sha: rev.stdout.trim(),
    summary: commit.stdout.trim(),
  };
}

/** Fast-forward the checkout from the hub. --ff-only so it never creates a
 *  merge/conflict silently: if history diverged or there are uncommitted
 *  changes, it fails with a clear message the agent can act on. */
export async function pull(root: string): Promise<string> {
  const { stdout, stderr, code } = await run(root, ["pull", "--ff-only"], 60_000);
  if (code !== 0) {
    throw new Error(
      `git pull failed: ${stderr.trim() || stdout.trim()} — commit or stash local changes first, or the history has diverged and needs manual resolution`,
    );
  }
  return stdout.trim() || "Already up to date.";
}

/** Push the current branch to its remote (origin by default). */
export async function push(root: string): Promise<string> {
  const branch = await currentBranch(root);
  const args = branch ? ["push", "origin", `HEAD:${branch}`] : ["push"];
  const { stdout, stderr, code } = await run(root, args, 120_000);
  if (code !== 0) {
    throw new Error(`git push failed: ${stderr.trim() || stdout.trim()}`);
  }
  return (stderr.trim() || stdout.trim() || `pushed ${branch || "HEAD"}`).trim();
}

/**
 * One-shot `git pull --rebase`, used when a push was rejected because the
 * remote moved: replay our local commits on top of the remote's, then the
 * caller retries the push. On any failure (typically conflicts) the rebase is
 * aborted (best effort) so the tree is left exactly as it was — the local
 * commits stay intact and the caller reports the push as failed. Returns
 * whether the rebase succeeded.
 */
export async function pullRebase(root: string): Promise<boolean> {
  const res = await run(root, ["pull", "--rebase"], 60_000);
  if (res.code === 0) return true;
  await run(root, ["rebase", "--abort"]); // best effort; no-op if none in progress
  return false;
}
