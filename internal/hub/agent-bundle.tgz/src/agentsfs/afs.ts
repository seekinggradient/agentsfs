import { execFile } from "node:child_process";
import { existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

/**
 * Thin wrapper around the `afs` (AgentsFS) CLI. We shell out and parse stdout
 * using the exact output formats the CLI guarantees. Every command accepts a
 * `[path]` that climbs to find the instance root, so we always pass the
 * configured AgentsFS root explicitly.
 *
 * Output formats are documented in the afs Go source; the parsers below mirror
 * them. If a format ever drifts, the parser degrades to "best effort" rather
 * than throwing, so the agent can still function on the raw text.
 */

export interface SearchResult {
  rank: number;
  path: string;
  /** Present only for semantic results. */
  score?: number;
  /** Heading/section the match came from, if any. */
  section?: string;
  snippet: string;
}

export interface Backlink {
  source: string;
  line: number;
  target: string;
}

export interface DoctorFinding {
  severity: "error" | "warn" | "info";
  code: string;
  path: string;
  message: string;
}

export interface EmbeddingsStatus {
  configured: boolean;
  provider?: string;
  model?: string;
  raw: string;
}

/** Raised when semantic search is requested but unavailable, so callers can
 *  fall back to full-text search. */
export class SemanticUnavailableError extends Error {}

interface ExecResult {
  stdout: string;
  stderr: string;
  code: number;
}

let cachedBin: string | null = null;

function resolveBin(): string {
  if (cachedBin) return cachedBin;
  const candidates = [
    process.env.AFS_BIN,
    "afs", // on PATH
    join(homedir(), ".local", "bin", "afs"),
  ].filter(Boolean) as string[];
  // Prefer an explicit/known path if it exists; otherwise trust PATH ("afs").
  for (const c of candidates) {
    if (c === "afs") continue;
    if (existsSync(c)) {
      cachedBin = c;
      return c;
    }
  }
  cachedBin = "afs";
  return cachedBin;
}

function run(args: string[], timeoutMs = 20_000): Promise<ExecResult> {
  const bin = resolveBin();
  return new Promise((resolve) => {
    execFile(
      bin,
      args,
      {
        timeout: timeoutMs,
        maxBuffer: 16 * 1024 * 1024,
        // CI=1 suppresses the update-check notice; pass through OPENAI_API_KEY so
        // semantic search works when the instance has an embedding index.
        env: { ...process.env, CI: "1" },
      },
      (err, stdout, stderr) => {
        const e = err as NodeJS.ErrnoException | null;
        if (e && e.code === "ENOENT") {
          resolve({
            stdout: "",
            stderr: "afs CLI not found (install afs or set AFS_BIN)",
            code: 127,
          });
          return;
        }
        const code =
          e && typeof e.code === "number"
            ? e.code
            : err
              ? 1
              : 0;
        resolve({ stdout: stdout ?? "", stderr: stderr ?? "", code });
      },
    );
  });
}

/** Returns true if the afs binary is runnable. Cached per process. */
let availability: boolean | null = null;
export async function afsAvailable(): Promise<boolean> {
  if (availability !== null) return availability;
  try {
    const { stdout, code } = await run(["version"], 5_000);
    availability = code === 0 || /afs/i.test(stdout);
  } catch {
    availability = false;
  }
  return availability;
}

/** Whole-tree map with descriptions and freshness. Returns raw text. */
export async function tree(root: string): Promise<string> {
  const { stdout } = await run(["tree", root]);
  return stdout.trimEnd();
}

/**
 * Ranked search. Full-text by default; semantic when `semantic` is true and the
 * instance has an embedding index. Throws {@link SemanticUnavailableError} when
 * semantic is requested but no index/provider exists, so the caller can retry
 * full-text.
 */
export async function search(
  root: string,
  query: string,
  opts: { semantic?: boolean; limit?: number } = {},
): Promise<SearchResult[]> {
  const args = ["search", query, root];
  if (opts.semantic) args.push("--semantic");
  if (opts.limit) args.push("-n", String(opts.limit));
  const { stdout, stderr, code } = await run(args);

  if (code !== 0) {
    const msg = stderr.trim() || stdout.trim();
    if (opts.semantic && /embedding|semantic|provider|index/i.test(msg)) {
      throw new SemanticUnavailableError(msg);
    }
    throw new Error(`afs search failed: ${msg}`);
  }
  return parseSearch(stdout);
}

export function parseSearch(stdout: string): SearchResult[] {
  const text = stdout.trim();
  if (!text || /^no matches/i.test(text)) return [];
  // The semantic-staleness warning may be prepended on stdout in some paths.
  const blocks = text
    .replace(/^warning:.*\n/i, "")
    .split(/\n\s*\n/)
    .map((b) => b.trim())
    .filter(Boolean);

  const results: SearchResult[] = [];
  for (const block of blocks) {
    const lines = block.split("\n");
    const header = lines[0] ?? "";
    const m = header.match(/^(\d+)\.\s+(.*)$/);
    if (!m) continue;
    const rank = Number(m[1]);
    let rest = m[2] ?? "";
    let score: number | undefined;
    const scoreMatch = rest.match(/^(.*?)\s{2,}score\s+([\d.]+)\s*$/);
    if (scoreMatch) {
      rest = scoreMatch[1] ?? rest;
      score = Number(scoreMatch[2]);
    }
    const path = rest.trim();

    let section: string | undefined;
    const snippetLines: string[] = [];
    for (const line of lines.slice(1)) {
      const sec = line.match(/^\s+section:\s*(.*)$/);
      if (sec) {
        section = (sec[1] ?? "").trim();
        continue;
      }
      const trimmed = line.trim();
      if (trimmed) snippetLines.push(trimmed);
    }
    results.push({
      rank,
      path,
      score,
      section,
      snippet: snippetLines.join(" ").trim(),
    });
  }
  return results;
}

/** Every `[[wikilink]]` that resolves to the named entity. */
export async function backlinks(
  root: string,
  name: string,
): Promise<Backlink[]> {
  const { stdout, code, stderr } = await run(["backlinks", name, root]);
  if (code !== 0) throw new Error(`afs backlinks failed: ${stderr.trim()}`);
  return parseBacklinks(stdout);
}

export function parseBacklinks(stdout: string): Backlink[] {
  const text = stdout.trim();
  if (!text || /^no links to/i.test(text)) return [];
  const out: Backlink[] = [];
  for (const line of text.split("\n")) {
    const m = line.match(/^(.*):(\d+)\s+\[\[(.*)\]\]\s*$/);
    if (m) {
      out.push({
        source: m[1] ?? "",
        line: Number(m[2]),
        target: m[3] ?? "",
      });
    }
  }
  return out;
}

/** Deterministic health check. Uses --json so we get structured findings. */
export async function doctor(root: string): Promise<DoctorFinding[]> {
  // doctor exits 1 when there are error-severity findings, so we ignore the
  // exit code and parse the JSON array instead.
  const { stdout } = await run(["doctor", root, "--json"]);
  try {
    const parsed = JSON.parse(stdout.trim() || "[]");
    return Array.isArray(parsed) ? (parsed as DoctorFinding[]) : [];
  } catch {
    return [];
  }
}

/**
 * Search with automatic fallback: when `semantic` is requested but the instance
 * has no embedding index/provider, transparently fall back to full-text. The
 * unavailability is cached per root so we don't pay a failing round-trip every
 * call.
 */
const semanticUnavailable = new Set<string>();

export interface SmartSearch {
  results: SearchResult[];
  mode: "semantic" | "fulltext";
  fellBack: boolean;
}

export async function searchSmart(
  root: string,
  query: string,
  opts: { semantic?: boolean; limit?: number } = {},
): Promise<SmartSearch> {
  const wantSemantic = !!opts.semantic && !semanticUnavailable.has(root);
  if (wantSemantic) {
    try {
      const results = await search(root, query, { ...opts, semantic: true });
      return { results, mode: "semantic", fellBack: false };
    } catch (e) {
      if (e instanceof SemanticUnavailableError) {
        semanticUnavailable.add(root);
      } else {
        throw e;
      }
    }
  }
  const results = await search(root, query, { ...opts, semantic: false });
  return { results, mode: "fulltext", fellBack: !!opts.semantic };
}

/** Reset cached semantic-availability (used by tests). */
export function _resetSemanticCache(): void {
  semanticUnavailable.clear();
}

/** Global embedding-provider status (not instance-specific). */
export async function embeddingsStatus(): Promise<EmbeddingsStatus> {
  const { stdout } = await run(["embeddings", "status"], 8_000);
  const raw = stdout.trim();
  const configured = !/not configured/i.test(raw) && /provider:/i.test(raw);
  const provider = raw.match(/embedding provider:\s*(\S+)/i)?.[1];
  const model = raw.match(/model:\s*(\S+)/i)?.[1];
  return {
    configured,
    provider: provider && provider !== "not" ? provider : undefined,
    model,
    raw,
  };
}
