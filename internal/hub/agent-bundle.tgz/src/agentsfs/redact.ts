/**
 * Secret redaction for tool output — UI HYGIENE, NOT a security boundary. It
 * masks secrets that appear verbatim in a tool result (`cat .env`, a git remote
 * with embedded creds, a config file), so an accidental surfacing doesn't land
 * in the transcript. It does NOT stop a determined exfiltration: any encoding
 * (base64/hex/rev) defeats a substring match. The real containment is (1) not
 * leaving the reasoner key in the process env (see index.ts) so run_bash can't
 * read it, (2) the sprite's per-user isolation + egress limits, and (3) the v2
 * plan to proxy model calls through the hub so no key lives in the sprite. Every
 * tool result still flows through here as cheap defense-in-depth.
 */

function collectSecretValues(): string[] {
  const vals: string[] = [];
  for (const [k, v] of Object.entries(process.env)) {
    if (!v || v.length < 8) continue; // too short to be a meaningful secret
    if (/(_API_KEY|_KEY|_TOKEN|SECRET|PASSWORD|PASSWD|_PAT\b)/i.test(k)) vals.push(v);
  }
  // Longest first so a value that contains another is masked whole.
  return [...new Set(vals)].sort((a, b) => b.length - a.length);
}

// Snapshot at module load — env is fixed for the process lifetime.
const SECRET_VALUES = collectSecretValues();

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

const VALUE_RE = SECRET_VALUES.length
  ? new RegExp(SECRET_VALUES.map(escapeRegExp).join("|"), "g")
  : null;

// Common secret shapes (defends against secrets NOT in this process's env, e.g.
// another user's token seen through a shared file): OpenAI keys, bearer/basic
// auth headers, and afs_ hub PATs.
const PATTERN_RES: RegExp[] = [
  /sk-[A-Za-z0-9_-]{16,}/g,
  /\bafs_[A-Za-z0-9_-]{16,}/g,
  /\b(Authorization|authorization)\s*:\s*(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]{8,}/g,
];

/** Replace every known/likely secret in `text` with [redacted]. */
export function redactSecrets(text: string): string {
  if (!text) return text;
  let out = text;
  if (VALUE_RE) out = out.replace(VALUE_RE, "[redacted]");
  for (const re of PATTERN_RES) out = out.replace(re, "[redacted]");
  return out;
}
