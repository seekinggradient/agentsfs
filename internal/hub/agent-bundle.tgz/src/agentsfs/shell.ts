import { execFile } from "node:child_process";

/**
 * Shell runner for the agent's run_bash tool. Unlike afs.ts/git.ts — which pass
 * a fixed argv precisely so a path/message can't inject a command — this tool is
 * MEANT to run arbitrary commands, so argv sanitization is not the defense. The
 * defense is the ENVIRONMENT: the child gets a minimal, allow-listed env with
 * every secret stripped, so a stray `env`/`printenv` (or a prompt-injected
 * "print your keys") can't exfiltrate the OpenAI/Anthropic key that the reasoner
 * needs in the PARENT process. Combined with the sprite's per-user Firecracker
 * isolation, that bounds the blast radius to the user's own VM.
 */

export interface ShellResult {
  /** Combined stdout+stderr, with a leading exit-code line on failure. */
  output: string;
  code: number;
}

/** Env vars the shell legitimately needs; everything else (esp. *_API_KEY /
 *  *_TOKEN / *SECRET*) is dropped. XDG_CONFIG_HOME survives so `afs hub` can
 *  read hub.json; AFS_BIN + a PATH that includes ~/.local/bin let `afs` run. */
const ALLOW = new Set([
  "PATH",
  "HOME",
  "USER",
  "LOGNAME",
  "LANG",
  "LC_ALL",
  "TERM",
  "TMPDIR",
  "SHELL",
  "XDG_CONFIG_HOME",
  "XDG_DATA_HOME",
  "AFS_BIN",
]);

/** Deny anything secret-shaped even if it were somehow allow-listed. */
function isSecretName(name: string): boolean {
  return /(_API_KEY|_KEY|_TOKEN|SECRET|PASSWORD|PASSWD|_PAT\b)/i.test(name);
}

function scrubbedEnv(): NodeJS.ProcessEnv {
  const out: NodeJS.ProcessEnv = {};
  for (const [k, v] of Object.entries(process.env)) {
    if (v === undefined) continue;
    if (!ALLOW.has(k)) continue;
    if (isSecretName(k)) continue; // belt-and-suspenders
    out[k] = v;
  }
  // Keep git non-interactive (no auth prompt hangs) and mark non-tty.
  out.GIT_TERMINAL_PROMPT = "0";
  out.CI = "1";
  return out;
}

/**
 * Run `command` through /bin/sh in `cwd`. Never throws for a non-zero exit — the
 * model needs to see failures — resolves {output, code} instead. ENOENT (no
 * /bin/sh) and timeouts surface as a readable message.
 */
export function runShell(
  cwd: string,
  command: string,
  opts: { timeoutMs?: number } = {},
): Promise<ShellResult> {
  return new Promise((resolve) => {
    execFile(
      "/bin/sh",
      ["-c", command],
      {
        cwd,
        timeout: opts.timeoutMs ?? 60_000,
        maxBuffer: 8 * 1024 * 1024,
        env: scrubbedEnv(),
      },
      (err, stdout, stderr) => {
        const e = err as (NodeJS.ErrnoException & { killed?: boolean; signal?: string }) | null;
        const body = [stdout ?? "", stderr ?? ""].filter(Boolean).join("").trimEnd();
        if (e && e.code === "ENOENT") {
          resolve({ output: "/bin/sh not found", code: 127 });
          return;
        }
        if (e && e.killed && e.signal === "SIGTERM") {
          resolve({
            output: `${body}\n[timed out after ${(opts.timeoutMs ?? 60_000) / 1000}s]`.trim(),
            code: 124,
          });
          return;
        }
        const code = e && typeof e.code === "number" ? e.code : err ? 1 : 0;
        const prefix = code !== 0 ? `[exit ${code}]\n` : "";
        resolve({ output: prefix + (body || "(no output)"), code });
      },
    );
  });
}
