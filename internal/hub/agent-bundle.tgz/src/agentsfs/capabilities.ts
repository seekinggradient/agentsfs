import { existsSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";

/**
 * AgentsFS instances grow structure over time. Rather than hard-code one
 * domain, we detect optional capabilities from what is actually on disk and let
 * tools "light up" accordingly. A plain notes vault exposes only the generic
 * tools; the agentic-stocks instance additionally exposes structured theses.
 *
 * This is the seam the user cares about: as AgentsFS gains conventions, add a
 * detector here and the chat/voice layer benefits automatically.
 */

export interface Capabilities {
  /** Top-level domain directories (e.g. development, stocks, education). */
  domains: string[];
  /** Relative path to the current-theses table if this is a stocks instance. */
  thesesJsonPath?: string;
  hasPortfolio: boolean;
  hasEducation: boolean;
  /** A derived index db exists (full-text and/or embeddings). */
  hasIndex: boolean;
}

function isDir(p: string): boolean {
  try {
    return statSync(p).isDirectory();
  } catch {
    return false;
  }
}

export function detectCapabilities(root: string): Capabilities {
  const domains = (() => {
    try {
      return readdirSync(root, { withFileTypes: true })
        .filter((e) => e.isDirectory() && !e.name.startsWith("."))
        .map((e) => e.name)
        .sort();
    } catch {
      return [];
    }
  })();

  const thesesJson = join("stocks", "theses", "history", "current-theses.json");
  const thesesJsonPath = existsSync(join(root, thesesJson))
    ? thesesJson
    : undefined;

  return {
    domains,
    thesesJsonPath,
    hasPortfolio: isDir(join(root, "stocks", "portfolio")),
    hasEducation: isDir(join(root, "education")),
    hasIndex: existsSync(join(root, ".agentsfs", "index.db")),
  };
}
