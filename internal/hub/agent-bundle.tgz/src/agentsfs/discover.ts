import { readFileSync, readdirSync, statSync } from "node:fs";
import { basename, join, resolve } from "node:path";

/**
 * Detect and discover AgentsFS instances on disk, so the UI can let the user
 * switch which instance is served. An "instance" is a directory that either
 * contains a `.agentsfs/` machine dir or an AGENTS.md declaring itself one — the
 * same signals the `afs` CLI uses. This validation is also the security gate for
 * switching: only real agentsfs directories can be selected.
 */

const SKIP = new Set([
  "node_modules",
  ".git",
  "dist",
  "build",
  ".next",
  ".venv",
  "venv",
  "__pycache__",
  ".cache",
  ".agentsfs",
]);

export function isAgentsfs(dir: string): boolean {
  try {
    if (statSync(join(dir, ".agentsfs")).isDirectory()) return true;
  } catch {
    /* no .agentsfs */
  }
  try {
    const agents = readFileSync(join(dir, "AGENTS.md"), "utf8");
    if (agents.includes("This folder is an agentsfs")) return true;
  } catch {
    /* no AGENTS.md */
  }
  return false;
}

export interface DiscoveredInstance {
  path: string;
  name: string;
}

/**
 * Walk `searchDir` up to `maxDepth` levels and return every AgentsFS instance
 * found. Does not descend into an instance once found, and skips heavy/hidden
 * directories. Bounded so it stays fast even over a big workspace.
 */
export function discoverInstances(
  searchDir: string,
  maxDepth = 3,
): DiscoveredInstance[] {
  const out: DiscoveredInstance[] = [];
  const seen = new Set<string>();

  const walk = (dir: string, depth: number): void => {
    if (depth > maxDepth) return;
    if (isAgentsfs(dir)) {
      if (!seen.has(dir)) {
        seen.add(dir);
        out.push({ path: dir, name: basename(dir) });
      }
      return; // don't recurse into an instance
    }
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries) {
      if (!e.isDirectory() || e.name.startsWith(".") || SKIP.has(e.name)) continue;
      walk(join(dir, e.name), depth + 1);
    }
  };

  walk(resolve(searchDir), 0);
  return out.sort((a, b) => a.path.localeCompare(b.path));
}
