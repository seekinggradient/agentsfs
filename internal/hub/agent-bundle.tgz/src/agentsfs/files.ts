import { execFile } from "node:child_process";
import {
  mkdir,
  readFile as fsReadFile,
  readdir,
  realpath,
  stat,
  writeFile as fsWriteFile,
} from "node:fs/promises";
import { dirname, relative, resolve, sep } from "node:path";

/**
 * Path-jailed filesystem access over an AgentsFS instance. Every path is
 * resolved against the instance root and verified to stay inside it, so the
 * agent (and anything it is convinced to do) can never read outside the wiki.
 */

const MAX_FILE_CHARS = 400 * 1024;

export class PathEscapeError extends Error {}

// The lexical safeResolve blocks `../` traversal, but a symlink *inside* the
// root could still point outside it. Verify the canonical (realpath) target
// stays in-root before any read. The root realpath is cached per process.
const rootRealCache = new Map<string, string>();
async function rootReal(root: string): Promise<string> {
  const key = resolve(root);
  let v = rootRealCache.get(key);
  if (v === undefined) {
    v = await realpath(key);
    rootRealCache.set(key, v);
  }
  return v;
}

async function assertRealInRoot(root: string, abs: string): Promise<void> {
  const real = await realpath(abs);
  const base = await rootReal(root);
  if (real !== base && !real.startsWith(base + sep)) {
    throw new PathEscapeError(
      `path escapes the AgentsFS root via symlink: ${relative(resolve(root), abs)}`,
    );
  }
}

/**
 * Resolve `relPath` against `root` and guarantee the result is inside `root`.
 * Absolute inputs are treated as instance-relative. Throws {@link PathEscapeError}
 * on any attempt to escape (e.g. `../../etc/passwd`).
 */
export function safeResolve(root: string, relPath: string): string {
  const rootAbs = resolve(root);
  // Treat a leading "/" as relative to the instance root, not the OS root.
  const cleaned = relPath.replace(/^[/\\]+/, "");
  const target = resolve(rootAbs, cleaned);
  if (target !== rootAbs && !target.startsWith(rootAbs + sep)) {
    throw new PathEscapeError(`path escapes the AgentsFS root: ${relPath}`);
  }
  return target;
}

export interface ReadResult {
  path: string;
  content: string;
  truncated: boolean;
  bytes: number;
}

/** Read a UTF-8 text file inside the instance, capped at {@link MAX_FILE_BYTES}. */
export async function readFile(
  root: string,
  relPath: string,
): Promise<ReadResult> {
  const abs = safeResolve(root, relPath);
  const info = await stat(abs);
  if (info.isDirectory()) {
    throw new Error(`${relPath} is a directory, not a file`);
  }
  await assertRealInRoot(root, abs);
  const buf = await fsReadFile(abs);
  // Decode fully then cap by character count so we never split a multibyte
  // UTF-8 sequence (AgentsFS files are small markdown).
  const full = buf.toString("utf8");
  const truncated = full.length > MAX_FILE_CHARS;
  const content = truncated ? full.slice(0, MAX_FILE_CHARS) : full;
  return {
    path: relative(resolve(root), abs),
    content,
    truncated,
    bytes: buf.length,
  };
}

export interface GrepMatch {
  path: string;
  line: number;
  text: string;
}

/**
 * Literal-by-default ripgrep over the instance. `isRegex` opts into regex.
 * Respects the instance's .gitignore (so `.agentsfs/` and binaries are skipped).
 */
export async function grep(
  root: string,
  pattern: string,
  opts: { glob?: string; isRegex?: boolean; maxResults?: number } = {},
): Promise<GrepMatch[]> {
  const rootAbs = resolve(root);
  const max = opts.maxResults ?? 60;
  const args = [
    "--line-number",
    "--no-heading",
    "--color=never",
    "--smart-case",
    "-g",
    "!.git",
    "-g",
    "!.agentsfs",
  ];
  if (!opts.isRegex) args.push("--fixed-strings");
  if (opts.glob) args.push("-g", opts.glob);
  args.push("--", pattern, rootAbs);

  const stdout = await new Promise<string>((resolveP) => {
    execFile(
      "rg",
      args,
      { timeout: 15_000, maxBuffer: 16 * 1024 * 1024 },
      (_err, out) => resolveP(out ?? ""), // rg exits 1 on no matches; treat as empty
    );
  });

  const matches: GrepMatch[] = [];
  for (const line of stdout.split("\n")) {
    if (!line) continue;
    // Format: <abs-path>:<line>:<text>
    const m = line.match(/^(.*?):(\d+):(.*)$/);
    if (!m) continue;
    const abs = m[1] ?? "";
    matches.push({
      path: relative(rootAbs, abs),
      line: Number(m[2]),
      text: (m[3] ?? "").slice(0, 400),
    });
    if (matches.length >= max) break;
  }
  return matches;
}

export interface DirEntry {
  name: string;
  type: "file" | "dir";
}

/**
 * Create or overwrite a UTF-8 text file inside the instance. Same path jail as
 * reads: safeResolve blocks `../` traversal; after writing, assertRealInRoot
 * verifies the (now-existing) target didn't escape via a symlink. Parent
 * directories are created as needed. Returns the instance-relative path.
 */
export async function writeFileSafe(
  root: string,
  relPath: string,
  content: string,
): Promise<string> {
  const abs = safeResolve(root, relPath);
  // Guard the parent against a symlink escape before creating anything.
  await mkdir(dirname(abs), { recursive: true });
  await assertRealInRoot(root, dirname(abs));
  await fsWriteFile(abs, content, "utf8");
  await assertRealInRoot(root, abs);
  return relative(resolve(root), abs);
}

export interface EditResult {
  path: string;
  replacements: number;
}

/**
 * Replace an exact substring in an existing file. `oldText` must occur exactly
 * once (unless replaceAll) so an edit is unambiguous — mirrors the discipline of
 * a precise code edit. Throws if the file is missing or the match count is
 * wrong, so the agent gets a clear error instead of a silent wrong edit.
 */
export async function editFileSafe(
  root: string,
  relPath: string,
  oldText: string,
  newText: string,
  replaceAll = false,
): Promise<EditResult> {
  const { content } = await readFile(root, relPath);
  if (oldText === "") throw new Error("oldText must not be empty");
  const count = content.split(oldText).length - 1;
  if (count === 0) {
    throw new Error(`oldText not found in ${relPath}; read the file first and copy the exact text`);
  }
  if (count > 1 && !replaceAll) {
    throw new Error(
      `oldText occurs ${count} times in ${relPath}; make it unique or set replaceAll=true`,
    );
  }
  const updated = replaceAll
    ? content.split(oldText).join(newText)
    : content.replace(oldText, newText);
  const path = await writeFileSafe(root, relPath, updated);
  return { path, replacements: replaceAll ? count : 1 };
}

/** List a directory inside the instance (sorted: dirs first, then files). */
export async function listDir(
  root: string,
  relPath = ".",
): Promise<DirEntry[]> {
  const abs = safeResolve(root, relPath);
  await assertRealInRoot(root, abs);
  const entries = await readdir(abs, { withFileTypes: true });
  return entries
    .filter((e) => e.name !== ".git")
    .map((e) => ({
      name: e.name,
      type: e.isDirectory() ? ("dir" as const) : ("file" as const),
    }))
    .sort((a, b) => {
      if (a.type !== b.type) return a.type === "dir" ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
}
