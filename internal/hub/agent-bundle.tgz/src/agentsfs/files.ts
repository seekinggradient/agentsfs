import { execFile } from "node:child_process";
import { randomUUID } from "node:crypto";
import { constants as fsConstants } from "node:fs";
import {
  lstat,
  mkdir,
  open,
  readFile as fsReadFile,
  readdir,
  realpath,
  rename,
  stat,
  unlink,
} from "node:fs/promises";
import { basename, dirname, join, relative, resolve, sep } from "node:path";

/**
 * Path-jailed filesystem access over an AgentsFS instance. Every path is
 * resolved against the instance root and verified to stay inside it, so the
 * agent (and anything it is convinced to do) can never read outside the wiki.
 */

const MAX_FILE_CHARS = 400 * 1024;

export class PathEscapeError extends Error {}

// The lexical safeResolve blocks `../` traversal, but a symlink *inside* the
// root could still point outside it. Verify the canonical (realpath) target
// stays in-root before any read. The root realpath is cached per process.
const rootRealCache = new Map<string, string>();
async function rootReal(root: string): Promise<string> {
  const key = resolve(root);
  let v = rootRealCache.get(key);
  if (v === undefined) {
    v = await realpath(key);
    rootRealCache.set(key, v);
  }
  return v;
}

async function assertRealInRoot(root: string, abs: string): Promise<void> {
  const real = await realpath(abs);
  const base = await rootReal(root);
  if (real !== base && !real.startsWith(base + sep)) {
    throw new PathEscapeError(
      `path escapes the AgentsFS root via symlink: ${relative(resolve(root), abs)}`,
    );
  }
}

function isErrnoException(error: unknown, code: string): boolean {
  return (
    error instanceof Error &&
    "code" in error &&
    (error as NodeJS.ErrnoException).code === code
  );
}

function assertCanonicalInRoot(
  root: string,
  rootCanonical: string,
  targetCanonical: string,
  originalPath: string,
): void {
  if (
    targetCanonical !== rootCanonical &&
    !targetCanonical.startsWith(rootCanonical + sep)
  ) {
    throw new PathEscapeError(
      `path escapes the AgentsFS root via symlink: ${relative(resolve(root), originalPath)}`,
    );
  }
}

/**
 * Create a target's parent one component at a time, following only symlinks
 * whose canonical destinations remain inside the root. `mkdir({ recursive:
 * true })` is unsafe here: it can create directories outside the jail before
 * a post-hoc realpath check notices an escaping parent symlink.
 */
async function prepareCanonicalParent(
  root: string,
  abs: string,
): Promise<string> {
  const rootAbs = resolve(root);
  const rootCanonical = await rootReal(root);
  const parentRel = relative(rootAbs, dirname(abs));
  let currentCanonical = rootCanonical;

  if (parentRel === "") return currentCanonical;

  for (const component of parentRel.split(sep)) {
    const next = join(currentCanonical, component);
    try {
      await mkdir(next);
    } catch (error) {
      if (!isErrnoException(error, "EEXIST")) throw error;
    }

    const info = await lstat(next);
    if (!info.isDirectory() && !info.isSymbolicLink()) {
      throw new Error(
        `${relative(rootAbs, next)} is not a directory`,
      );
    }

    const nextCanonical = await realpath(next);
    assertCanonicalInRoot(root, rootCanonical, nextCanonical, next);
    const canonicalInfo = await stat(nextCanonical);
    if (!canonicalInfo.isDirectory()) {
      throw new Error(`${relative(rootAbs, next)} is not a directory`);
    }
    currentCanonical = nextCanonical;
  }

  return currentCanonical;
}

async function assertNotSymlink(
  abs: string,
  relPath: string,
): Promise<number | undefined> {
  try {
    const info = await lstat(abs);
    if (info.isSymbolicLink()) {
      throw new PathEscapeError(
        `refusing to write through a symlink: ${relPath}`,
      );
    }
    return info.isFile() ? info.mode & 0o777 : undefined;
  } catch (error) {
    if (isErrnoException(error, "ENOENT")) return undefined;
    throw error;
  }
}

/**
 * Resolve `relPath` against `root` and guarantee the result is inside `root`.
 * Absolute inputs are treated as instance-relative. Throws {@link PathEscapeError}
 * on any attempt to escape (e.g. `../../etc/passwd`).
 */
export function safeResolve(root: string, relPath: string): string {
  const rootAbs = resolve(root);
  // Treat a leading "/" as relative to the instance root, not the OS root.
  const cleaned = relPath.replace(/^[/\\]+/, "");
  const target = resolve(rootAbs, cleaned);
  if (target !== rootAbs && !target.startsWith(rootAbs + sep)) {
    throw new PathEscapeError(`path escapes the AgentsFS root: ${relPath}`);
  }
  return target;
}

export interface ReadResult {
  path: string;
  content: string;
  truncated: boolean;
  bytes: number;
}

/** Read a UTF-8 text file inside the instance, capped at {@link MAX_FILE_BYTES}. */
export async function readFile(
  root: string,
  relPath: string,
): Promise<ReadResult> {
  const abs = safeResolve(root, relPath);
  const info = await stat(abs);
  if (info.isDirectory()) {
    throw new Error(`${relPath} is a directory, not a file`);
  }
  await assertRealInRoot(root, abs);
  const buf = await fsReadFile(abs);
  // Decode fully then cap by character count so we never split a multibyte
  // UTF-8 sequence (AgentsFS files are small markdown).
  const full = buf.toString("utf8");
  const truncated = full.length > MAX_FILE_CHARS;
  const content = truncated ? full.slice(0, MAX_FILE_CHARS) : full;
  return {
    path: relative(resolve(root), abs),
    content,
    truncated,
    bytes: buf.length,
  };
}

export interface GrepMatch {
  path: string;
  line: number;
  text: string;
}

/**
 * Literal-by-default ripgrep over the instance. `isRegex` opts into regex.
 * Respects the instance's .gitignore (so `.agentsfs/` and binaries are skipped).
 */
export async function grep(
  root: string,
  pattern: string,
  opts: { glob?: string; isRegex?: boolean; maxResults?: number } = {},
): Promise<GrepMatch[]> {
  const rootAbs = resolve(root);
  const max = opts.maxResults ?? 60;
  const args = [
    "--line-number",
    "--no-heading",
    "--color=never",
    "--smart-case",
    "-g",
    "!.git",
    "-g",
    "!.agentsfs",
  ];
  if (!opts.isRegex) args.push("--fixed-strings");
  if (opts.glob) args.push("-g", opts.glob);
  args.push("--", pattern, rootAbs);

  const stdout = await new Promise<string>((resolveP) => {
    execFile(
      "rg",
      args,
      { timeout: 15_000, maxBuffer: 16 * 1024 * 1024 },
      (_err, out) => resolveP(out ?? ""), // rg exits 1 on no matches; treat as empty
    );
  });

  const matches: GrepMatch[] = [];
  for (const line of stdout.split("\n")) {
    if (!line) continue;
    // Format: <abs-path>:<line>:<text>
    const m = line.match(/^(.*?):(\d+):(.*)$/);
    if (!m) continue;
    const abs = m[1] ?? "";
    matches.push({
      path: relative(rootAbs, abs),
      line: Number(m[2]),
      text: (m[3] ?? "").slice(0, 400),
    });
    if (matches.length >= max) break;
  }
  return matches;
}

export interface DirEntry {
  name: string;
  type: "file" | "dir";
}

/**
 * Create or overwrite a UTF-8 text file inside the instance. Same path jail as
 * reads: safeResolve blocks `../` traversal, parent symlinks are resolved and
 * verified before creating descendants, and final-component symlinks are never
 * followed. The new contents are written to a sibling temporary file and then
 * atomically renamed into place. Parent directories are created as needed.
 * Returns the instance-relative path.
 */
export async function writeFileSafe(
  root: string,
  relPath: string,
  content: string,
): Promise<string> {
  const abs = safeResolve(root, relPath);
  const canonicalParent = await prepareCanonicalParent(root, abs);
  const canonicalTarget = join(canonicalParent, basename(abs));
  const existingMode = await assertNotSymlink(canonicalTarget, relPath);
  const temporary = join(
    canonicalParent,
    `.agentsfs-write-${randomUUID()}.tmp`,
  );
  let handle: Awaited<ReturnType<typeof open>> | undefined;

  try {
    handle = await open(
      temporary,
      fsConstants.O_WRONLY |
        fsConstants.O_CREAT |
        fsConstants.O_EXCL |
        fsConstants.O_NOFOLLOW,
      existingMode ?? 0o666,
    );
    await handle.writeFile(content, "utf8");
    if (existingMode !== undefined) await handle.chmod(existingMode);
    await handle.sync();
    await handle.close();
    handle = undefined;

    // Check again immediately before rename. If this changes after the check,
    // rename replaces the symlink itself atomically rather than following it.
    await assertNotSymlink(canonicalTarget, relPath);
    await rename(temporary, canonicalTarget);
  } finally {
    await handle?.close().catch(() => undefined);
    await unlink(temporary).catch((error: unknown) => {
      if (!isErrnoException(error, "ENOENT")) throw error;
    });
  }

  return relative(resolve(root), abs);
}

export interface EditResult {
  path: string;
  replacements: number;
}

/**
 * Replace an exact substring in an existing file. `oldText` must occur exactly
 * once (unless replaceAll) so an edit is unambiguous — mirrors the discipline of
 * a precise code edit. Throws if the file is missing or the match count is
 * wrong, so the agent gets a clear error instead of a silent wrong edit.
 */
export async function editFileSafe(
  root: string,
  relPath: string,
  oldText: string,
  newText: string,
  replaceAll = false,
): Promise<EditResult> {
  const { content } = await readFile(root, relPath);
  if (oldText === "") throw new Error("oldText must not be empty");
  const count = content.split(oldText).length - 1;
  if (count === 0) {
    throw new Error(`oldText not found in ${relPath}; read the file first and copy the exact text`);
  }
  if (count > 1 && !replaceAll) {
    throw new Error(
      `oldText occurs ${count} times in ${relPath}; make it unique or set replaceAll=true`,
    );
  }
  const updated = replaceAll
    ? content.split(oldText).join(newText)
    : content.replace(oldText, newText);
  const path = await writeFileSafe(root, relPath, updated);
  return { path, replacements: replaceAll ? count : 1 };
}

/** List a directory inside the instance (sorted: dirs first, then files). */
export async function listDir(
  root: string,
  relPath = ".",
): Promise<DirEntry[]> {
  const abs = safeResolve(root, relPath);
  await assertRealInRoot(root, abs);
  const entries = await readdir(abs, { withFileTypes: true });
  return entries
    .filter((e) => e.name !== ".git")
    .map((e) => ({
      name: e.name,
      type: e.isDirectory() ? ("dir" as const) : ("file" as const),
    }))
    .sort((a, b) => {
      if (a.type !== b.type) return a.type === "dir" ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
}
