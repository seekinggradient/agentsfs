import { loadConfig } from "./config.js";
import { createApp, startServer } from "./server/server.js";

// A long-lived server should log and survive a stray rejection rather than die.
process.on("unhandledRejection", (e) => console.error("unhandledRejection:", e));
process.on("uncaughtException", (e) => console.error("uncaughtException:", e));

/** Boot the server over the configured AgentsFS instance. */
async function main() {
  const cfg = loadConfig();
  const ctx = await createApp(cfg);
  await startServer(ctx, cfg.port, cfg.host);
  const caps = ctx.toolCtx.caps;
  console.log(`\n  agentsfs-chat`);
  console.log(`  instance : ${ctx.agent.instanceName}  (${cfg.agentsfsRoot})`);
  console.log(`  reasoner : ${cfg.provider}/${cfg.chatModel}`);
  console.log(`  voice    : ${cfg.realtimeModel} (${cfg.realtimeVoice}, ${cfg.realtimeVad} vad)`);
  console.log(`  domains  : ${caps.domains.join(", ") || "(none)"}`);
  console.log(`  writes   : ${cfg.allowWrites ? `on (as ${cfg.agentName} <${cfg.agentEmail}>)` : "off (read-only)"}`);
  console.log(`\n  → http://${cfg.host}:${cfg.port}\n`);
}

main().catch((e) => {
  console.error("Failed to start:", e.message);
  process.exit(1);
});
