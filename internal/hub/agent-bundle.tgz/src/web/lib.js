// Pure, DOM-free helpers for the web client. Kept separate so they can be unit
// tested in Node without a browser.

export function escapeHtml(s) {
  return String(s).replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
}

/** Return a normalized web URL, or null for schemes that could execute code. */
export function safeHttpUrl(value) {
  try {
    const url = new URL(String(value));
    return url.protocol === "http:" || url.protocol === "https:" ? url.href : null;
  } catch {
    return null;
  }
}

export function inline(s) {
  return s
    .replace(/`([^`]+)`/g, (_, c) => `<code>${c}</code>`)
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    .replace(
      /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
      '<a href="$2" target="_blank" rel="noopener">$1</a>',
    )
    // The coding prompt emits this one proxy-relative application route. Keep
    // the exception exact; arbitrary relative links could target Hub actions.
    .replace(
      /\[([^\]]+)\]\(preview\/\)/g,
      '<a href="preview/" target="_blank" rel="noopener">$1</a>',
    );
}

/** Minimal, injection-safe markdown: headings, lists, code, bold/italic, links. */
export function renderMarkdown(md) {
  const lines = escapeHtml(md).split("\n");
  let html = "";
  let list = null;
  let inCode = false;
  let para = [];
  const flushPara = () => {
    if (para.length) {
      html += `<p>${inline(para.join(" "))}</p>`;
      para = [];
    }
  };
  const closeList = () => {
    if (list) {
      html += `</${list}>`;
      list = null;
    }
  };
  for (const raw of lines) {
    const line = raw.replace(/\s+$/, "");
    if (line.trim().startsWith("```")) {
      flushPara();
      closeList();
      if (!inCode) {
        html += "<pre><code>";
        inCode = true;
      } else {
        html += "</code></pre>";
        inCode = false;
      }
      continue;
    }
    if (inCode) {
      html += line + "\n";
      continue;
    }
    const h = line.match(/^(#{1,3})\s+(.*)$/);
    if (h) {
      flushPara();
      closeList();
      html += `<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`;
      continue;
    }
    const ul = line.match(/^\s*[-*]\s+(.*)$/);
    const ol = line.match(/^\s*\d+\.\s+(.*)$/);
    if (ul || ol) {
      flushPara();
      const want = ul ? "ul" : "ol";
      if (list !== want) {
        closeList();
        html += `<${want}>`;
        list = want;
      }
      html += `<li>${inline((ul || ol)[1])}</li>`;
      continue;
    }
    if (!line.trim()) {
      flushPara();
      closeList();
      continue;
    }
    para.push(line);
  }
  if (inCode) html += "</code></pre>";
  flushPara();
  closeList();
  return html;
}

/**
 * Classify each line of a unified diff by its leading character, so the review
 * proposal card can colour additions/deletions/hunks. Pure + DOM-free so it can
 * be unit-tested. `+++`/`---` file headers are classified as `meta`, not add/del
 * (they must be checked before the single +/- cases).
 */
export function diffToSegments(diff) {
  return String(diff).split("\n").map((line) => {
    let type = "ctx";
    if (
      line.startsWith("+++") ||
      line.startsWith("---") ||
      line.startsWith("diff ") ||
      line.startsWith("index ") ||
      line.startsWith("new file") ||
      line.startsWith("deleted file") ||
      line.startsWith("rename ") ||
      line.startsWith("similarity ")
    ) {
      type = "meta";
    } else if (line.startsWith("@@")) {
      type = "hunk";
    } else if (line.startsWith("+")) {
      type = "add";
    } else if (line.startsWith("-")) {
      type = "del";
    }
    return { type, text: line };
  });
}

// Intra-line diff annotation limits: lines longer than this many tokens skip
// the LCS pass (quadratic DP), and a line whose changed WORD-token fraction
// exceeds the threshold is a rewrite, not an edit — marks would be noise.
const DIFF_MAX_TOKENS = 400;
const DIFF_CHANGED_FRACTION_MAX = 0.7;

// Alternating word/whitespace tokens, preserving whitespace exactly so the
// concatenation of tokens reproduces the line verbatim.
const DIFF_TOKEN_RE = /\S+|\s+/g;

/** Token-level LCS membership: mark which tokens of a and b are NOT common
 *  (i.e. changed). Simple O(n·m) DP — callers cap the token counts. */
function changedTokenMasks(a, b) {
  const n = a.length;
  const m = b.length;
  const dp = [];
  for (let i = 0; i <= n; i++) dp.push(new Uint16Array(m + 1));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const aChanged = new Array(n).fill(true);
  const bChanged = new Array(m).fill(true);
  let i = 0;
  let j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) {
      aChanged[i] = false;
      bChanged[j] = false;
      i++;
      j++;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      i++;
    } else {
      j++;
    }
  }
  return { aChanged, bChanged };
}

/** Fraction of WORD tokens (whitespace tokens excluded) marked changed. */
function changedWordFraction(tokens, mask) {
  let words = 0;
  let changed = 0;
  for (let i = 0; i < tokens.length; i++) {
    if (/\S/.test(tokens[i])) {
      words++;
      if (mask[i]) changed++;
    }
  }
  return words ? changed / words : 0;
}

/** Merge consecutive tokens with the same changed-flag into single spans. */
function coalesceSpans(tokens, mask) {
  const spans = [];
  for (let i = 0; i < tokens.length; i++) {
    const changed = !!mask[i];
    const last = spans[spans.length - 1];
    if (last && last.changed === changed) last.text += tokens[i];
    else spans.push({ text: tokens[i], changed });
  }
  return spans;
}

/** Annotate one del/add line pair with word-level change spans (in place). */
function annotatePair(delSeg, addSeg) {
  // Content after the leading -/+ marker; the marker renders separately.
  const a = delSeg.text.slice(1).match(DIFF_TOKEN_RE) || [];
  const b = addSeg.text.slice(1).match(DIFF_TOKEN_RE) || [];
  if (!a.length || !b.length) return;
  if (a.length > DIFF_MAX_TOKENS || b.length > DIFF_MAX_TOKENS) return;
  const { aChanged, bChanged } = changedTokenMasks(a, b);
  if (!aChanged.some(Boolean) && !bChanged.some(Boolean)) return; // identical content
  if (
    changedWordFraction(a, aChanged) > DIFF_CHANGED_FRACTION_MAX ||
    changedWordFraction(b, bChanged) > DIFF_CHANGED_FRACTION_MAX
  ) {
    return; // a rewrite — whole-line coloring reads better than confetti marks
  }
  delSeg.spans = coalesceSpans(a, aChanged);
  addSeg.spans = coalesceSpans(b, bChanged);
}

/**
 * Intra-line annotation pass over {@link diffToSegments} output. Markdown
 * paragraphs are single long source lines, so a small edit otherwise renders as
 * two near-identical walls of red/green with the change far off-screen.
 * Pairing rule: a run of consecutive `del` lines immediately followed by a run
 * of consecutive `add` lines of EQUAL length pairs i-th with i-th; unequal
 * runs keep plain whole-line coloring. Paired segments gain
 * `spans: [{text, changed}]` covering the line content AFTER the leading -/+
 * marker. Pure + DOM-free so it's unit-testable.
 */
export function annotateDiffSegments(segments) {
  const out = segments.map((s) => ({ ...s }));
  let i = 0;
  while (i < out.length) {
    if (out[i].type !== "del") {
      i++;
      continue;
    }
    let delEnd = i;
    while (delEnd < out.length && out[delEnd].type === "del") delEnd++;
    let addEnd = delEnd;
    while (addEnd < out.length && out[addEnd].type === "add") addEnd++;
    const dels = delEnd - i;
    const adds = addEnd - delEnd;
    if (adds > 0 && dels === adds) {
      for (let k = 0; k < dels; k++) annotatePair(out[i + k], out[delEnd + k]);
    }
    i = addEnd;
  }
  return out;
}

/**
 * Render a unified diff to injection-safe HTML: one `<div class="dl …">` per
 * line, coloured by {@link diffToSegments}, with word-level
 * `<span class="dchg">` marks from {@link annotateDiffSegments} on paired -/+
 * lines. Built token-by-token — every text fragment is HTML-escaped BEFORE any
 * span markup is added, never after. The leading -/+ marker stays outside the
 * spans so it keeps the plain line tint.
 */
export function renderDiff(diff) {
  return annotateDiffSegments(diffToSegments(diff))
    .map((s) => {
      if (s.spans) {
        const marker = escapeHtml(s.text[0] || "");
        const body = s.spans
          .map((sp) =>
            sp.changed
              ? `<span class="dchg">${escapeHtml(sp.text)}</span>`
              : escapeHtml(sp.text),
          )
          .join("");
        return `<div class="dl ${s.type}">${marker}${body}</div>`;
      }
      return `<div class="dl ${s.type}">${escapeHtml(s.text) || "&nbsp;"}</div>`;
    })
    .join("");
}

/**
 * Decide what the working-tree banner should do for a `tree` SSE event.
 * Contract: the server emits `tree` after EVERY non-review chat turn as
 * {files, diff, ahead} — `files`/`diff` describe uncommitted changes, `ahead`
 * counts committed-but-unpushed work (a checkpoint whose push failed;
 * no-upstream → 0). {files: [], diff: "", ahead: 0} = all clean → dismiss.
 * Three visible states:
 * - "dirty":  uncommitted changes (ahead, if any, is folded into the label);
 *             the banner offers View/Commit/Discard (commit also pushes).
 * - "ahead":  clean tree but unpushed commits; a single Push action.
 * - hidden:   all clean, or a pending proposal card already shows the state.
 * Pure + DOM-free. Returns { show, reason, label?, additions?, deletions?, ahead }.
 */
export function treeBannerDecision(data, hasPendingProposal) {
  const files = data && Array.isArray(data.files) ? data.files : [];
  const ahead = Math.max(0, Number(data && data.ahead) || 0);
  const aheadLabel = `${ahead} unpushed commit${ahead === 1 ? "" : "s"}`;
  if (!files.length && !ahead) return { show: false, reason: "clean", ahead: 0 };
  if (hasPendingProposal) return { show: false, reason: "proposal", ahead };
  if (!files.length) {
    return { show: true, reason: "ahead", ahead, label: aheadLabel };
  }
  let additions = 0;
  let deletions = 0;
  for (const f of files) {
    additions += Number(f.additions) || 0;
    deletions += Number(f.deletions) || 0;
  }
  return {
    show: true,
    reason: "dirty",
    additions,
    deletions,
    ahead,
    label:
      `Uncommitted changes — ${files.length} file${files.length === 1 ? "" : "s"} (+${additions} −${deletions})` +
      (ahead ? ` · ${aheadLabel}` : ""),
  };
}

/** How long a staged mobile review handoff stays valid (localStorage transport). */
export const PENDING_HANDOFF_MAX_AGE_MS = 15 * 60 * 1000;

/**
 * Decide whether a pending mobile review handoff should be consumed. On phones
 * the hub stages the handoff payload in localStorage (`afs-review-pending`) and
 * navigates to the agent; the agent reads-and-deletes the key on load and runs
 * this check. Pure + DOM-free so it's unit-testable.
 *
 * Valid = an object with a non-empty comments array, a nonce that differs from
 * the last-consumed one (replay/back-button protection), and a numeric `ts`
 * within {@link PENDING_HANDOFF_MAX_AGE_MS} of now. Anything else is stale or
 * malformed and must be silently discarded.
 */
export function validatePendingHandoff(payload, lastNonce, now = Date.now(), maxAgeMs = PENDING_HANDOFF_MAX_AGE_MS) {
  if (!payload || typeof payload !== "object") return false;
  if (!Array.isArray(payload.comments) || !payload.comments.length) return false;
  if (!payload.nonce || typeof payload.nonce !== "string") return false;
  if (lastNonce && payload.nonce === lastNonce) return false;
  if (typeof payload.ts !== "number" || !Number.isFinite(payload.ts)) return false;
  if (Math.abs(now - payload.ts) > maxAgeMs) return false;
  return true;
}

/**
 * Parse complete SSE frames out of a buffer. Returns the parsed frames and the
 * leftover (incomplete) buffer to carry into the next read.
 * Each frame: { event, data } where data is the raw string after "data:".
 */
export function splitSSE(buffer) {
  const frames = [];
  let buf = buffer;
  let idx;
  while ((idx = buf.indexOf("\n\n")) !== -1) {
    const block = buf.slice(0, idx);
    buf = buf.slice(idx + 2);
    let event = "message";
    const dataLines = [];
    for (const line of block.split("\n")) {
      if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
    }
    if (dataLines.length) frames.push({ event, data: dataLines.join("\n") });
  }
  return { frames, rest: buf };
}
