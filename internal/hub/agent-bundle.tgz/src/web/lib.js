// Pure, DOM-free helpers for the web client. Kept separate so they can be unit
// tested in Node without a browser.

export function escapeHtml(s) {
  return String(s).replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
}

/** Return a normalized web URL, or null for schemes that could execute code. */
export function safeHttpUrl(value) {
  try {
    const url = new URL(String(value));
    return url.protocol === "http:" || url.protocol === "https:" ? url.href : null;
  } catch {
    return null;
  }
}

export function inline(s) {
  return s
    .replace(/`([^`]+)`/g, (_, c) => `<code>${c}</code>`)
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    .replace(
      /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
      '<a href="$2" target="_blank" rel="noopener">$1</a>',
    )
    // The coding prompt emits this one proxy-relative application route. Keep
    // the exception exact; arbitrary relative links could target Hub actions.
    .replace(
      /\[([^\]]+)\]\(preview\/\)/g,
      '<a href="preview/" target="_blank" rel="noopener">$1</a>',
    );
}

/** Minimal, injection-safe markdown: headings, lists, code, bold/italic, links. */
export function renderMarkdown(md) {
  const lines = escapeHtml(md).split("\n");
  let html = "";
  let list = null;
  let inCode = false;
  let para = [];
  const flushPara = () => {
    if (para.length) {
      html += `<p>${inline(para.join(" "))}</p>`;
      para = [];
    }
  };
  const closeList = () => {
    if (list) {
      html += `</${list}>`;
      list = null;
    }
  };
  for (const raw of lines) {
    const line = raw.replace(/\s+$/, "");
    if (line.trim().startsWith("```")) {
      flushPara();
      closeList();
      if (!inCode) {
        html += "<pre><code>";
        inCode = true;
      } else {
        html += "</code></pre>";
        inCode = false;
      }
      continue;
    }
    if (inCode) {
      html += line + "\n";
      continue;
    }
    const h = line.match(/^(#{1,3})\s+(.*)$/);
    if (h) {
      flushPara();
      closeList();
      html += `<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`;
      continue;
    }
    const ul = line.match(/^\s*[-*]\s+(.*)$/);
    const ol = line.match(/^\s*\d+\.\s+(.*)$/);
    if (ul || ol) {
      flushPara();
      const want = ul ? "ul" : "ol";
      if (list !== want) {
        closeList();
        html += `<${want}>`;
        list = want;
      }
      html += `<li>${inline((ul || ol)[1])}</li>`;
      continue;
    }
    if (!line.trim()) {
      flushPara();
      closeList();
      continue;
    }
    para.push(line);
  }
  if (inCode) html += "</code></pre>";
  flushPara();
  closeList();
  return html;
}

/**
 * Classify each line of a unified diff by its leading character, so the review
 * proposal card can colour additions/deletions/hunks. Pure + DOM-free so it can
 * be unit-tested. `+++`/`---` file headers are classified as `meta`, not add/del
 * (they must be checked before the single +/- cases).
 */
export function diffToSegments(diff) {
  return String(diff).split("\n").map((line) => {
    let type = "ctx";
    if (
      line.startsWith("+++") ||
      line.startsWith("---") ||
      line.startsWith("diff ") ||
      line.startsWith("index ") ||
      line.startsWith("new file") ||
      line.startsWith("deleted file") ||
      line.startsWith("rename ") ||
      line.startsWith("similarity ")
    ) {
      type = "meta";
    } else if (line.startsWith("@@")) {
      type = "hunk";
    } else if (line.startsWith("+")) {
      type = "add";
    } else if (line.startsWith("-")) {
      type = "del";
    }
    return { type, text: line };
  });
}

/** Render a unified diff to injection-safe HTML: one `<div class="dl …">` per
 *  line, coloured by {@link diffToSegments}. Every line is HTML-escaped. */
export function renderDiff(diff) {
  return diffToSegments(diff)
    .map((s) => `<div class="dl ${s.type}">${escapeHtml(s.text) || "&nbsp;"}</div>`)
    .join("");
}

/**
 * Parse complete SSE frames out of a buffer. Returns the parsed frames and the
 * leftover (incomplete) buffer to carry into the next read.
 * Each frame: { event, data } where data is the raw string after "data:".
 */
export function splitSSE(buffer) {
  const frames = [];
  let buf = buffer;
  let idx;
  while ((idx = buf.indexOf("\n\n")) !== -1) {
    const block = buf.slice(0, idx);
    buf = buf.slice(idx + 2);
    let event = "message";
    const dataLines = [];
    for (const line of block.split("\n")) {
      if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
    }
    if (dataLines.length) frames.push({ event, data: dataLines.join("\n") });
  }
  return { frames, rest: buf };
}
