// agentsfs-chat web client: streaming chat + WebRTC voice over the same tools.
import { escapeHtml, renderDiff, renderMarkdown, safeHttpUrl, splitSSE, treeBannerDecision, validatePendingHandoff } from "./lib.js";

const $ = (id) => document.getElementById(id);
const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
};

const history = [];
let config = null;
let currentConversationId = null; // server-persisted conversation, when enabled

// Agentic co-editing "review mode". Set when the hub hands off inline comments;
// stays set for the conversation so typed follow-up feedback also runs as a
// restricted review turn. Cleared after the user approves & commits a proposal,
// and whenever the user switches to another conversation or starts a new chat
// (review mode is scoped to the handed-off conversation, never carried across).
// Discard does NOT exit review mode — the user iterates after discarding.
const reviewMode = { active: false, user: null, repo: null, path: null, head: null };

function exitReviewMode() {
  reviewMode.active = false;
  reviewMode.user = null;
  reviewMode.repo = null;
  reviewMode.path = null;
  reviewMode.head = null;
}

// Client-side price table ($/1M tokens) for the realtime voice model, so we can
// show live spend. Audio dominates. gpt-realtime-mini rates (mini audio from a
// secondary source — treat the $ as an estimate). Edit to match your plan.
const VOICE_PRICE = {
  "gpt-realtime-mini": { textIn: 0.6, textOut: 2.4, audioIn: 10, audioOut: 20 },
  "gpt-realtime": { textIn: 4, textOut: 24, audioIn: 32, audioOut: 64 },
};
const fmtUsd = (u) => `$${u < 0.01 ? u.toFixed(4) : u.toFixed(3)}`;
const kfmt = (n) => (n >= 1000 ? (n / 1000).toFixed(1) + "k" : String(n));

// Running session cost across BOTH modes. "text" = gpt-5.1 reasoning (chat +
// voice consult); "voice" = realtime audio.
const sessionCost = {
  textIn: 0,
  textOut: 0,
  textUsd: 0,
  voiceAudioIn: 0,
  voiceAudioOut: 0,
  voiceUsd: 0,
};

function addTextCost(usage, costUsd) {
  if (usage) {
    sessionCost.textIn += usage.inputTokens || 0;
    sessionCost.textOut += usage.outputTokens || 0;
  }
  if (costUsd) sessionCost.textUsd += costUsd;
  renderHUD();
}

function renderHUD() {
  const total = sessionCost.textUsd + sessionCost.voiceUsd;
  let s = `session ~${fmtUsd(total)} · text ${kfmt(sessionCost.textIn)} in / ${kfmt(sessionCost.textOut)} out`;
  if (sessionCost.voiceAudioIn || sessionCost.voiceAudioOut) {
    s += ` · voice ${kfmt(sessionCost.voiceAudioIn)} / ${kfmt(sessionCost.voiceAudioOut)} audio`;
  }
  $("hud").textContent = s;
}

// ---------- citations ----------
function chip(c) {
  const isUrlCitation = c.type === "url";
  const url = isUrlCitation ? safeHttpUrl(c.url) : null;
  const label = c.label || c.path || c.url;
  const node = el("button", `chip ${isUrlCitation ? "url" : "file"}`, label);
  node.title = c.url || c.path || "";
  node.addEventListener("click", () => {
    if (url) window.open(url, "_blank", "noopener");
    else if (isUrlCitation) return;
    else openFile(c.path);
  });
  if (isUrlCitation && !url) {
    node.disabled = true;
    node.title = "Invalid citation URL";
  }
  return node;
}
function renderCitations(container, citations) {
  container.innerHTML = "";
  if (!citations || !citations.length) return;
  for (const c of citations) container.appendChild(chip(c));
}

// ---------- drawer (file viewer) ----------
async function openFile(path) {
  $("drawerTitle").textContent = path;
  $("drawerBody").textContent = "Loading…";
  $("drawer").classList.remove("hidden");
  $("scrim").classList.remove("hidden");
  try {
    const r = await fetch("api/tools/call", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: "read_file", args: { path } }),
    });
    const data = await r.json();
    $("drawerBody").textContent = data.content || "(empty)";
  } catch (e) {
    $("drawerBody").textContent = "Failed to load file: " + e.message;
  }
}
function closeDrawer() {
  $("drawer").classList.add("hidden");
  $("scrim").classList.add("hidden");
}

// ---------- chat ----------
function addMessage(role) {
  // The welcome/suggestions are re-rendered dynamically with only a class (no
  // id), so remove by class — otherwise they linger above the conversation.
  document.querySelector(".welcome")?.remove();
  const wrap = el("div", `msg ${role}`);
  const trace = el("div", "tool-trace");
  trace.style.display = "none";
  const bubble = el("div", "bubble");
  const cites = el("div", "citations");
  const meta = el("div", "meta");
  if (role === "assistant") wrap.appendChild(trace);
  wrap.appendChild(bubble);
  if (role === "assistant") {
    wrap.appendChild(cites);
    wrap.appendChild(meta);
  }
  $("messages").appendChild(wrap);
  scrollDown();
  return { wrap, trace, bubble, cites, meta };
}
function scrollDown() {
  const m = $("messages");
  m.scrollTop = m.scrollHeight;
}

async function send(message, opts = {}) {
  if (!message.trim()) return;
  const review = !!opts.review;
  const u = addMessage("user");
  u.bubble.textContent = message;

  const a = addMessage("assistant");
  a.bubble.classList.add("cursor");
  let text = "";
  const tools = [];

  setComposerEnabled(false);
  // Lazily open a persisted conversation on the first message (keeps empty
  // conversations from cluttering the list).
  if (config?.persistConversations && !currentConversationId) {
    try {
      const r = await fetch("api/conversations", { method: "POST", headers: { "Content-Type": "application/json" } });
      if (r.ok) currentConversationId = (await r.json()).id;
    } catch { /* fall back to in-memory */ }
  }
  try {
    await streamSSE("api/chat", { message, history, conversationId: currentConversationId, review: review || undefined }, (event, data) => {
      if (event === "delta") {
        text += data.text;
        a.bubble.innerHTML = renderMarkdown(text);
        a.bubble.classList.add("cursor");
        scrollDown();
      } else if (event === "reset") {
        // A pre-tool round emitted interim prose; discard it.
        text = "";
        a.bubble.innerHTML = "";
        a.bubble.classList.add("cursor");
      } else if (event === "tool") {
        tools.push(`${data.name}(${shortArgs(data.args)})`);
        a.trace.style.display = "";
        a.trace.innerHTML = tools.map((t) => `<span class="t">↳ ${escapeHtml(t)}</span>`).join("  ");
        scrollDown();
      } else if (event === "instance") {
        // The agent switched knowledge base mid-turn — reflect it in the topbar.
        setActiveInstance(data.name);
      } else if (event === "proposal") {
        // Review turn left changes in the working tree — offer approve/discard.
        renderProposalCard(data);
      } else if (event === "tree") {
        // Post-turn working-tree state (non-review turns): update or dismiss
        // the persistent uncommitted-changes banner.
        updateTreeBanner(data);
      } else if (event === "done") {
        if (data.text && !text) text = data.text;
        a.bubble.innerHTML = renderMarkdown(text);
        a.bubble.classList.remove("cursor");
        renderCitations(a.cites, data.citations);
        if (data.usage) {
          const c = data.costUsd != null ? ` · ~${fmtUsd(data.costUsd)} est` : "";
          a.meta.textContent = `${data.model} · ${data.usage.inputTokens}+${data.usage.outputTokens} tok${c}`;
        }
        addTextCost(data.usage, data.costUsd);
        history.push({ role: "user", content: message });
        history.push({ role: "assistant", content: text });
        scrollDown();
      } else if (event === "error") {
        a.bubble.classList.remove("cursor");
        a.bubble.innerHTML = `<span class="error">Error: ${escapeHtml(data.message)}</span>`;
      }
    });
  } catch (e) {
    a.bubble.classList.remove("cursor");
    a.bubble.innerHTML = `<span class="error">Error: ${escapeHtml(e.message)}</span>`;
  } finally {
    setComposerEnabled(true);
  }
}

function shortArgs(args) {
  try {
    const s = JSON.stringify(args);
    return s.length > 60 ? s.slice(0, 57) + "…" : s;
  } catch {
    return "";
  }
}

async function streamSSE(url, body, onEvent) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const { frames, rest } = splitSSE(buf);
    buf = rest;
    for (const f of frames) {
      try { onEvent(f.event, JSON.parse(f.data)); } catch { /* ignore */ }
    }
  }
}

function setComposerEnabled(on) {
  $("input").disabled = !on;
  $("sendBtn").disabled = !on;
  if (on) $("input").focus();
}

// ---------- review mode (agentic co-editing) ----------
// Two handoff transports, one downstream path:
// - Desktop: the hub posts `afs-review-handoff` into this iframe (retried until
//   acked). index.html buffers it into window.__afsReviewQueue and acks
//   immediately; drainReviewQueue consumes it here.
// - Phone: the dock is a full-page navigation, so the hub stages the payload in
//   the SAME-ORIGIN localStorage key `afs-review-pending` and navigates here;
//   consumePendingHandoff reads-and-deletes it on load (nonce/ts validated).
// Both feed startReviewHandoff: focus the repo, compose the numbered review
// message, run a restricted review turn; the `proposal` SSE event renders an
// approve/discard card.

let lastHandoffSig = null;

const PENDING_HANDOFF_KEY = "afs-review-pending";
const CONSUMED_NONCE_KEY = "afs-review-consumed";

// Mobile transport: consume a handoff the hub staged in localStorage before
// navigating here. Consume-on-read (the key is deleted BEFORE validation) so a
// reload/back-button never replays it; the last-consumed nonce is remembered as
// a second replay guard; stale (>15 min) or malformed payloads are silently
// discarded (validatePendingHandoff in lib.js — unit-tested).
function consumePendingHandoff() {
  let payload = null;
  try {
    const raw = localStorage.getItem(PENDING_HANDOFF_KEY);
    if (!raw) return;
    localStorage.removeItem(PENDING_HANDOFF_KEY);
    payload = JSON.parse(raw);
  } catch {
    try { localStorage.removeItem(PENDING_HANDOFF_KEY); } catch { /* unavailable */ }
    return;
  }
  let lastNonce = null;
  try { lastNonce = localStorage.getItem(CONSUMED_NONCE_KEY); } catch { /* unavailable */ }
  if (!validatePendingHandoff(payload, lastNonce)) return;
  try { localStorage.setItem(CONSUMED_NONCE_KEY, payload.nonce); } catch { /* unavailable */ }
  startReviewHandoff(payload);
}

function drainReviewQueue() {
  const q = window.__afsReviewQueue || [];
  window.__afsReviewQueue = [];
  if (!q.length) return;
  // The hub retries the SAME handoff until acked, so the queue may hold several
  // identical copies — handle only the most recent, and only once. The per-click
  // nonce keeps a deliberate re-handoff of unchanged comments (e.g. after a
  // Discard) distinct from those retry duplicates.
  const payload = q[q.length - 1];
  const sig = JSON.stringify([
    payload.nonce,
    payload.repo,
    payload.path,
    payload.head,
    (payload.comments || []).map((c) => c.id),
  ]);
  if (sig === lastHandoffSig) return;
  lastHandoffSig = sig;
  startReviewHandoff(payload);
}

// Turn the handed-off comments into a numbered review request. The quoted text
// anchors each comment to a passage in the rendered file; the agent locates it
// in the markdown source. Kept plain so the user sees exactly what was sent.
function composeReviewMessage(payload) {
  const comments = payload.comments || [];
  const lines = [];
  lines.push(
    `I've left ${comments.length} comment${comments.length === 1 ? "" : "s"} on the rendered file \`${payload.path}\`` +
      (payload.head ? ` (as of commit ${payload.head}).` : "."),
  );
  lines.push(
    "Please address each one — answer questions, and make edits where a change is called for. Do not commit or push — I'll review any changes and approve them myself.",
  );
  lines.push("");
  comments.forEach((c, i) => {
    // Duplicate passages: say WHICH occurrence is meant, with leading context,
    // so the agent edits the right one.
    let where = "";
    if (typeof c.occurrence === "number" && c.occurrence > 0) {
      where = ` (occurrence ${c.occurrence + 1}${c.prefix ? `; appears after “…${c.prefix}”` : ""})`;
    }
    lines.push(`${i + 1}. On the passage “${c.quote}”${where}:`);
    if (c.note) lines.push(`   ${c.note}`);
  });
  return lines.join("\n");
}

async function startReviewHandoff(payload) {
  if (!payload || !Array.isArray(payload.comments) || !payload.comments.length) return;
  reviewMode.active = true;
  reviewMode.user = payload.user || null;
  reviewMode.repo = payload.repo || null;
  reviewMode.path = payload.path || null;
  reviewMode.head = payload.head || null;
  // Focus the payload's repo so the review turn edits the right checkout. In
  // workspace mode a failed focus must ABORT the handoff: proceeding would run
  // the review turn against the workspace root, where edits land in the wrong
  // place and git can't build a proposal — a silent no-op from the user's side.
  // (Single-mode servers have no focus; there the active root is already right.)
  if (payload.repo) {
    try {
      const r = await fetch("api/focus", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ repo: payload.repo }),
      });
      if (r.ok) {
        applyConfig(await r.json());
      } else if (isWorkspace()) {
        let detail = "";
        try { detail = (await r.json()).error || ""; } catch { /* opaque */ }
        const m = addMessage("assistant");
        m.bubble.textContent =
          `Couldn't hand off: focusing "${payload.repo}" failed` +
          (detail ? ` (${detail})` : "") +
          ". Pick the knowledge base from the dropdown and try again.";
        reviewMode.active = false;
        return;
      }
    } catch { /* network hiccup: fall through, the turn may still be focused */ }
  }
  send(composeReviewMessage(payload), { review: true });
}

// At most one *pending* proposal card at a time; a committed one stays as a
// record. A fresh proposal replaces the pending card.
function removeProposalCard() {
  document.querySelectorAll(".proposal-card:not(.committed)").forEach((n) => n.remove());
}

function renderProposalCard(data) {
  removeProposalCard();
  // The card shows the same dirty state the banner would — never both.
  removeTreeBanner();
  const card = el("div", "proposal-card");

  const head = el("div", "proposal-head");
  head.appendChild(el("span", "proposal-title", "Proposed changes"));
  const files = el("div", "proposal-files");
  for (const f of data.files || []) {
    const chip = el("span", "proposal-file");
    chip.appendChild(el("span", "pf-path", f.path));
    const stat = el("span", "pf-stat");
    stat.innerHTML =
      `<span class="pf-add">+${Number(f.additions) || 0}</span>` +
      `<span class="pf-del">−${Number(f.deletions) || 0}</span>`;
    chip.appendChild(stat);
    files.appendChild(chip);
  }
  head.appendChild(files);
  card.appendChild(head);

  const diff = el("pre", "diff");
  diff.innerHTML = renderDiff(data.diff || "");
  card.appendChild(diff);

  const msgInput = el("input", "commit-msg");
  msgInput.type = "text";
  // Prefer the agent's own description of the change (the `Commit:` line the
  // server extracted); the canned path default is only the fallback. Editable —
  // the user has final say.
  msgInput.value =
    data.suggestedMessage ||
    (reviewMode.path
      ? `Resolve review comments in ${reviewMode.path}`
      : "Resolve review comments");
  msgInput.setAttribute("aria-label", "Commit message");
  card.appendChild(msgInput);

  const status = el("div", "proposal-status");
  card.appendChild(status);

  const actions = el("div", "proposal-actions");
  const discard = el("button", "btn ghost", "Discard");
  const approve = el("button", "btn send", "Approve & commit");
  actions.appendChild(discard);
  actions.appendChild(approve);
  card.appendChild(actions);

  approve.addEventListener("click", () =>
    approveProposal(data, card, msgInput, status, approve, discard),
  );
  discard.addEventListener("click", () =>
    discardProposal(card, status, approve, discard),
  );

  $("messages").appendChild(card);
  scrollDown();
}

async function approveProposal(data, card, msgInput, status, approve, discard) {
  approve.disabled = true;
  discard.disabled = true;
  status.className = "proposal-status";
  status.textContent = "Committing…";
  try {
    const res = await fetch("api/review/commit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: msgInput.value.trim() || undefined,
        // Guard: the server 409s if the focused repo changed since the proposal.
        repo: reviewMode.repo || undefined,
      }),
    });
    const out = await res.json();
    if (!res.ok) throw new Error(out.error || "commit failed");
    if (out.pushed) {
      // Fully landed on the hub. Capture the note identity BEFORE exiting
      // review mode — the draft clear and the back-link both need it.
      const note = { user: reviewMode.user, repo: reviewMode.repo, path: reviewMode.path };
      const embedded = window.parent !== window;
      if (embedded) {
        // Desktop (iframe in the hub dock): tell the hub page to refresh — it
        // clears the drafts and reloads the note. Only NOW: doing so on an
        // unpushed commit would show stale content with the comments gone.
        const filePaths = (data.files || []).map((f) => f.path);
        try {
          window.parent.postMessage(
            { type: "afs-review-committed", commit: out.commit, files: filePaths },
            location.origin,
          );
        } catch { /* postMessage unavailable */ }
      }
      // Same-origin, so the hub's draft key is directly reachable — clear it
      // here too. On phones (no hub page listening) this is the ONLY clear.
      if (note.user && note.repo && note.path) {
        try { localStorage.removeItem(`afs-review:${note.user}/${note.repo}/${note.path}`); } catch { /* unavailable */ }
      }
      status.textContent = `Committed ${out.commit} · pushed`;
      status.classList.add("ok");
      card.classList.add("committed");
      msgInput.disabled = true;
      // Phone (running top-level): give the user a way back to the note.
      if (!embedded && note.user && note.repo && note.path) {
        const back = el("a", "proposal-backlink", "View the updated note →");
        back.href =
          "/" + encodeURIComponent(note.user) + "/" + encodeURIComponent(note.repo) +
          "/blob/" + note.path.split("/").map(encodeURIComponent).join("/");
        card.appendChild(back);
      }
      exitReviewMode();
    } else if (out.commit) {
      // Committed on the sprite but the push didn't reach the hub. The commit
      // endpoint is idempotent, so a re-POST just retries the push.
      status.textContent = "Committed on the agent's machine — push to the hub failed. Retry?";
      status.classList.add("err");
      approve.textContent = "Retry push";
      approve.disabled = false;
    } else {
      // Clean tree, nothing ahead of the hub — nothing to do. Leave Discard
      // enabled so the stale card can be dismissed.
      status.textContent = "Nothing to commit";
      discard.disabled = false;
    }
  } catch (e) {
    status.textContent = "Error: " + e.message;
    status.classList.add("err");
    approve.disabled = false;
    discard.disabled = false;
  }
}

async function discardProposal(card, status, approve, discard) {
  approve.disabled = true;
  discard.disabled = true;
  status.className = "proposal-status";
  status.textContent = "Discarding…";
  try {
    const res = await fetch("api/review/discard", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      // Same wrong-repo guard as approve (server 409s on a focus mismatch).
      body: JSON.stringify({ repo: reviewMode.repo || undefined }),
    });
    const out = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(out.error || "discard failed");
    // Stay in review mode: discarding a proposal is part of iterating.
    card.remove();
  } catch (e) {
    status.textContent = "Error: " + e.message;
    status.classList.add("err");
    approve.disabled = false;
    discard.disabled = false;
  }
}

// ---------- working-tree banner (checkpoint drafts + unpushed commits) ----------
// The agent batches edits in the working tree and commits at checkpoints, so a
// turn can legitimately end dirty — or clean but with a checkpoint commit whose
// push failed. The server emits a `tree` event after every non-review chat turn
// ({files, diff, ahead}; all-zero = clean); ONE persistent banner reflects the
// latest state — updated in place, dismissed when clean, and suppressed while a
// pending proposal card already shows the same dirt. Commit/Discard/Push reuse
// the deterministic review endpoints (dual-use; commit retries the push on a
// clean-but-ahead tree, including one rebase).

let treeBannerEl = null;
let lastTreeDiff = "";

function hasPendingProposal() {
  return !!document.querySelector(".proposal-card:not(.committed)");
}

function removeTreeBanner() {
  if (treeBannerEl) {
    treeBannerEl.remove();
    treeBannerEl = null;
  }
}

// Clean tree, unpushed checkpoint commit(s): a slim bar with one Push action.
function renderAheadBanner(decision) {
  const banner = el("div", "tree-banner");
  const row = el("div", "tb-row");
  row.appendChild(el("span", "tb-dot"));
  row.appendChild(el("span", "tb-label", decision.label));
  const actions = el("div", "tb-actions");
  const push = el("button", "tb-btn tb-commit", "Push");
  actions.appendChild(push);
  row.appendChild(actions);
  banner.appendChild(row);
  const status = el("div", "tb-status");
  banner.appendChild(status);

  push.addEventListener("click", async () => {
    push.disabled = true;
    status.className = "tb-status";
    status.textContent = "Pushing…";
    try {
      // On a clean-but-ahead tree the commit endpoint just retries the push
      // (with one rebase if the remote moved).
      const res = await fetch("api/review/commit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ repo: activeRepo() || undefined }),
      });
      const out = await res.json();
      if (!res.ok) throw new Error(out.error || "push failed");
      if (out.pushed || !out.commit) {
        removeTreeBanner(); // landed (or nothing was ahead after all)
      } else {
        status.textContent = "Push failed — try again.";
        status.classList.add("err");
        push.disabled = false;
      }
    } catch (e) {
      status.textContent = "Error: " + e.message;
      status.classList.add("err");
      push.disabled = false;
    }
  });

  $("composer").parentNode.insertBefore(banner, $("composer"));
  treeBannerEl = banner;
}

function updateTreeBanner(data) {
  const decision = treeBannerDecision(data, hasPendingProposal());
  removeTreeBanner();
  if (!decision.show) return;
  if (decision.reason === "ahead") {
    renderAheadBanner(decision);
    return;
  }
  lastTreeDiff = data.diff || "";

  const banner = el("div", "tree-banner");
  const row = el("div", "tb-row");
  row.appendChild(el("span", "tb-dot"));
  row.appendChild(el("span", "tb-label", decision.label));
  const actions = el("div", "tb-actions");
  const view = el("button", "tb-btn", "View");
  const commit = el("button", "tb-btn tb-commit", "Commit");
  const discard = el("button", "tb-btn", "Discard");
  actions.appendChild(view);
  actions.appendChild(commit);
  actions.appendChild(discard);
  row.appendChild(actions);
  banner.appendChild(row);

  const status = el("div", "tb-status");
  banner.appendChild(status);

  // View: expand/collapse the diff (same renderer as the proposal card).
  let diffEl = null;
  view.addEventListener("click", () => {
    if (diffEl) {
      diffEl.remove();
      diffEl = null;
      view.textContent = "View";
      return;
    }
    diffEl = el("pre", "diff");
    diffEl.innerHTML = renderDiff(lastTreeDiff);
    banner.appendChild(diffEl);
    view.textContent = "Hide";
  });

  // Commit: reveal an inline message input, then POST the shared endpoint.
  let commitRow = null;
  commit.addEventListener("click", async () => {
    resetDiscardConfirm();
    if (!commitRow) {
      commitRow = el("div", "tb-commit-row");
      const input = el("input");
      input.type = "text";
      input.placeholder = "Describe the change…";
      const go = el("button", "tb-btn tb-commit", "Commit & push");
      commitRow.appendChild(input);
      commitRow.appendChild(go);
      banner.insertBefore(commitRow, status);
      input.focus();
      go.addEventListener("click", () => doBannerCommit(input, go));
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          doBannerCommit(input, go);
        }
      });
      return;
    }
    commitRow.remove();
    commitRow = null;
  });

  async function doBannerCommit(input, go) {
    go.disabled = true;
    status.className = "tb-status";
    status.textContent = "Committing…";
    try {
      const res = await fetch("api/review/commit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: input.value.trim() || undefined,
          repo: activeRepo() || undefined,
        }),
      });
      const out = await res.json();
      if (!res.ok) throw new Error(out.error || "commit failed");
      if (out.pushed) {
        removeTreeBanner(); // tree is clean and on the hub
      } else if (out.commit) {
        status.textContent = `Committed ${out.commit} — push failed. Commit again to retry the push.`;
        status.classList.add("err");
        if (commitRow) {
          commitRow.remove();
          commitRow = null;
        }
        go.disabled = false;
      } else {
        removeTreeBanner(); // nothing to commit — the tree cleaned up under us
      }
    } catch (e) {
      status.textContent = "Error: " + e.message;
      status.classList.add("err");
      go.disabled = false;
    }
  }

  // Discard: two-step confirm, then POST the shared endpoint.
  let discardArmed = false;
  function resetDiscardConfirm() {
    discardArmed = false;
    discard.textContent = "Discard";
    discard.classList.remove("tb-danger");
  }
  discard.addEventListener("click", async () => {
    if (!discardArmed) {
      discardArmed = true;
      discard.textContent = "Really discard?";
      discard.classList.add("tb-danger");
      return;
    }
    discard.disabled = true;
    status.className = "tb-status";
    status.textContent = "Discarding…";
    try {
      const res = await fetch("api/review/discard", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ repo: activeRepo() || undefined }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error || "discard failed");
      removeTreeBanner();
    } catch (e) {
      status.textContent = "Error: " + e.message;
      status.classList.add("err");
      discard.disabled = false;
      resetDiscardConfirm();
    }
  });

  // Slim persistent bar pinned just above the composer.
  $("composer").parentNode.insertBefore(banner, $("composer"));
  treeBannerEl = banner;
}

// ---------- voice (WebRTC) ----------
let voice = null;
let voiceUsage = { audioIn: 0, audioOut: 0, textIn: 0, textOut: 0 };
// Citations from the consult_knowledge call for the in-progress spoken turn,
// attached to the assistant bubble when its transcript completes.
let voiceTurnCitations = [];

function resetVoiceUsage() {
  voiceUsage = { audioIn: 0, audioOut: 0, textIn: 0, textOut: 0 };
  $("voiceUsage").textContent = "";
}

function accumulateVoiceUsage(u) {
  const i = u.input_token_details || {};
  const o = u.output_token_details || {};
  voiceUsage.audioIn += i.audio_tokens || 0;
  voiceUsage.textIn += i.text_tokens || 0;
  voiceUsage.audioOut += o.audio_tokens || 0;
  voiceUsage.textOut += o.text_tokens || 0;
  renderVoiceUsage();
}

function renderVoiceUsage() {
  const p = VOICE_PRICE[config?.realtime?.model] || VOICE_PRICE["gpt-realtime-mini"];
  const cost =
    (voiceUsage.audioIn * p.audioIn +
      voiceUsage.audioOut * p.audioOut +
      voiceUsage.textIn * p.textIn +
      voiceUsage.textOut * p.textOut) /
    1_000_000;
  $("voiceUsage").textContent =
    `voice • audio ${kfmt(voiceUsage.audioIn)} in / ${kfmt(voiceUsage.audioOut)} out · ~${fmtUsd(cost)} est`;
  // Fold realtime audio into the session HUD.
  sessionCost.voiceAudioIn = voiceUsage.audioIn;
  sessionCost.voiceAudioOut = voiceUsage.audioOut;
  sessionCost.voiceUsd = cost;
  renderHUD();
}

async function startVoice() {
  resetVoiceUsage();
  setVoiceUI("Connecting…", false, true);
  try {
    // Seed the voice session with the recent text conversation for continuity.
    const tokenRes = await fetch("api/realtime/token", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ history: history.slice(-12) }),
    });
    const token = await tokenRes.json();
    if (!token.value) throw new Error(token.error || "no token");

    const pc = new RTCPeerConnection();
    const audioEl = new Audio();
    audioEl.autoplay = true;
    pc.ontrack = (e) => { audioEl.srcObject = e.streams[0]; };

    // Echo cancellation + noise suppression reduce the model hearing its own
    // voice / background noise and self-interrupting.
    const mic = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    });
    pc.addTrack(mic.getTracks()[0]);

    const dc = pc.createDataChannel("oai-events");
    dc.addEventListener("open", () => setVoiceUI("Listening…", true, true));
    dc.addEventListener("message", (e) => onVoiceEvent(JSON.parse(e.data), dc));

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    const sdpRes = await fetch("https://api.openai.com/v1/realtime/calls", {
      method: "POST",
      body: offer.sdp,
      headers: { Authorization: `Bearer ${token.value}`, "Content-Type": "application/sdp" },
    });
    if (!sdpRes.ok) throw new Error("realtime connect failed: " + sdpRes.status);
    await pc.setRemoteDescription({ type: "answer", sdp: await sdpRes.text() });

    voice = { pc, dc, mic, audioEl, muted: false, assistantSpeaking: false, bargeOverride: false };
    $("voiceBtn").setAttribute("aria-pressed", "true");
    $("voicePanel").classList.remove("hidden");
    $("muteBtn").classList.remove("hidden");
    updateMuteUI(); // initial state: mic on, "Mute mic", "Listening…"
  } catch (e) {
    setVoiceUI("Error: " + e.message, false, false);
    stopVoice();
  }
}

function stopVoice() {
  if (voice) {
    try { voice.dc.close(); } catch {}
    try { voice.pc.close(); } catch {}
    try { voice.mic.getTracks().forEach((t) => t.stop()); } catch {}
    voice = null;
  }
  $("voiceBtn").setAttribute("aria-pressed", "false");
  $("muteBtn").classList.add("hidden");
  setVoiceUI("Voice off", false, false);
}

// The mic auto-mutes while the assistant is speaking, so stray sound, echo, or
// background noise can't accidentally interrupt it. This is made VISIBLE (the
// button reads "Unmute to interrupt" and the status says the mic is muted) so
// it's never a surprise — and the user can click Unmute to override and barge
// in. A manual mute (voice.muted) persists across turns; a barge-in override
// (voice.bargeOverride) lasts only until the assistant's next utterance.
function micShouldBeOn() {
  return !!voice && !voice.muted && (!voice.assistantSpeaking || voice.bargeOverride);
}
function applyMicState() {
  if (!voice) return;
  const on = micShouldBeOn();
  voice.mic.getTracks().forEach((t) => (t.enabled = on));
  updateMuteUI();
}

// Reflect the exact mic state on the button + status line so muting is never a
// surprise to the user.
function updateMuteUI() {
  if (!voice) return;
  const on = micShouldBeOn();
  const autoMuted = voice.assistantSpeaking && !voice.bargeOverride && !voice.muted;
  const mb = $("muteBtn");
  if (mb) {
    mb.classList.toggle("muted", !on);
    mb.setAttribute("aria-pressed", String(!on));
    mb.textContent = voice.muted ? "Unmute" : autoMuted ? "Unmute to interrupt" : "Mute mic";
  }
  let status;
  if (voice.muted) status = "Muted — tap Unmute to speak";
  else if (autoMuted) status = "🔇 Mic muted while the agent speaks — tap Unmute to interrupt";
  else if (voice.assistantSpeaking) status = "Interrupting — go ahead…";
  else status = "Listening…";
  $("voiceStatus").textContent = status;
  $("voicePulse").classList.toggle("live", on || voice.assistantSpeaking);
}

// Track whether the assistant is producing audio and auto-mute the mic while it
// is. Entering a fresh utterance clears any prior barge-in override.
function setAssistantSpeaking(speaking) {
  if (!voice) return;
  if (speaking) {
    if (!voice.assistantSpeaking) { voice.assistantSpeaking = true; voice.bargeOverride = false; }
  } else {
    voice.assistantSpeaking = false;
    voice.bargeOverride = false;
  }
  applyMicState();
}

// The button reflects the effective mic state: if the mic is on, mute it; if
// it's off (manual mute OR the auto-mute mid-answer), turn it on — which doubles
// as "unmute to interrupt" while the assistant is speaking.
function toggleMute() {
  if (!voice) return;
  if (micShouldBeOn()) {
    voice.muted = true;
  } else {
    voice.muted = false;
    voice.bargeOverride = true; // override the auto-mute so you can barge in now
  }
  applyMicState();
}

function setVoiceUI(status, live, panel) {
  $("voiceStatus").textContent = status;
  $("voicePulse").classList.toggle("live", !!live);
  if (panel) $("voicePanel").classList.remove("hidden");
}

async function onVoiceEvent(ev, dc) {
  switch (ev.type) {
    case "response.created":
      $("assistantTranscript").textContent = "";
      break;
    case "input_audio_buffer.speech_started":
      // The user is talking. With auto-mute the mic is only live here when they
      // clicked Unmute to interrupt — so honor it: flush the assistant's
      // still-playing audio (server VAD also cancels the response upstream) so we
      // stop and let them take over.
      if (voice?.assistantSpeaking) {
        try { dc.send(JSON.stringify({ type: "output_audio_buffer.clear" })); } catch {}
        setAssistantSpeaking(false);
      }
      break;
    case "conversation.item.input_audio_transcription.delta":
      $("userTranscript").textContent += ev.delta || "";
      break;
    case "conversation.item.input_audio_transcription.completed": {
      // Commit the finished user turn into the shared thread + history.
      const text = (ev.transcript || $("userTranscript").textContent || "").trim();
      $("userTranscript").textContent = "";
      if (text) {
        addMessage("user").bubble.textContent = text;
        history.push({ role: "user", content: text });
      }
      break;
    }
    case "output_audio_buffer.started":
      setAssistantSpeaking(true); // precise: assistant audio is now playing
      break;
    case "output_audio_buffer.stopped":
    case "output_audio_buffer.cleared":
      setAssistantSpeaking(false); // audio done → reopen the mic
      break;
    case "response.output_audio_transcript.delta":
      $("assistantTranscript").textContent += ev.delta || "";
      setAssistantSpeaking(true); // assistant is talking → auto-mute + status (fallback if buffer events miss)
      break;
    case "response.output_audio_transcript.done": {
      // Commit the finished spoken answer into the shared thread + history,
      // with the citations from this turn's consult_knowledge call.
      const text = (ev.transcript || $("assistantTranscript").textContent || "").trim();
      $("assistantTranscript").textContent = "";
      updateMuteUI(); // status follows the real mic state (audio may still be playing)
      if (text) {
        const a = addMessage("assistant");
        a.bubble.innerHTML = renderMarkdown(text);
        renderCitations(a.cites, voiceTurnCitations);
        a.meta.textContent = "🎙 spoken";
        history.push({ role: "assistant", content: text });
      }
      voiceTurnCitations = [];
      break;
    }
    case "response.done":
      if (ev.response?.usage) accumulateVoiceUsage(ev.response.usage);
      setAssistantSpeaking(false); // turn finished — assistant is no longer talking
      await handleVoiceTools(ev.response, dc);
      break;
    case "error":
      setVoiceUI("Error: " + (ev.error?.message || "unknown"), false, true);
      break;
    default:
      // Helps diagnose transcript/usage wiring if OpenAI tweaks event names.
      if (/transcript|response\.(done|created)|usage/.test(ev.type)) {
        console.debug("[voice event]", ev.type, ev);
      }
  }
}

async function handleVoiceTools(response, dc) {
  const calls = (response?.output || []).filter((o) => o.type === "function_call");
  if (!calls.length) return;
  for (const call of calls) {
    let args = {};
    try { args = JSON.parse(call.arguments || "{}"); } catch {}
    setVoiceUI(`Looking it up (${call.name})…`, true, true);
    let result = { content: "", citations: [] };
    try {
      const r = await fetch("api/tools/call", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: call.name, args }),
      });
      result = await r.json();
    } catch (e) {
      result = { content: "Tool error: " + e.message, citations: [] };
    }
    // Collect citations for this turn (attached when the answer transcript
    // completes) and fold the consult's text cost into the session HUD.
    if (Array.isArray(result.citations)) voiceTurnCitations.push(...result.citations);
    addTextCost(result.usage, result.costUsd);
    dc.send(JSON.stringify({
      type: "conversation.item.create",
      item: { type: "function_call_output", call_id: call.call_id, output: result.content || "" },
    }));
  }
  dc.send(JSON.stringify({ type: "response.create" }));
}

// ---------- instance / workspace ----------
// Workspace mode has many KBs; you're "focused" on one or none (unfocused = still
// on the workspace dir). We keep the topbar showing the active KB at all times.
function isWorkspace() {
  return config?.mode === "workspace";
}
function activeRepo() {
  return isWorkspace() ? config?.workspace?.active || null : config?.instanceName;
}

function applyConfig(cfg) {
  config = cfg;
  $("convBtn").style.display = cfg.persistConversations ? "" : "none";
  // In workspace mode, the KB dropdown is the switcher; hide the generic
  // path-based "Instance ▾" picker (single-mode / power-user only).
  $("instanceBtn").style.display = isWorkspace() ? "none" : "";
  renderKbSelect();
  renderTopbar();
}

// Populate + show the KB dropdown in workspace mode (a direct switcher, not just
// conversational). Selecting a KB focuses it without wiping the conversation.
function renderKbSelect() {
  const sel = $("kbSelect");
  if (!isWorkspace()) {
    sel.classList.add("hidden");
    return;
  }
  const repos = config?.workspace?.repos || [];
  const active = config?.workspace?.active || "";
  sel.innerHTML = "";
  if (!active) {
    const o = el("option", null, "Choose a KB…");
    o.value = "";
    o.disabled = true;
    o.selected = true;
    sel.appendChild(o);
  }
  for (const name of repos) {
    const o = el("option", null, name);
    o.value = name;
    if (name === active) o.selected = true;
    sel.appendChild(o);
  }
  sel.classList.remove("hidden");
}

async function selectKb(name) {
  if (!name) return;
  try {
    const res = await fetch("api/focus", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ repo: name }),
    });
    if (res.ok) {
      applyConfig(await res.json());
      // If the conversation is empty, refresh the welcome to the focused state.
      if (!history.length) showWelcome();
    }
  } catch { /* ignore */ }
}

// Update just the active-KB label — called on load, on an in-band focus_repo
// (SSE "instance" event), and on a manual switch — so the user always sees where
// they are.
function setActiveInstance(name) {
  if (config) {
    config.instanceName = name;
    if (config.workspace) config.workspace.active = name;
  }
  renderKbSelect();
  renderTopbar();
}

function renderTopbar() {
  if (!config) return;
  if (isWorkspace()) {
    const active = config.workspace?.active;
    $("instanceName").textContent = active || "Choose a workspace";
    $("instanceMeta").textContent = active
      ? `${config.provider}/${config.model} · working in ${active}`
      : `${(config.workspace?.repos || []).length} knowledge bases · none selected`;
  } else {
    $("instanceName").textContent = config.instanceName;
    $("instanceMeta").textContent = `${config.provider}/${config.model} · ${config.domains.join(", ")}`;
  }
}

// Focus a workspace KB directly from the UI (the picker chips), matching what the
// agent does in-band. Resets the conversation so context doesn't bleed across KBs.
async function focusWorkspace(name) {
  try {
    const res = await fetch("api/focus", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ repo: name }),
    });
    if (res.ok) {
      applyConfig(await res.json());
      resetConversation();
    }
  } catch { /* ignore */ }
}

function showWelcome() {
  const m = $("messages");
  m.innerHTML = "";
  const w = el("div", "welcome");

  // Workspace mode, nothing focused yet → a picker instead of a generic welcome.
  if (isWorkspace() && !activeRepo()) {
    w.appendChild(el("h1", null, "Choose a knowledge base"));
    w.appendChild(el("p", null, "You have several. Pick one to work in — or just tell the agent which."));
    const picks = el("div", "suggestions");
    for (const name of config?.workspace?.repos || []) {
      const b = el("div", "suggestion", `📚 ${name}`);
      b.addEventListener("click", () => focusWorkspace(name));
      picks.appendChild(b);
    }
    w.appendChild(picks);
    m.appendChild(w);
    return;
  }

  const label = activeRepo() || "your knowledge base";
  w.appendChild(el("h1", null, isWorkspace() ? `Working in “${label}”` : "Chat with your knowledge base"));
  w.appendChild(
    el(
      "p",
      null,
      config
        ? `Ask anything grounded in “${label}”. Every answer cites the files and sources it used.`
        : "Loading…",
    ),
  );
  const sugg = el("div", "suggestions");
  for (const s of config?.suggestedPrompts || []) {
    const b = el("div", "suggestion", s);
    b.addEventListener("click", () => {
      $("input").value = s;
      submit();
    });
    sugg.appendChild(b);
  }
  w.appendChild(sugg);
  m.appendChild(w);
}

function resetConversation() {
  if (voice) stopVoice();
  // A fresh conversation (New chat, KB/instance switch) is never a review turn.
  exitReviewMode();
  history.length = 0;
  Object.assign(sessionCost, {
    textIn: 0, textOut: 0, textUsd: 0,
    voiceAudioIn: 0, voiceAudioOut: 0, voiceUsd: 0,
  });
  renderHUD();
  showWelcome();
}

function togglePicker(force) {
  const panel = $("instancePicker");
  const show = force != null ? force : panel.classList.contains("hidden");
  panel.classList.toggle("hidden", !show);
  if (show) loadInstances();
}

async function loadInstances() {
  const list = $("instanceList");
  list.textContent = "Loading…";
  $("instanceError").textContent = "";
  try {
    const data = await (await fetch("api/instances")).json();
    list.innerHTML = "";
    if (!data.instances.length) {
      list.textContent = "No AgentsFS instances found under the search dir.";
    }
    for (const inst of data.instances) {
      const isCurrent = inst.path === data.current;
      const b = el("button", "picker-item" + (isCurrent ? " active" : ""));
      b.innerHTML = `${escapeHtml(inst.name)}${isCurrent ? " · current" : ""}<span class="p">${escapeHtml(inst.path)}</span>`;
      b.addEventListener("click", () => doSwitch(inst.path));
      list.appendChild(b);
    }
  } catch (e) {
    list.textContent = "Failed to load instances: " + e.message;
  }
}

async function doSwitch(path) {
  $("instanceError").textContent = "";
  try {
    const res = await fetch("api/instance", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "switch failed");
    applyConfig(data);
    resetConversation();
    togglePicker(false);
  } catch (e) {
    $("instanceError").textContent = e.message;
  }
}

// ---------- conversations (persistent history) ----------
function toggleConvPicker(force) {
  const panel = $("convPicker");
  const show = force != null ? force : panel.classList.contains("hidden");
  panel.classList.toggle("hidden", !show);
  if (show) loadConversationsList();
}

async function loadConversationsList() {
  const list = $("convList");
  list.textContent = "Loading…";
  try {
    const data = await (await fetch("api/conversations")).json();
    list.innerHTML = "";
    if (!data.conversations || !data.conversations.length) {
      list.textContent = "No saved conversations yet.";
      return;
    }
    for (const c of data.conversations) {
      const b = el("button", "picker-item" + (c.id === currentConversationId ? " active" : ""));
      const when = new Date(c.updatedAt).toLocaleString();
      b.textContent = String(c.title || "Untitled chat");
      const count = Number.isFinite(Number(c.messageCount))
        ? Math.max(0, Math.trunc(Number(c.messageCount)))
        : 0;
      const meta = el(
        "span",
        "p",
        `${when} · ${count} msgs${c.activeRepo ? " · " + String(c.activeRepo) : ""}`,
      );
      b.appendChild(meta);
      b.addEventListener("click", () => loadConversation(c.id));
      const del = el("span", "conv-del", "✕");
      del.title = "Delete";
      del.addEventListener("click", (e) => { e.stopPropagation(); deleteConversation(c.id); });
      b.appendChild(del);
      list.appendChild(b);
    }
  } catch (e) {
    list.textContent = "Failed to load conversations.";
  }
}

async function loadConversation(id) {
  try {
    const res = await fetch("api/conversations/" + id);
    if (!res.ok) return;
    const c = await res.json();
    if (voice) stopVoice();
    // Review mode belongs to the conversation it was handed to — never let it
    // leak into another conversation's typed messages.
    exitReviewMode();
    currentConversationId = id;
    history.length = 0;
    $("messages").innerHTML = "";
    for (const m of c.messages) {
      const node = addMessage(m.role);
      if (m.role === "assistant") node.bubble.innerHTML = renderMarkdown(m.content);
      else node.bubble.textContent = m.content;
      history.push({ role: m.role, content: m.content });
    }
    if (c.activeRepo) setActiveInstance(c.activeRepo);
    toggleConvPicker(false);
    scrollDown();
  } catch { /* ignore */ }
}

async function deleteConversation(id) {
  try { await fetch("api/conversations/" + id, { method: "DELETE" }); } catch {}
  if (id === currentConversationId) newConversation();
  loadConversationsList();
}

// New conversation: a fresh persisted chat (or just a cleared one when history
// isn't enabled).
async function newConversation() {
  currentConversationId = null; // a new one is created lazily on first message
  resetConversation();
}

// ---------- bootstrap ----------
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function loadInitialConfig() {
  let attempt = 0;
  for (;;) {
    try {
      const response = await fetch("api/config", { cache: "no-store" });
      if (!response.ok) throw new Error(`config returned ${response.status}`);
      return await response.json();
    } catch {
      const offline = typeof navigator !== "undefined" && navigator.onLine === false;
      $("instanceMeta").textContent = offline
        ? "offline · waiting for connection…"
        : "waking agent · reconnecting…";
      await wait(Math.min(750 * 2 ** attempt, 5000));
      attempt += 1;
    }
  }
}

async function init() {
  let cfg = await loadInitialConfig();
  // The repo button links here as /agent/?repo=<slug>; pre-focus that repo so
  // the agent lands scoped to it instead of asking which one.
  const repo = new URLSearchParams(location.search).get("repo");
  if (repo) {
    try {
      const r = await fetch("api/focus", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ repo }),
      });
      if (r.ok) cfg = await r.json();
    } catch { /* fall back to the default focus + ask */ }
  }
  applyConfig(cfg);
  showWelcome();
  renderHUD();
  // Review handoffs, both transports (after config load + ?repo= pre-focus):
  // desktop — index.html buffers postMessages + acks; drain any that arrived
  // before this module loaded, and handle later ones as they come in.
  window.__afsOnReviewHandoff = drainReviewQueue;
  drainReviewQueue();
  // phone — consume a handoff staged in localStorage by the hub note page.
  consumePendingHandoff();
}

function submit() {
  const v = $("input").value;
  if (!v.trim()) return;
  $("input").value = "";
  $("input").style.height = "auto";
  // In review mode, typed follow-up feedback stays a restricted review turn.
  send(v, { review: reviewMode.active });
}

$("composer").addEventListener("submit", (e) => { e.preventDefault(); submit(); });
$("input").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); }
});
$("input").addEventListener("input", function () {
  this.style.height = "auto";
  this.style.height = Math.min(this.scrollHeight, 180) + "px";
});
$("voiceBtn").addEventListener("click", () => (voice ? stopVoice() : startVoice()));
$("muteBtn").addEventListener("click", toggleMute);
$("instanceBtn").addEventListener("click", () => togglePicker());
$("convBtn").addEventListener("click", () => toggleConvPicker());
$("kbSelect").addEventListener("change", (e) => selectKb(e.target.value));
$("instanceUse").addEventListener("click", () => {
  const p = $("instancePath").value.trim();
  if (p) doSwitch(p);
});
$("instancePath").addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    const p = e.target.value.trim();
    if (p) doSwitch(p);
  }
});
$("newChatBtn").addEventListener("click", () => newConversation());
$("drawerClose").addEventListener("click", closeDrawer);
$("scrim").addEventListener("click", closeDrawer);

init();
