// agentsfs-chat web client: streaming chat + WebRTC voice over the same tools.
import { escapeHtml, renderMarkdown, splitSSE } from "./lib.js";

const $ = (id) => document.getElementById(id);
const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
};

const history = [];
let config = null;

// Client-side price table ($/1M tokens) for the realtime voice model, so we can
// show live spend. Audio dominates. gpt-realtime-mini rates (mini audio from a
// secondary source — treat the $ as an estimate). Edit to match your plan.
const VOICE_PRICE = {
  "gpt-realtime-mini": { textIn: 0.6, textOut: 2.4, audioIn: 10, audioOut: 20 },
  "gpt-realtime": { textIn: 4, textOut: 24, audioIn: 32, audioOut: 64 },
};
const fmtUsd = (u) => `$${u < 0.01 ? u.toFixed(4) : u.toFixed(3)}`;
const kfmt = (n) => (n >= 1000 ? (n / 1000).toFixed(1) + "k" : String(n));

// Running session cost across BOTH modes. "text" = gpt-5.1 reasoning (chat +
// voice consult); "voice" = realtime audio.
const sessionCost = {
  textIn: 0,
  textOut: 0,
  textUsd: 0,
  voiceAudioIn: 0,
  voiceAudioOut: 0,
  voiceUsd: 0,
};

function addTextCost(usage, costUsd) {
  if (usage) {
    sessionCost.textIn += usage.inputTokens || 0;
    sessionCost.textOut += usage.outputTokens || 0;
  }
  if (costUsd) sessionCost.textUsd += costUsd;
  renderHUD();
}

function renderHUD() {
  const total = sessionCost.textUsd + sessionCost.voiceUsd;
  let s = `session ~${fmtUsd(total)} · text ${kfmt(sessionCost.textIn)} in / ${kfmt(sessionCost.textOut)} out`;
  if (sessionCost.voiceAudioIn || sessionCost.voiceAudioOut) {
    s += ` · voice ${kfmt(sessionCost.voiceAudioIn)} / ${kfmt(sessionCost.voiceAudioOut)} audio`;
  }
  $("hud").textContent = s;
}

// ---------- citations ----------
function chip(c) {
  const isUrl = c.type === "url";
  const label = c.label || c.path || c.url;
  const node = el("button", `chip ${isUrl ? "url" : "file"}`, label);
  node.title = c.url || c.path || "";
  node.addEventListener("click", () => {
    if (isUrl) window.open(c.url, "_blank", "noopener");
    else openFile(c.path);
  });
  return node;
}
function renderCitations(container, citations) {
  container.innerHTML = "";
  if (!citations || !citations.length) return;
  for (const c of citations) container.appendChild(chip(c));
}

// ---------- drawer (file viewer) ----------
async function openFile(path) {
  $("drawerTitle").textContent = path;
  $("drawerBody").textContent = "Loading…";
  $("drawer").classList.remove("hidden");
  $("scrim").classList.remove("hidden");
  try {
    const r = await fetch("api/tools/call", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: "read_file", args: { path } }),
    });
    const data = await r.json();
    $("drawerBody").textContent = data.content || "(empty)";
  } catch (e) {
    $("drawerBody").textContent = "Failed to load file: " + e.message;
  }
}
function closeDrawer() {
  $("drawer").classList.add("hidden");
  $("scrim").classList.add("hidden");
}

// ---------- chat ----------
function addMessage(role) {
  // The welcome/suggestions are re-rendered dynamically with only a class (no
  // id), so remove by class — otherwise they linger above the conversation.
  document.querySelector(".welcome")?.remove();
  const wrap = el("div", `msg ${role}`);
  const trace = el("div", "tool-trace");
  trace.style.display = "none";
  const bubble = el("div", "bubble");
  const cites = el("div", "citations");
  const meta = el("div", "meta");
  if (role === "assistant") wrap.appendChild(trace);
  wrap.appendChild(bubble);
  if (role === "assistant") {
    wrap.appendChild(cites);
    wrap.appendChild(meta);
  }
  $("messages").appendChild(wrap);
  scrollDown();
  return { wrap, trace, bubble, cites, meta };
}
function scrollDown() {
  const m = $("messages");
  m.scrollTop = m.scrollHeight;
}

async function send(message) {
  if (!message.trim()) return;
  const u = addMessage("user");
  u.bubble.textContent = message;

  const a = addMessage("assistant");
  a.bubble.classList.add("cursor");
  let text = "";
  const tools = [];

  setComposerEnabled(false);
  try {
    await streamSSE("api/chat", { message, history }, (event, data) => {
      if (event === "delta") {
        text += data.text;
        a.bubble.innerHTML = renderMarkdown(text);
        a.bubble.classList.add("cursor");
        scrollDown();
      } else if (event === "reset") {
        // A pre-tool round emitted interim prose; discard it.
        text = "";
        a.bubble.innerHTML = "";
        a.bubble.classList.add("cursor");
      } else if (event === "tool") {
        tools.push(`${data.name}(${shortArgs(data.args)})`);
        a.trace.style.display = "";
        a.trace.innerHTML = tools.map((t) => `<span class="t">↳ ${escapeHtml(t)}</span>`).join("  ");
        scrollDown();
      } else if (event === "done") {
        if (data.text && !text) text = data.text;
        a.bubble.innerHTML = renderMarkdown(text);
        a.bubble.classList.remove("cursor");
        renderCitations(a.cites, data.citations);
        if (data.usage) {
          const c = data.costUsd != null ? ` · ~${fmtUsd(data.costUsd)} est` : "";
          a.meta.textContent = `${data.model} · ${data.usage.inputTokens}+${data.usage.outputTokens} tok${c}`;
        }
        addTextCost(data.usage, data.costUsd);
        history.push({ role: "user", content: message });
        history.push({ role: "assistant", content: text });
        scrollDown();
      } else if (event === "error") {
        a.bubble.classList.remove("cursor");
        a.bubble.innerHTML = `<span class="error">Error: ${escapeHtml(data.message)}</span>`;
      }
    });
  } catch (e) {
    a.bubble.classList.remove("cursor");
    a.bubble.innerHTML = `<span class="error">Error: ${escapeHtml(e.message)}</span>`;
  } finally {
    setComposerEnabled(true);
  }
}

function shortArgs(args) {
  try {
    const s = JSON.stringify(args);
    return s.length > 60 ? s.slice(0, 57) + "…" : s;
  } catch {
    return "";
  }
}

async function streamSSE(url, body, onEvent) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const { frames, rest } = splitSSE(buf);
    buf = rest;
    for (const f of frames) {
      try { onEvent(f.event, JSON.parse(f.data)); } catch { /* ignore */ }
    }
  }
}

function setComposerEnabled(on) {
  $("input").disabled = !on;
  $("sendBtn").disabled = !on;
  if (on) $("input").focus();
}

// ---------- voice (WebRTC) ----------
let voice = null;
let voiceUsage = { audioIn: 0, audioOut: 0, textIn: 0, textOut: 0 };
// Citations from the consult_knowledge call for the in-progress spoken turn,
// attached to the assistant bubble when its transcript completes.
let voiceTurnCitations = [];

function resetVoiceUsage() {
  voiceUsage = { audioIn: 0, audioOut: 0, textIn: 0, textOut: 0 };
  $("voiceUsage").textContent = "";
}

function accumulateVoiceUsage(u) {
  const i = u.input_token_details || {};
  const o = u.output_token_details || {};
  voiceUsage.audioIn += i.audio_tokens || 0;
  voiceUsage.textIn += i.text_tokens || 0;
  voiceUsage.audioOut += o.audio_tokens || 0;
  voiceUsage.textOut += o.text_tokens || 0;
  renderVoiceUsage();
}

function renderVoiceUsage() {
  const p = VOICE_PRICE[config?.realtime?.model] || VOICE_PRICE["gpt-realtime-mini"];
  const cost =
    (voiceUsage.audioIn * p.audioIn +
      voiceUsage.audioOut * p.audioOut +
      voiceUsage.textIn * p.textIn +
      voiceUsage.textOut * p.textOut) /
    1_000_000;
  $("voiceUsage").textContent =
    `voice • audio ${kfmt(voiceUsage.audioIn)} in / ${kfmt(voiceUsage.audioOut)} out · ~${fmtUsd(cost)} est`;
  // Fold realtime audio into the session HUD.
  sessionCost.voiceAudioIn = voiceUsage.audioIn;
  sessionCost.voiceAudioOut = voiceUsage.audioOut;
  sessionCost.voiceUsd = cost;
  renderHUD();
}

async function startVoice() {
  resetVoiceUsage();
  setVoiceUI("Connecting…", false, true);
  try {
    // Seed the voice session with the recent text conversation for continuity.
    const tokenRes = await fetch("api/realtime/token", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ history: history.slice(-12) }),
    });
    const token = await tokenRes.json();
    if (!token.value) throw new Error(token.error || "no token");

    const pc = new RTCPeerConnection();
    const audioEl = new Audio();
    audioEl.autoplay = true;
    pc.ontrack = (e) => { audioEl.srcObject = e.streams[0]; };

    // Echo cancellation + noise suppression reduce the model hearing its own
    // voice / background noise and self-interrupting.
    const mic = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    });
    pc.addTrack(mic.getTracks()[0]);

    const dc = pc.createDataChannel("oai-events");
    dc.addEventListener("open", () => setVoiceUI("Listening…", true, true));
    dc.addEventListener("message", (e) => onVoiceEvent(JSON.parse(e.data), dc));

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    const sdpRes = await fetch("https://api.openai.com/v1/realtime/calls", {
      method: "POST",
      body: offer.sdp,
      headers: { Authorization: `Bearer ${token.value}`, "Content-Type": "application/sdp" },
    });
    if (!sdpRes.ok) throw new Error("realtime connect failed: " + sdpRes.status);
    await pc.setRemoteDescription({ type: "answer", sdp: await sdpRes.text() });

    voice = { pc, dc, mic, audioEl, muted: false };
    $("voiceBtn").setAttribute("aria-pressed", "true");
    $("voicePanel").classList.remove("hidden");
    const mb = $("muteBtn");
    mb.classList.remove("hidden", "muted");
    mb.setAttribute("aria-pressed", "false");
    mb.textContent = "Mute mic";
  } catch (e) {
    setVoiceUI("Error: " + e.message, false, false);
    stopVoice();
  }
}

function stopVoice() {
  if (voice) {
    try { voice.dc.close(); } catch {}
    try { voice.pc.close(); } catch {}
    try { voice.mic.getTracks().forEach((t) => t.stop()); } catch {}
    voice = null;
  }
  $("voiceBtn").setAttribute("aria-pressed", "false");
  $("muteBtn").classList.add("hidden");
  setVoiceUI("Voice off", false, false);
}

// Mute the mic without dropping the call — muted tracks send silence, so the
// model stops hearing background noise / its own echo and won't self-interrupt.
function toggleMute() {
  if (!voice) return;
  voice.muted = !voice.muted;
  voice.mic.getTracks().forEach((t) => (t.enabled = !voice.muted));
  const mb = $("muteBtn");
  mb.textContent = voice.muted ? "Unmute" : "Mute mic";
  mb.setAttribute("aria-pressed", String(voice.muted));
  mb.classList.toggle("muted", voice.muted);
  setVoiceUI(voice.muted ? "Muted — tap Unmute to speak" : "Listening…", !voice.muted, true);
}

function setVoiceUI(status, live, panel) {
  $("voiceStatus").textContent = status;
  $("voicePulse").classList.toggle("live", !!live);
  if (panel) $("voicePanel").classList.remove("hidden");
}

async function onVoiceEvent(ev, dc) {
  switch (ev.type) {
    case "response.created":
      $("assistantTranscript").textContent = "";
      break;
    case "conversation.item.input_audio_transcription.delta":
      $("userTranscript").textContent += ev.delta || "";
      break;
    case "conversation.item.input_audio_transcription.completed": {
      // Commit the finished user turn into the shared thread + history.
      const text = (ev.transcript || $("userTranscript").textContent || "").trim();
      $("userTranscript").textContent = "";
      if (text) {
        addMessage("user").bubble.textContent = text;
        history.push({ role: "user", content: text });
      }
      break;
    }
    case "response.output_audio_transcript.delta":
      $("assistantTranscript").textContent += ev.delta || "";
      setVoiceUI("Speaking…", true, true);
      break;
    case "response.output_audio_transcript.done": {
      // Commit the finished spoken answer into the shared thread + history,
      // with the citations from this turn's consult_knowledge call.
      const text = (ev.transcript || $("assistantTranscript").textContent || "").trim();
      $("assistantTranscript").textContent = "";
      setVoiceUI("Listening…", true, true);
      if (text) {
        const a = addMessage("assistant");
        a.bubble.innerHTML = renderMarkdown(text);
        renderCitations(a.cites, voiceTurnCitations);
        a.meta.textContent = "🎙 spoken";
        history.push({ role: "assistant", content: text });
      }
      voiceTurnCitations = [];
      break;
    }
    case "response.done":
      if (ev.response?.usage) accumulateVoiceUsage(ev.response.usage);
      await handleVoiceTools(ev.response, dc);
      break;
    case "error":
      setVoiceUI("Error: " + (ev.error?.message || "unknown"), false, true);
      break;
    default:
      // Helps diagnose transcript/usage wiring if OpenAI tweaks event names.
      if (/transcript|response\.(done|created)|usage/.test(ev.type)) {
        console.debug("[voice event]", ev.type, ev);
      }
  }
}

async function handleVoiceTools(response, dc) {
  const calls = (response?.output || []).filter((o) => o.type === "function_call");
  if (!calls.length) return;
  for (const call of calls) {
    let args = {};
    try { args = JSON.parse(call.arguments || "{}"); } catch {}
    setVoiceUI(`Looking it up (${call.name})…`, true, true);
    let result = { content: "", citations: [] };
    try {
      const r = await fetch("api/tools/call", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: call.name, args }),
      });
      result = await r.json();
    } catch (e) {
      result = { content: "Tool error: " + e.message, citations: [] };
    }
    // Collect citations for this turn (attached when the answer transcript
    // completes) and fold the consult's text cost into the session HUD.
    if (Array.isArray(result.citations)) voiceTurnCitations.push(...result.citations);
    addTextCost(result.usage, result.costUsd);
    dc.send(JSON.stringify({
      type: "conversation.item.create",
      item: { type: "function_call_output", call_id: call.call_id, output: result.content || "" },
    }));
  }
  dc.send(JSON.stringify({ type: "response.create" }));
}

// ---------- instance picker ----------
function applyConfig(cfg) {
  config = cfg;
  $("instanceName").textContent = cfg.instanceName;
  $("instanceMeta").textContent = `${cfg.provider}/${cfg.model} · ${cfg.domains.join(", ")}`;
}

function showWelcome() {
  const m = $("messages");
  m.innerHTML = "";
  const w = el("div", "welcome");
  w.appendChild(el("h1", null, "Chat with your knowledge base"));
  w.appendChild(
    el(
      "p",
      null,
      config
        ? `Ask anything grounded in “${config.instanceName}”. Every answer cites the files and sources it used.`
        : "Loading…",
    ),
  );
  const sugg = el("div", "suggestions");
  for (const s of config?.suggestedPrompts || []) {
    const b = el("div", "suggestion", s);
    b.addEventListener("click", () => {
      $("input").value = s;
      submit();
    });
    sugg.appendChild(b);
  }
  w.appendChild(sugg);
  m.appendChild(w);
}

function resetConversation() {
  if (voice) stopVoice();
  history.length = 0;
  Object.assign(sessionCost, {
    textIn: 0, textOut: 0, textUsd: 0,
    voiceAudioIn: 0, voiceAudioOut: 0, voiceUsd: 0,
  });
  renderHUD();
  showWelcome();
}

function togglePicker(force) {
  const panel = $("instancePicker");
  const show = force != null ? force : panel.classList.contains("hidden");
  panel.classList.toggle("hidden", !show);
  if (show) loadInstances();
}

async function loadInstances() {
  const list = $("instanceList");
  list.textContent = "Loading…";
  $("instanceError").textContent = "";
  try {
    const data = await (await fetch("api/instances")).json();
    list.innerHTML = "";
    if (!data.instances.length) {
      list.textContent = "No AgentsFS instances found under the search dir.";
    }
    for (const inst of data.instances) {
      const isCurrent = inst.path === data.current;
      const b = el("button", "picker-item" + (isCurrent ? " active" : ""));
      b.innerHTML = `${escapeHtml(inst.name)}${isCurrent ? " · current" : ""}<span class="p">${escapeHtml(inst.path)}</span>`;
      b.addEventListener("click", () => doSwitch(inst.path));
      list.appendChild(b);
    }
  } catch (e) {
    list.textContent = "Failed to load instances: " + e.message;
  }
}

async function doSwitch(path) {
  $("instanceError").textContent = "";
  try {
    const res = await fetch("api/instance", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "switch failed");
    applyConfig(data);
    resetConversation();
    togglePicker(false);
  } catch (e) {
    $("instanceError").textContent = e.message;
  }
}

// ---------- bootstrap ----------
async function init() {
  try {
    let cfg = await (await fetch("api/config")).json();
    // The repo button links here as /agent/?repo=<slug>; pre-focus that repo so
    // the agent lands scoped to it instead of asking which one.
    const repo = new URLSearchParams(location.search).get("repo");
    if (repo) {
      try {
        const r = await fetch("api/focus", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ repo }),
        });
        if (r.ok) cfg = await r.json();
      } catch { /* fall back to the default focus + ask */ }
    }
    applyConfig(cfg);
  } catch {
    $("instanceMeta").textContent = "(failed to load config)";
  }
  showWelcome();
  renderHUD();
}

function submit() {
  const v = $("input").value;
  if (!v.trim()) return;
  $("input").value = "";
  $("input").style.height = "auto";
  send(v);
}

$("composer").addEventListener("submit", (e) => { e.preventDefault(); submit(); });
$("input").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); }
});
$("input").addEventListener("input", function () {
  this.style.height = "auto";
  this.style.height = Math.min(this.scrollHeight, 180) + "px";
});
$("voiceBtn").addEventListener("click", () => (voice ? stopVoice() : startVoice()));
$("muteBtn").addEventListener("click", toggleMute);
$("instanceBtn").addEventListener("click", () => togglePicker());
$("instanceUse").addEventListener("click", () => {
  const p = $("instancePath").value.trim();
  if (p) doSwitch(p);
});
$("instancePath").addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    const p = e.target.value.trim();
    if (p) doSwitch(p);
  }
});
$("newChatBtn").addEventListener("click", () => {
  history.length = 0;
  $("messages").innerHTML = "";
  location.reload();
});
$("drawerClose").addEventListener("click", closeDrawer);
$("scrim").addEventListener("click", closeDrawer);

init();
