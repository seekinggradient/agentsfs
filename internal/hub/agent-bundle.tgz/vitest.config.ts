import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["test/**/*.test.ts"],
    // Live API tests (real OpenAI calls) are opt-in via RUN_LIVE=1 and are
    // skipped by default so the suite is deterministic and offline-safe.
    testTimeout: 30_000,
    hookTimeout: 30_000,
    environment: "node",
  },
});
