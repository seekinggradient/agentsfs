# The agent in a Sprite

> **Superseded / legacy.** The one-sprite-**per-repo** model this script
> provisions is no longer the supported path. The hub now provisions **one
> sprite per user** automatically (`afs-user-<user>`), which clones *all* of your
> hub repos and is reached in-hub at **hub.agentsfs.ai/agent/** (or by clicking
> "Talk to an agent" on any repo page) — you never touch sprites.dev or run this
> script. The 3 legacy per-repo sprites have been retired. See
> [the hub's agent docs](../../agentsfs/internal/hub/) for the current
> architecture.
>
> `scripts/agent-sprite.sh` is kept as a **low-level / dev tool** for manually
> driving a single-repo sprite. Everything below describes that legacy path.

Run the write-capable agentsfs-chat agent as a hosted service — one per hub
repo — that you talk to over a stable URL, and that reads, edits, **commits, and
pushes** the knowledge base back to the hub. The runtime is a
[Fly Sprite](https://sprites.dev): a persistent, hardware-isolated microVM that
auto-sleeps when idle and wakes on the next request.

```
   browser ──HTTPS──▶ https://afs-<repo>-<id>.sprites.app  (sprites.dev org login)
                          │  proxied to :8080
                    ┌─────▼──────────────── Fly Sprite (per repo) ───────────┐
                    │  service "agent"  (boot/crash/cold-wake persistent)     │
                    │    npm start  →  agentsfs-chat, HOST=0.0.0.0 PORT=8080   │
                    │    AGENTSFS_ALLOW_WRITES=1                               │
                    │  /home/sprite/wiki   ← git clone of the hub repo         │
                    │    edit → git commit → git push ─────────┐              │
                    └──────────────────────────────────────────┼──────────────┘
                                                                ▼
                                              hub.agentsfs.ai/<user>/<repo>.git
```

Durable truth stays the git repo on the hub. The sprite is a live working copy;
every change the agent makes is an attributed git commit pushed back.

## Prerequisites

- A Sprites token in `~/.afs-hub/sprites.env` as `SPRITES_TOKEN=...` (create one
  at <https://sprites.dev/account>).
- `OPENAI_API_KEY` (and optional `CHAT_MODEL`) in this repo's `.env`.
- Signed in to the hub: `afs hub login` (writes `<config>/agentsfs/hub.json`).
- A repo already on the hub (`afs hub push <repo>`), Go + `git` locally (to build
  the `afs` binary that ships into the sprite).

## Lifecycle

```sh
scripts/agent-sprite.sh create  <repo> [hub-user]  # provision (or refresh) the agent
scripts/agent-sprite.sh url      <repo>            # print its URL
scripts/agent-sprite.sh status   <repo>            # sprite + service status
scripts/agent-sprite.sh logs     <repo> [n]        # tail the agent service log
scripts/agent-sprite.sh restart  <repo>            # restart the service
scripts/agent-sprite.sh stop     <repo>            # stop the service
scripts/agent-sprite.sh destroy  <repo>            # delete the sprite entirely
scripts/agent-sprite.sh list                       # list all agent sprites
```

`create` is idempotent: it reuses the repo's sprite, re-uploads the app and the
`afs` binary (sha-verified), re-clones the wiki to the latest hub state, and
(re)starts the `agent` service. First visit to the URL redirects through
sprites.dev to sign in with your org — so only you can reach the agent, even
though it can write.

## Notes

- **Secrets** live only in the service's env inside the sprite and in the repo's
  git config (a scoped push credential) — never printed by these commands, never
  committed. Treat the Sprites and OpenAI tokens as sensitive. Note this legacy
  per-repo script still injects a real `OPENAI_API_KEY` into the sprite's
  service env; the supported per-user path does **not** — model calls proxy
  through the hub (`/v1/agent-llm`) so no OpenAI key ever lands on the box.
- **Cost**: a Sprite bills per CPU/GB-hour only while awake and auto-sleeps when
  idle, so an occasionally-used agent costs cents.
- **Egress**: the sprite's default policy already reaches the hub, OpenAI, and
  GitHub; tighten it with the Sprites policy API if you want an explicit allowlist.
