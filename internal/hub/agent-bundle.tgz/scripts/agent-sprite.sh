#!/usr/bin/env bash
#
# agent-sprite.sh — run the write-capable agentsfs-chat agent in a Fly Sprite,
# one per hub repo, as a persistent (boot/crash/cold-wake) service you can talk
# to over a stable URL. This is the lifecycle manager: create, inspect, and
# tear down per-repo agents.
#
#   agent-sprite.sh create  <repo> [hub-user]   provision (or refresh) the agent
#   agent-sprite.sh url      <repo>              print the agent's URL
#   agent-sprite.sh status   <repo>             sprite + service status
#   agent-sprite.sh logs     <repo> [n]         tail the agent service log
#   agent-sprite.sh restart  <repo>             restart the agent service
#   agent-sprite.sh stop     <repo>             stop the agent service
#   agent-sprite.sh destroy  <repo>             delete the sprite entirely
#   agent-sprite.sh list                        list all agent sprites
#
# Secrets are read from standard local files, never embedded:
#   ~/.afs-hub/sprites.env              SPRITES_TOKEN=...
#   <agentsfs-chat>/.env                OPENAI_API_KEY=..., CHAT_MODEL=...
#   <config>/agentsfs/hub.json          hub url / user / token (from `afs hub login`)
set -euo pipefail

CHAT_SRC="${AGENTSFS_CHAT_SRC:-$(cd "$(dirname "$0")/.." && pwd)}"
AFS_SRC="${AGENTSFS_SRC:-$HOME/Development/agentsfs}"
API=https://api.sprites.dev/v1

sprites_token() { sed -E 's/^SPRITES_TOKEN=//' ~/.afs-hub/sprites.env; }
AUTH="Authorization: Bearer $(sprites_token)"

sprite_name() { printf 'afs-%s' "$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | tr -c 'a-z0-9-' '-' | sed -E 's/-+/-/g; s/^-|-$//g')"; }

exec_sh() { # NAME on $1, timeout on $2; sh script on stdin; echoes stdout
  curl -sS -X POST "$API/sprites/$1/exec?cmd=sh&stdin=true" -H "$AUTH" --data-binary @- --max-time "${2:-300}"
}
sprite_url() { curl -sS "$API/sprites/$1" -H "$AUTH" | python3 -c 'import json,sys;print(json.load(sys.stdin).get("url",""))'; }
say() { printf '▸ %s\n' "$*" >&2; }

cmd_create() {
  local SLUG="${1:?usage: create <repo> [hub-user]}" HUB_USER_ARG="${2:-}"
  local NAME; NAME="$(sprite_name "$SLUG")"
  local OPENAI_API_KEY CHAT_MODEL HUB_JSON HUB_URL HUB_USER HUB_TOKEN
  OPENAI_API_KEY="$(grep -E '^OPENAI_API_KEY=' "$CHAT_SRC/.env" | head -1 | sed -E 's/^OPENAI_API_KEY=//')"
  CHAT_MODEL="$(grep -E '^CHAT_MODEL=' "$CHAT_SRC/.env" | head -1 | sed -E 's/^CHAT_MODEL=//' || true)"; CHAT_MODEL="${CHAT_MODEL:-gpt-5.1}"
  HUB_JSON="$HOME/Library/Application Support/agentsfs/hub.json"; [ -f "$HUB_JSON" ] || HUB_JSON="$HOME/.config/agentsfs/hub.json"
  jget() { python3 -c 'import json,sys;print(json.load(open(sys.argv[1])).get(sys.argv[2],""))' "$HUB_JSON" "$1"; }
  HUB_URL="$(jget url)"; HUB_URL="${HUB_URL%/}"
  HUB_USER="${HUB_USER_ARG:-$(jget user)}"; HUB_TOKEN="$(jget token)"

  local WORK; WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' RETURN

  say "building afs (linux/amd64)…"
  ( cd "$AFS_SRC" && GOOS=linux GOARCH=amd64 go build -ldflags='-s -w' -o "$WORK/afs" ./cmd/afs )

  say "creating sprite $NAME…"
  local URL RESP
  RESP="$(curl -sS -X POST "$API/sprites" -H "$AUTH" -H 'Content-Type: application/json' -d "{\"name\":\"$NAME\"}" || true)"
  URL="$(printf '%s' "$RESP" | python3 -c 'import json,sys
try: print(json.load(sys.stdin).get("url",""))
except Exception: print("")')"
  [ -n "$URL" ] || URL="$(sprite_url "$NAME")"
  [ -n "$URL" ] || { echo "could not create sprite: $RESP" >&2; return 1; }
  say "url: $URL"

  say "uploading afs binary…"
  local LOCAL_SHA; LOCAL_SHA="$(shasum -a 256 "$WORK/afs" | cut -d' ' -f1)"
  gzip -9 -c "$WORK/afs" | base64 > "$WORK/afs.gz.b64"; split -b 700000 "$WORK/afs.gz.b64" "$WORK/chunk."
  printf 'mkdir -p /home/sprite/.local/bin; : > /tmp/afs.gz.b64\n' | exec_sh "$NAME" >/dev/null
  local c
  for c in "$WORK"/chunk.*; do
    { echo "cat >> /tmp/afs.gz.b64 <<'CHUNKEOF'"; cat "$c"; echo; echo "CHUNKEOF"; } | exec_sh "$NAME" >/dev/null
  done
  printf '%s' 'base64 -d /tmp/afs.gz.b64 | gunzip > /home/sprite/.local/bin/afs && chmod +x /home/sprite/.local/bin/afs && rm -f /tmp/afs.gz.b64; sha256sum /home/sprite/.local/bin/afs | cut -d" " -f1' | exec_sh "$NAME" > "$WORK/sha.txt" 2>/dev/null
  grep -q "$LOCAL_SHA" "$WORK/sha.txt" || { echo "afs upload sha mismatch" >&2; return 1; }

  say "uploading agentsfs-chat source…"
  tar czf "$WORK/src.tgz" -C "$CHAT_SRC" --exclude node_modules --exclude .git --exclude .env . 2>/dev/null
  { echo "rm -rf /home/sprite/agentsfs-chat && mkdir -p /home/sprite/agentsfs-chat && base64 -d > /tmp/src.tgz <<'SRCEOF'";
    base64 < "$WORK/src.tgz"; echo; echo "SRCEOF";
    echo "tar xzf /tmp/src.tgz -C /home/sprite/agentsfs-chat && rm /tmp/src.tgz && echo src-ok"; } | exec_sh "$NAME" >/dev/null

  say "installing deps + cloning $HUB_USER/$SLUG…"
  local B64AUTH; B64AUTH="$(printf '%s:%s' "$HUB_USER" "$HUB_TOKEN" | base64)"
  exec_sh "$NAME" 420 >/dev/null <<EOF
set -e
command -v rg >/dev/null 2>&1 || (sudo apt-get update -qq && sudo apt-get install -y -qq ripgrep) >/dev/null 2>&1 || true
cd /home/sprite/agentsfs-chat && npm install --no-audit --no-fund >/tmp/npm.log 2>&1 || tail -5 /tmp/npm.log
rm -rf /home/sprite/wiki
git -c http.extraHeader="Authorization: Basic $B64AUTH" clone "$HUB_URL/$HUB_USER/$SLUG.git" /home/sprite/wiki 2>&1 | tail -1
git -C /home/sprite/wiki config http.extraHeader "Authorization: Basic $B64AUTH"
git -C /home/sprite/wiki config user.name "AgentsFS Agent"
git -C /home/sprite/wiki config user.email "agent@agentsfs.ai"
EOF

  say "starting the agent service…"
  local ENVS="PORT=8080,HOST=0.0.0.0,AGENTSFS_ROOT=/home/sprite/wiki,AGENTSFS_ALLOW_WRITES=1,AFS_BIN=/home/sprite/.local/bin/afs,AGENTSFS_AGENT_NAME=AgentsFS Agent,AGENTSFS_AGENT_EMAIL=agent@agentsfs.ai,CHAT_MODEL=$CHAT_MODEL,OPENAI_API_KEY=$OPENAI_API_KEY"
  { printf 'sprite-env services delete agent >/dev/null 2>&1 || true\n';
    printf "sprite-env services create agent --cmd npm --args start --dir /home/sprite/agentsfs-chat --http-port 8080 --env '%s' >/dev/null 2>&1\n" "$ENVS"; } | exec_sh "$NAME" >/dev/null

  local i code
  for i in $(seq 1 20); do
    code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 -H "$AUTH" "$URL/api/health" || true)"
    [ "$code" = "200" ] && break; sleep 3
  done
  printf '\n  Agent live for %s/%s\n  → %s\n  (first visit signs in via your sprites.dev org)\n\n' "$HUB_USER" "$SLUG" "$URL"
}

cmd_url()     { sprite_url "$(sprite_name "${1:?usage: url <repo>}")"; }
cmd_status()  { local N; N="$(sprite_name "${1:?usage: status <repo>}")"; curl -sS "$API/sprites/$N" -H "$AUTH" | python3 -m json.tool 2>/dev/null | grep -E '"(name|status|url)"' || true;
                # NB: never print the service env — it holds OPENAI_API_KEY.
                printf '%s' 'sprite-env services get agent 2>/dev/null | python3 -c "import json,sys
try:
  st=json.load(sys.stdin).get(\"state\",{})
  print(\"service:\", st.get(\"status\"), \"pid:\", st.get(\"pid\"), \"since:\", st.get(\"started_at\"))
except Exception: print(\"no agent service\")"' | exec_sh "$N" 20; }
cmd_logs()    { local N; N="$(sprite_name "${1:?usage: logs <repo> [n]}")"; printf 'tail -n %s /.sprite/logs/services/agent.log 2>/dev/null || echo "no logs yet"' "${2:-40}" | exec_sh "$N" 20; }
cmd_restart() { local N; N="$(sprite_name "${1:?usage: restart <repo>}")"; printf 'sprite-env services restart agent' | exec_sh "$N" 30; }
cmd_stop()    { local N; N="$(sprite_name "${1:?usage: stop <repo>}")"; printf 'sprite-env services stop agent' | exec_sh "$N" 30; }
cmd_destroy() { local N; N="$(sprite_name "${1:?usage: destroy <repo>}")"; curl -sS -X DELETE "$API/sprites/$N" -H "$AUTH" -w '\nHTTP %{http_code}\n'; }
cmd_list()    { curl -sS "$API/sprites" -H "$AUTH" | python3 -c '
import json, sys
d = json.load(sys.stdin)
for s in d.get("sprites", []):
    n = s.get("name", "")
    if n.startswith("afs-"):
        print("%-28s %-8s %s" % (n, s.get("status", "?"), s.get("url", "")))'; }

sub="${1:-}"; shift || true
case "$sub" in
  create)  cmd_create "$@" ;;
  url)     cmd_url "$@" ;;
  status)  cmd_status "$@" ;;
  logs)    cmd_logs "$@" ;;
  restart) cmd_restart "$@" ;;
  stop)    cmd_stop "$@" ;;
  destroy) cmd_destroy "$@" ;;
  list)    cmd_list ;;
  *) sed -n '2,30p' "$0"; exit 1 ;;
esac
