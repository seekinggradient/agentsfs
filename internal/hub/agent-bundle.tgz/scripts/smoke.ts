/**
 * Live end-to-end smoke test: boots the server on an ephemeral port and
 * exercises health, config, a real streamed chat turn (hits OpenAI), the tool
 * relay, and realtime token minting. Run: `npm run smoke`.
 *
 * Requires a real OPENAI_API_KEY and a valid AGENTSFS_ROOT in .env.
 */
import type { AddressInfo } from "node:net";
import { loadConfig } from "../src/config.js";
import { createApp, startServer } from "../src/server/server.js";
// @ts-expect-error - plain JS module
import { splitSSE } from "../src/web/lib.js";

const ok = (s: string) => console.log(`  \x1b[32m✓\x1b[0m ${s}`);
const fail = (s: string) => console.log(`  \x1b[31m✗\x1b[0m ${s}`);

async function main() {
  const cfg = loadConfig();
  const ctx = await createApp(cfg);
  const server = await startServer(ctx, 0);
  const port = (server.address() as AddressInfo).port;
  const base = `http://127.0.0.1:${port}`;
  console.log(`\nsmoke: ${cfg.provider}/${cfg.chatModel} over ${cfg.agentsfsRoot}\n`);

  let failures = 0;
  const guard = async (name: string, fn: () => Promise<void>) => {
    try {
      await fn();
    } catch (e) {
      failures++;
      fail(`${name}: ${(e as Error).message}`);
    }
  };

  await guard("health", async () => {
    const j = await (await fetch(`${base}/api/health`)).json();
    if (!j.ok) throw new Error("not ok");
    ok(`health (instance: ${j.instanceName})`);
  });

  await guard("config", async () => {
    const j = await (await fetch(`${base}/api/config`)).json();
    ok(`config (domains: ${j.domains.join(", ")}; theses: ${j.capabilities.theses})`);
  });

  await guard("chat (live)", async () => {
    const r = await fetch(`${base}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: "In one sentence, what is this knowledge base about? Cite one file.",
      }),
    });
    const text = await r.text();
    const { frames } = splitSSE(text) as {
      frames: { event: string; data: string }[];
    };
    const deltas = frames.filter((f) => f.event === "delta").length;
    const doneFrame = frames.find((f) => f.event === "done");
    if (!doneFrame) throw new Error("no done event");
    const done = JSON.parse(doneFrame.data);
    if (!done.text) throw new Error("no final text");
    ok(`chat streamed ${deltas} deltas, ${done.toolCallCount} tool calls, ${done.citations.length} citations`);
    console.log(`      → ${done.text.slice(0, 140).replace(/\n/g, " ")}…`);
    if (done.citations[0]) console.log(`      → cite: ${done.citations[0].path ?? done.citations[0].url}`);
  });

  await guard("tools/call", async () => {
    const j = await (
      await fetch(`${base}/api/tools/call`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: "search_wiki", args: { query: "overview", limit: 2 } }),
      })
    ).json();
    ok(`tools/call search_wiki (${j.citations?.length ?? 0} citations)`);
  });

  await guard("realtime token", async () => {
    const j = await (await fetch(`${base}/api/realtime/token`, { method: "POST" })).json();
    if (!j.value) throw new Error(j.error || "no token");
    ok(`realtime token minted (${String(j.value).slice(0, 6)}…)`);
  });

  server.close();
  console.log(failures === 0 ? "\nAll smoke checks passed.\n" : `\n${failures} check(s) failed.\n`);
  process.exit(failures === 0 ? 0 : 1);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
