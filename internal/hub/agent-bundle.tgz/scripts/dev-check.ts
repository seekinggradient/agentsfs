/**
 * Dev utility: exercise the AgentsFS access layer against the configured
 * AGENTSFS_ROOT and print a summary. Run: npm run -s smoke is separate; this is
 * `tsx scripts/dev-check.ts`. Read-only.
 */
import { loadConfig } from "../src/config.js";
import * as afs from "../src/agentsfs/afs.js";
import { grep, readFile, listDir } from "../src/agentsfs/files.js";
import { detectCapabilities } from "../src/agentsfs/capabilities.js";
import { extractSources, extractWikilinks } from "../src/agentsfs/frontmatter.js";

const cfg = loadConfig();
console.log("root:", cfg.agentsfsRoot);
console.log("afs available:", await afs.afsAvailable());

const caps = detectCapabilities(cfg.agentsfsRoot);
console.log("capabilities:", JSON.stringify(caps));

const top = await listDir(cfg.agentsfsRoot);
console.log(
  "top entries:",
  top.map((e) => `${e.name}${e.type === "dir" ? "/" : ""}`).join(", "),
);

const results = await afs.search(cfg.agentsfsRoot, "datadog AI acceleration", {
  limit: 4,
});
console.log("\nsearch results:", results.length);
for (const r of results) {
  console.log(`  ${r.rank}. ${r.path}${r.section ? ` § ${r.section}` : ""}`);
  console.log(`     ${r.snippet.slice(0, 90)}`);
}

const g = await grep(cfg.agentsfsRoot, "AI memory scarcity", { maxResults: 3 });
console.log("\ngrep matches:", g.length, g[0] ? `e.g. ${g[0].path}:${g[0].line}` : "");

const bl = await afs.backlinks(cfg.agentsfsRoot, "Datadog");
console.log("backlinks to Datadog:", bl.length, bl[0] ? `e.g. ${bl[0].source}:${bl[0].line}` : "");

const findings = await afs.doctor(cfg.agentsfsRoot);
console.log("doctor findings:", findings.length, "(errors:", findings.filter((f) => f.severity === "error").length, ")");

if (results[0]) {
  const file = await readFile(cfg.agentsfsRoot, results[0].path);
  console.log(`\nread ${file.path}: ${file.bytes} bytes, truncated=${file.truncated}`);
  console.log("  sources:", extractSources(file.content).slice(0, 3));
  console.log("  wikilinks:", extractWikilinks(file.content).slice(0, 5));
}

const status = await afs.embeddingsStatus();
console.log("\nembeddings:", status.configured ? `${status.provider}/${status.model}` : "not configured");
