import { fileURLToPath } from "node:url";
import { join } from "node:path";
import { loadConfig, type Config } from "../src/config.js";
import type {
  ChatMessage,
  Reasoner,
  RunTurnOptions,
  TurnResult,
} from "../src/reasoner/types.js";

export const FIXTURE = fileURLToPath(
  new URL("./fixtures/mini-agentsfs", import.meta.url),
);

/** A workspace of two distinct KBs (kb-alpha has Zebra, kb-beta has Pancakes),
 *  for workspace-mode + cross-workspace tests. */
export const WORKSPACE = fileURLToPath(
  new URL("./fixtures/workspace", import.meta.url),
);
export const KB_ALPHA = join(WORKSPACE, "kb-alpha");
export const KB_BETA = join(WORKSPACE, "kb-beta");

export function makeConfig(overrides: Partial<Config> = {}): Config {
  // provider override avoids needing a real key for the mock-reasoner tests.
  return loadConfig({ agentsfsRoot: FIXTURE, provider: "openai", ...overrides });
}

/** A workspace-mode config: boots unfocused on the workspace dir, discovers the
 *  two sibling KBs, with the shell + write tools on (as the sprite runs it). */
export function makeWorkspaceConfig(overrides: Partial<Config> = {}): Config {
  return loadConfig({
    agentsfsRoot: WORKSPACE,
    searchDir: WORKSPACE,
    provider: "openai",
    mode: "workspace",
    workspaceDir: WORKSPACE,
    allowWrites: true,
    allowShell: true,
    ...overrides,
  });
}

/** A deterministic reasoner: runs a scripted list of tool calls, then "streams"
 *  a fixed answer. Lets us test the agent/server wiring without any network. */
export class MockReasoner implements Reasoner {
  readonly name = "mock";
  readonly model = "mock-model";
  constructor(
    private readonly script: { name: string; args: Record<string, unknown> }[],
    private readonly finalText: string,
  ) {}
  async runTurn(opts: RunTurnOptions): Promise<TurnResult> {
    let count = 0;
    for (const call of this.script) {
      opts.onToolCall?.(call.name, call.args);
      await opts.executeTool(call.name, call.args);
      count++;
    }
    for (const ch of this.finalText) opts.onTextDelta?.(ch);
    return {
      text: this.finalText,
      toolCallCount: count,
      model: this.model,
      usage: { inputTokens: 100, outputTokens: 20 },
    };
  }
}

/** One scripted turn: the tool calls to make, then the final answer text. */
export interface ScriptedTurn {
  script?: { name: string; args?: Record<string, unknown> }[];
  text: string;
}

/** What the reasoner received + returned on one turn — the DI seam for asserting
 *  the model actually SAW the right context (system prompt, tool set, history)
 *  and what each tool returned to it (e.g. an appended freshness hint). */
export interface CapturedTurn {
  system: string;
  userMessage: string;
  history: ChatMessage[];
  toolNames: string[];
  toolResults: string[];
}

/**
 * A reasoner driven by a per-turn QUEUE of scripts (one consumed per runTurn),
 * so a multi-turn conversation can behave differently each turn — e.g. turn 1
 * focuses repo B, turn 2 reads a B-only file. Records every turn in `calls`.
 * If more turns run than scripted, the last script repeats.
 */
export class ScriptedReasoner implements Reasoner {
  readonly name = "scripted";
  readonly model = "mock-model";
  readonly calls: CapturedTurn[] = [];
  private i = 0;
  constructor(private readonly turns: ScriptedTurn[]) {}

  async runTurn(opts: RunTurnOptions): Promise<TurnResult> {
    const turn = this.turns[Math.min(this.i, this.turns.length - 1)] ?? { text: "" };
    this.i++;
    const toolResults: string[] = [];
    let count = 0;
    for (const call of turn.script ?? []) {
      opts.onToolCall?.(call.name, call.args ?? {});
      toolResults.push(await opts.executeTool(call.name, call.args ?? {}));
      count++;
    }
    this.calls.push({
      system: opts.system,
      userMessage: opts.userMessage,
      history: opts.history,
      toolNames: opts.tools.map((t) => t.name),
      toolResults,
    });
    for (const ch of turn.text) opts.onTextDelta?.(ch);
    return {
      text: turn.text,
      toolCallCount: count,
      model: this.model,
      usage: { inputTokens: 100, outputTokens: 20 },
    };
  }
}
