import { fileURLToPath } from "node:url";
import { loadConfig, type Config } from "../src/config.js";
import type { Reasoner, RunTurnOptions, TurnResult } from "../src/reasoner/types.js";

export const FIXTURE = fileURLToPath(
  new URL("./fixtures/mini-agentsfs", import.meta.url),
);

export function makeConfig(overrides: Partial<Config> = {}): Config {
  // provider override avoids needing a real key for the mock-reasoner tests.
  return loadConfig({ agentsfsRoot: FIXTURE, provider: "openai", ...overrides });
}

/** A deterministic reasoner: runs a scripted list of tool calls, then "streams"
 *  a fixed answer. Lets us test the agent/server wiring without any network. */
export class MockReasoner implements Reasoner {
  readonly name = "mock";
  readonly model = "mock-model";
  constructor(
    private readonly script: { name: string; args: Record<string, unknown> }[],
    private readonly finalText: string,
  ) {}
  async runTurn(opts: RunTurnOptions): Promise<TurnResult> {
    let count = 0;
    for (const call of this.script) {
      opts.onToolCall?.(call.name, call.args);
      await opts.executeTool(call.name, call.args);
      count++;
    }
    for (const ch of this.finalText) opts.onTextDelta?.(ch);
    return {
      text: this.finalText,
      toolCallCount: count,
      model: this.model,
      usage: { inputTokens: 100, outputTokens: 20 },
    };
  }
}
