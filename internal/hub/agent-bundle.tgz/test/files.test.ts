import { afterEach, describe, expect, it } from "vitest";
import { existsSync, symlinkSync, unlinkSync } from "node:fs";
import { join } from "node:path";
import {
  PathEscapeError,
  grep,
  listDir,
  readFile,
  safeResolve,
} from "../src/agentsfs/files.js";
import { FIXTURE } from "./helpers.js";

describe("safeResolve (path jail)", () => {
  it("allows paths inside the root", () => {
    expect(safeResolve(FIXTURE, "notes/Apple.md")).toContain("notes/Apple.md");
    expect(safeResolve(FIXTURE, "/notes/Apple.md")).toContain("notes/Apple.md");
  });
  it("rejects traversal outside the root", () => {
    expect(() => safeResolve(FIXTURE, "../../../etc/passwd")).toThrow(PathEscapeError);
    expect(() => safeResolve(FIXTURE, "../secrets")).toThrow(PathEscapeError);
  });
});

describe("readFile", () => {
  it("reads a file inside the instance", async () => {
    const r = await readFile(FIXTURE, "notes/Apple.md");
    expect(r.path).toBe("notes/Apple.md");
    expect(r.content).toContain("# Apple");
    expect(r.truncated).toBe(false);
  });
  it("refuses to read outside the instance", async () => {
    await expect(readFile(FIXTURE, "../../../etc/passwd")).rejects.toThrow();
  });
});

describe("grep", () => {
  it("finds literal matches with path and line", async () => {
    const m = await grep(FIXTURE, "potassium");
    expect(m.length).toBeGreaterThan(0);
    expect(m[0]!.path).toContain("Banana.md");
    expect(m[0]!.line).toBeGreaterThan(0);
  });
  it("supports a glob filter", async () => {
    const m = await grep(FIXTURE, "fruit", { glob: "notes/**/*.md" });
    expect(m.every((x) => x.path.startsWith("notes/"))).toBe(true);
  });
});

describe("symlink jail", () => {
  const link = join(FIXTURE, "notes", "escape-link.md");
  afterEach(() => {
    try {
      if (existsSync(link)) unlinkSync(link);
    } catch {
      /* ignore */
    }
  });
  it("rejects reading an in-root symlink that points outside the root", async () => {
    symlinkSync("/etc/hosts", link);
    await expect(readFile(FIXTURE, "notes/escape-link.md")).rejects.toThrow(
      PathEscapeError,
    );
  });
});

describe("listDir", () => {
  it("lists entries with dirs first", async () => {
    const entries = await listDir(FIXTURE, ".");
    const names = entries.map((e) => e.name);
    expect(names).toContain("notes");
    const firstFileIdx = entries.findIndex((e) => e.type === "file");
    const lastDirIdx = entries.map((e) => e.type).lastIndexOf("dir");
    expect(lastDirIdx).toBeLessThan(firstFileIdx);
  });
});
