import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import {
  description,
  extractSources,
  extractWikilinks,
  parseFrontmatter,
} from "../src/agentsfs/frontmatter.js";
import { FIXTURE } from "./helpers.js";

const apple = readFileSync(join(FIXTURE, "notes", "Apple.md"), "utf8");

describe("frontmatter", () => {
  it("parses frontmatter data and body", () => {
    const { data, body, hasFrontmatter } = parseFrontmatter(apple);
    expect(hasFrontmatter).toBe(true);
    expect(data["description"]).toMatch(/apples/i);
    expect(Array.isArray(data["sources"])).toBe(true);
    expect(body).toMatch(/^# Apple/);
  });

  it("returns no frontmatter for plain text", () => {
    const r = parseFrontmatter("# Just markdown\n\nno frontmatter");
    expect(r.hasFrontmatter).toBe(false);
    expect(r.data).toEqual({});
  });

  it("extracts the description", () => {
    expect(description(apple)).toMatch(/apples/i);
  });

  it("extracts wikilinks deduped", () => {
    expect(extractWikilinks(apple)).toContain("Banana");
    // [[Banana]] appears twice (sources + body) but should dedupe
    expect(extractWikilinks(apple).filter((x) => x === "Banana")).toHaveLength(1);
  });

  it("extracts sources from frontmatter and body urls", () => {
    const sources = extractSources(apple);
    expect(sources).toContain("https://example.com/apple-facts");
    expect(sources).toContain("[[Banana]]");
  });
});
