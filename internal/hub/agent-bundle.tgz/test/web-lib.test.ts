import { describe, expect, it } from "vitest";
// @ts-expect-error - plain JS module, no types
import { escapeHtml, renderMarkdown, splitSSE } from "../src/web/lib.js";

describe("escapeHtml", () => {
  it("escapes html-sensitive characters", () => {
    expect(escapeHtml('<script>"x"</script>')).toBe(
      "&lt;script&gt;&quot;x&quot;&lt;/script&gt;",
    );
  });
});

describe("renderMarkdown", () => {
  it("renders headings, bold, inline code, and links", () => {
    const html = renderMarkdown(
      "# Title\n\nSome **bold** and `code` and [link](https://x.com).",
    );
    expect(html).toContain("<h1>Title</h1>");
    expect(html).toContain("<strong>bold</strong>");
    expect(html).toContain("<code>code</code>");
    expect(html).toContain('<a href="https://x.com"');
  });

  it("renders unordered and ordered lists", () => {
    expect(renderMarkdown("- a\n- b")).toContain("<ul><li>a</li><li>b</li></ul>");
    expect(renderMarkdown("1. a\n2. b")).toContain("<ol><li>a</li><li>b</li></ol>");
  });

  it("escapes html in content (no injection)", () => {
    const html = renderMarkdown("<img src=x onerror=alert(1)>");
    expect(html).not.toContain("<img");
    expect(html).toContain("&lt;img");
  });

  it("renders fenced code blocks", () => {
    const html = renderMarkdown("```\nconst x = 1;\n```");
    expect(html).toContain("<pre><code>");
    expect(html).toContain("const x = 1;");
  });
});

describe("splitSSE", () => {
  it("parses complete frames and keeps the remainder", () => {
    const { frames, rest } = splitSSE(
      'event: delta\ndata: {"text":"hi"}\n\nevent: done\ndata: {"ok":true}\n\nevent: partial\ndata: {',
    );
    expect(frames).toHaveLength(2);
    expect(frames[0]).toEqual({ event: "delta", data: '{"text":"hi"}' });
    expect(frames[1]!.event).toBe("done");
    expect(rest).toBe("event: partial\ndata: {");
  });

  it("returns no frames for an incomplete buffer", () => {
    const { frames, rest } = splitSSE("event: delta\ndata: {");
    expect(frames).toHaveLength(0);
    expect(rest).toContain("event: delta");
  });
});
