import { describe, expect, it } from "vitest";
import { Agent } from "../src/agent/session.js";
import { FIXTURE, makeConfig, MockReasoner } from "./helpers.js";

describe("Agent.ask (with a mock reasoner)", () => {
  it("dispatches tools, streams text, and aggregates citations", async () => {
    const cfg = makeConfig({ agentsfsRoot: FIXTURE });
    const reasoner = new MockReasoner(
      [{ name: "read_file", args: { path: "notes/Apple.md" } }],
      "Apples are a fruit rich in fiber.",
    );
    const agent = await Agent.create(cfg, reasoner);

    const deltas: string[] = [];
    const toolCalls: string[] = [];
    const result = await agent.ask({
      message: "Tell me about apples.",
      onTextDelta: (d) => deltas.push(d),
      onToolCall: (n) => toolCalls.push(n),
    });

    expect(result.text).toBe("Apples are a fruit rich in fiber.");
    expect(deltas.join("")).toBe(result.text);
    expect(toolCalls).toEqual(["read_file"]);
    expect(result.toolCallCount).toBe(1);
    // citations aggregated from the read_file tool
    expect(result.citations.some((c) => c.path === "notes/Apple.md")).toBe(true);
    expect(result.citations.some((c) => c.url?.includes("apple-facts"))).toBe(true);
    // usage surfaced from the reasoner
    expect(result.usage).toEqual({ inputTokens: 100, outputTokens: 20 });
  });

  it("dedupes citations across multiple tool calls", async () => {
    const cfg = makeConfig({ agentsfsRoot: FIXTURE });
    const reasoner = new MockReasoner(
      [
        { name: "read_file", args: { path: "notes/Apple.md" } },
        { name: "read_file", args: { path: "notes/Apple.md" } },
      ],
      "done",
    );
    const agent = await Agent.create(cfg, reasoner);
    const result = await agent.ask({ message: "x" });
    const appleCites = result.citations.filter((c) => c.path === "notes/Apple.md");
    expect(appleCites).toHaveLength(1);
  });

  it("exposes capabilities and instance name", async () => {
    const agent = await Agent.create(makeConfig(), new MockReasoner([], ""));
    expect(agent.instanceName).toBe("mini-agentsfs");
    expect(agent.capabilities.thesesJsonPath).toBeTruthy();
    expect(agent.realtimeInstructions()).toMatch(/consult_knowledge/);
  });
});
