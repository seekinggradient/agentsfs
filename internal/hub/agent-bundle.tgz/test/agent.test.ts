import { describe, expect, it } from "vitest";
import { Agent } from "../src/agent/session.js";
import {
  _setBehindForTest,
  clearFreshness,
  pullHint,
} from "../src/agentsfs/freshness.js";
import { FIXTURE, makeConfig, MockReasoner, ScriptedReasoner } from "./helpers.js";

describe("Agent.ask (with a mock reasoner)", () => {
  it("dispatches tools, streams text, and aggregates citations", async () => {
    const cfg = makeConfig({ agentsfsRoot: FIXTURE });
    const reasoner = new MockReasoner(
      [{ name: "read_file", args: { path: "notes/Apple.md" } }],
      "Apples are a fruit rich in fiber.",
    );
    const agent = await Agent.create(cfg, reasoner);

    const deltas: string[] = [];
    const toolCalls: string[] = [];
    const result = await agent.ask({
      message: "Tell me about apples.",
      onTextDelta: (d) => deltas.push(d),
      onToolCall: (n) => toolCalls.push(n),
    });

    expect(result.text).toBe("Apples are a fruit rich in fiber.");
    expect(deltas.join("")).toBe(result.text);
    expect(toolCalls).toEqual(["read_file"]);
    expect(result.toolCallCount).toBe(1);
    // citations aggregated from the read_file tool
    expect(result.citations.some((c) => c.path === "notes/Apple.md")).toBe(true);
    expect(result.citations.some((c) => c.url?.includes("apple-facts"))).toBe(true);
    // usage surfaced from the reasoner
    expect(result.usage).toEqual({ inputTokens: 100, outputTokens: 20 });
  });

  it("dedupes citations across multiple tool calls", async () => {
    const cfg = makeConfig({ agentsfsRoot: FIXTURE });
    const reasoner = new MockReasoner(
      [
        { name: "read_file", args: { path: "notes/Apple.md" } },
        { name: "read_file", args: { path: "notes/Apple.md" } },
      ],
      "done",
    );
    const agent = await Agent.create(cfg, reasoner);
    const result = await agent.ask({ message: "x" });
    const appleCites = result.citations.filter((c) => c.path === "notes/Apple.md");
    expect(appleCites).toHaveLength(1);
  });

  it("exposes capabilities and instance name", async () => {
    const agent = await Agent.create(makeConfig(), new MockReasoner([], ""));
    expect(agent.instanceName).toBe("mini-agentsfs");
    expect(agent.capabilities.thesesJsonPath).toBeTruthy();
    expect(agent.realtimeInstructions()).toMatch(/consult_knowledge/);
  });

  // T1.2 — a search then a read, citations aggregated across both.
  it("aggregates citations across a search + read", async () => {
    const cfg = makeConfig();
    const reasoner = new ScriptedReasoner([
      {
        script: [
          { name: "search_wiki", args: { query: "fiber" } },
          { name: "read_file", args: { path: "notes/Apple.md" } },
        ],
        text: "Apples are rich in fiber.",
      },
    ]);
    const agent = await Agent.create(cfg, reasoner);
    const result = await agent.ask({ message: "apples?" });
    expect(result.toolCallCount).toBe(2);
    expect(result.citations.some((c) => c.path === "notes/Apple.md")).toBe(true);
  });

  // T1.3 — a plain answer with no tool calls.
  it("answers with no tools (no citations, toolCallCount 0)", async () => {
    const reasoner = new ScriptedReasoner([{ text: "Hello there." }]);
    const agent = await Agent.create(makeConfig(), reasoner);
    const result = await agent.ask({ message: "hi" });
    expect(result.text).toBe("Hello there.");
    expect(result.toolCallCount).toBe(0);
    expect(result.citations).toHaveLength(0);
  });
});

describe("freshness hint on read tools", () => {
  // T1.4a — the hint text is deterministic given a seeded behind-count.
  it("pullHint reflects the behind-count, and clears", () => {
    _setBehindForTest(FIXTURE, 2);
    expect(pullHint(FIXTURE)).toMatch(/2 newer commits/);
    clearFreshness(FIXTURE);
    expect(pullHint(FIXTURE)).toBe("");
  });

  // T1.4b — a read tool's result carries the hint to the model when behind.
  it("appends the stale-checkout hint to a read tool's result", async () => {
    const cfg = makeConfig();
    const reasoner = new ScriptedReasoner([
      { script: [{ name: "read_file", args: { path: "notes/Apple.md" } }], text: "ok" },
    ]);
    const agent = await Agent.create(cfg, reasoner);
    // Let the create-time freshness probe (a non-git fixture → behind 0) settle,
    // then seed a deterministic behind-count so the hint is asserted race-free.
    await new Promise((r) => setTimeout(r, 250));
    _setBehindForTest(FIXTURE, 3);
    await agent.ask({ message: "apples?" });
    expect(reasoner.calls[0]!.toolResults[0]!).toMatch(/3 newer commits/);
    clearFreshness(FIXTURE);
  });
});
