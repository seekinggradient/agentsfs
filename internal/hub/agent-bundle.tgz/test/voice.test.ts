import { basename } from "node:path";
import { describe, expect, it, vi } from "vitest";
import { Agent } from "../src/agent/session.js";
import { createApp, executeNamedTool } from "../src/server/server.js";
import { mintEphemeralToken } from "../src/server/realtime.js";
import {
  makeConfig,
  makeWorkspaceConfig,
  MockReasoner,
  ScriptedReasoner,
} from "./helpers.js";

// The real WebRTC audio round-trip needs a browser and isn't tested here; these
// cover the SERVER-side voice paths — token mint, the consult_knowledge relay,
// and voice/typed sharing the same focused repo.

describe("voice token mint (T5.1)", () => {
  async function capturedMint(cfg: ReturnType<typeof makeConfig>) {
    const agent = await Agent.create(cfg, new MockReasoner([], ""));
    let captured: { url: string; auth: unknown; body: any } | null = null;
    vi.stubGlobal("fetch", async (url: string, init: any) => {
      captured = { url, auth: init.headers.Authorization, body: JSON.parse(init.body) };
      return new Response(JSON.stringify({ value: "ek_test", expires_at: 1 }), { status: 200 });
    });
    const token = await mintEphemeralToken(cfg, agent);
    vi.unstubAllGlobals();
    return { token, captured: captured! };
  }

  it("proxy mode: mints via the hub URL with the PAT as Bearer", async () => {
    const cfg = { ...makeConfig(), llmBaseUrl: "https://hub.example/v1/agent-llm", openaiApiKey: "afs_pat" };
    const { token, captured } = await capturedMint(cfg);
    expect(token.value).toBe("ek_test");
    expect(captured.url).toBe("https://hub.example/v1/agent-llm/realtime/client_secrets");
    expect(captured.auth).toBe("Bearer afs_pat");
    // the session advertises the voice tool set + the configured model
    expect(JSON.stringify(captured.body)).toContain("consult_knowledge");
    expect(captured.body.session.model).toBe(cfg.realtimeModel);
  });

  it("non-proxy mode: mints directly against api.openai.com with the real key", async () => {
    const cfg = { ...makeConfig(), llmBaseUrl: undefined, openaiApiKey: "sk-real" };
    const { captured } = await capturedMint(cfg);
    expect(captured.url).toBe("https://api.openai.com/v1/realtime/client_secrets");
    expect(captured.auth).toBe("Bearer sk-real");
  });
});

describe("voice relay + voice/typed mode sharing (T5.2–T5.4)", () => {
  // T5.2 — consult_knowledge runs the full agent in VOICE mode.
  it("consult_knowledge runs the agent in voice mode", async () => {
    const reasoner = new ScriptedReasoner([
      { script: [{ name: "read_file", args: { path: "notes/Apple.md" } }], text: "Apples are a fruit." },
    ]);
    const ctx = await createApp(makeConfig(), reasoner);
    const out = await executeNamedTool(ctx, "consult_knowledge", { question: "apples?" });
    expect(out.content).toBe("Apples are a fruit.");
    expect(out.citations.length).toBeGreaterThan(0);
    expect(reasoner.calls[0]!.system).toMatch(/spoken aloud|voice/i);
  });

  // T5.3 — in one session, a typed turn and a voice turn both resolve against the
  // SAME focused repo (kb-beta), distinguished only by mode.
  it("typed and voice turns share the focused repo", async () => {
    const reasoner = new ScriptedReasoner([
      { script: [{ name: "read_file", args: { path: "recipes/Pancakes.md" } }], text: "typed pancakes" },
      { script: [{ name: "read_file", args: { path: "recipes/Pancakes.md" } }], text: "voice pancakes" },
    ]);
    const ctx = await createApp(makeWorkspaceConfig(), reasoner);
    await ctx.onFocusRepo!("kb-beta"); // the user switched to beta (a typed-mode action)

    const typed = await ctx.agent.ask({ message: "pancakes?", mode: "chat" });
    const voice = await executeNamedTool(ctx, "consult_knowledge", { question: "pancakes?" });

    expect(typed.text).toContain("typed");
    expect(voice.content).toContain("voice");
    expect(reasoner.calls[0]!.system).not.toMatch(/spoken aloud/i); // typed
    expect(reasoner.calls[1]!.system).toMatch(/spoken aloud|voice/i); // voice
    // both grounded in the same (beta-only) file → same active KB across modes
    expect(typed.citations.some((c) => c.path === "recipes/Pancakes.md")).toBe(true);
    expect(voice.citations.some((c: { path?: string }) => c.path === "recipes/Pancakes.md")).toBe(true);
  });

  // T5.4 — the voice token instructions (used at mint time) follow a focus switch.
  it("voice instructions follow the focused repo", async () => {
    const ctx = await createApp(makeWorkspaceConfig(), new MockReasoner([], ""));
    await ctx.onFocusRepo!("kb-alpha");
    expect(ctx.agent.realtimeInstructions()).toContain("kb-alpha");
    await ctx.onFocusRepo!("kb-beta");
    expect(ctx.agent.realtimeInstructions()).toContain("kb-beta");
  });
});

// The real WebRTC audio round-trip needs a browser (untested here), but voice
// CAN now switch workspaces: the mint advertises the switch tools, and focusing
// through the tool relay (the path the voice data-channel uses) actually switches.
describe("voice can switch workspaces (server-side)", () => {
  it("the minted session advertises list_repos + focus_repo", async () => {
    const cfg = { ...makeWorkspaceConfig(), llmBaseUrl: "https://hub.example/v1/agent-llm", openaiApiKey: "afs_pat" };
    const agent = await Agent.create(cfg, new MockReasoner([], ""));
    let toolNames: string[] = [];
    vi.stubGlobal("fetch", async (_url: string, init: any) => {
      toolNames = (JSON.parse(init.body).session.tools || []).map((t: any) => t.name);
      return new Response(JSON.stringify({ value: "ek" }), { status: 200 });
    });
    await mintEphemeralToken(cfg, agent);
    vi.unstubAllGlobals();
    expect(toolNames).toContain("consult_knowledge");
    expect(toolNames).toContain("list_repos");
    expect(toolNames).toContain("focus_repo");
  });

  it("focus_repo through the tool relay switches the active KB", async () => {
    const ctx = await createApp(makeWorkspaceConfig(), new MockReasoner([], ""));
    const out = await executeNamedTool(ctx, "focus_repo", { repo: "kb-beta" });
    expect(out.content).toMatch(/Focused on/i);
    expect(basename(ctx.session.root)).toBe("kb-beta");
  });
});
