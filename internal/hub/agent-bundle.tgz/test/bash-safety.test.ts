import { describe, expect, it, vi } from "vitest";
import { runShell } from "../src/agentsfs/shell.js";
import { redactSecrets } from "../src/agentsfs/redact.js";
import { Agent } from "../src/agent/session.js";
import { makeWorkspaceConfig, ScriptedReasoner, WORKSPACE } from "./helpers.js";

// The bash tool is arbitrary /bin/sh -c; its safety rests on (1) a scrubbed
// child env so secrets can't be printed, and (2) a redactor on all tool output
// as defense-in-depth. (The real boundary — no OpenAI key in the sprite via the
// hub proxy — is a deploy property, verified separately against the sprite.)

describe("run_bash env scrub (shell.ts)", () => {
  it("drops secrets from the child env but keeps PATH", async () => {
    vi.stubEnv("OPENAI_API_KEY", "sk-should-be-scrubbed-1234567890");
    vi.stubEnv("MY_SERVICE_TOKEN", "tok-should-be-scrubbed");
    const r = await runShell(
      WORKSPACE,
      'printenv OPENAI_API_KEY || echo NO_OPENAI; printenv MY_SERVICE_TOKEN || echo NO_TOKEN; test -n "$PATH" && echo HAS_PATH',
    );
    expect(r.output).toContain("NO_OPENAI");
    expect(r.output).toContain("NO_TOKEN");
    expect(r.output).toContain("HAS_PATH");
    expect(r.output).not.toContain("sk-should-be-scrubbed");
    expect(r.output).not.toContain("tok-should-be-scrubbed");
    vi.unstubAllEnvs();
  });

  it("returns combined output and surfaces a non-zero exit code", async () => {
    const r = await runShell(WORKSPACE, "echo out; echo err 1>&2; exit 3");
    expect(r.code).toBe(3);
    expect(r.output).toContain("out");
    expect(r.output).toContain("err");
    expect(r.output).toMatch(/\[exit 3\]/);
  });
});

describe("tool-output redaction (redact.ts)", () => {
  it("masks secret shapes and leaves clean text alone", () => {
    expect(redactSecrets("key sk-ABCDEFGHIJKLMNOPQRSTUV here")).toBe("key [redacted] here");
    expect(redactSecrets("pat afs_abcdefghij1234567890 x")).toBe("pat [redacted] x");
    expect(redactSecrets("Authorization: Bearer abcdef1234567890xyz")).toContain("[redacted]");
    expect(redactSecrets("nothing secret in this sentence")).toBe("nothing secret in this sentence");
  });
});

describe("end-to-end — a secret a tool surfaces is redacted before the model", () => {
  it("run_bash output is redacted in the reasoner's tool result", async () => {
    const reasoner = new ScriptedReasoner([
      {
        script: [{ name: "run_bash", args: { command: "echo 'leaked sk-ABCDEFGHIJKLMNOPQRSTUV done'" } }],
        text: "ok",
      },
    ]);
    const agent = await Agent.create(makeWorkspaceConfig(), reasoner);
    await agent.ask({ message: "run it" });
    const toolResult = reasoner.calls[0]!.toolResults[0]!;
    expect(toolResult).toContain("[redacted]");
    expect(toolResult).not.toContain("sk-ABCDEFGHIJKLMNOPQRSTUV");
  });
});
