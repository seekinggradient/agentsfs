import type { AddressInfo } from "node:net";
import { describe, expect, it } from "vitest";
import { Agent } from "../src/agent/session.js";
import { createApp, executeNamedTool, startServer } from "../src/server/server.js";
// @ts-expect-error - plain JS module
import { splitSSE } from "../src/web/lib.js";
import { makeConfig, makeWorkspaceConfig } from "./helpers.js";

/**
 * LIVE eval — the ACTUAL agent in the loop: the real model (gpt-5.1) decides
 * which tools to call, runs them against the fixtures, and produces an answer.
 * Non-deterministic, hits the network, and costs tokens, so it is SKIPPED unless
 * RUN_LIVE=1 (and a key is in .env). Run: `npm run test:live`.
 *
 * Assertions are robust invariants — a tool was actually called, the right file
 * was cited, and an expected keyword appears — not exact strings.
 */
const LIVE = process.env.RUN_LIVE === "1";
const T = 90_000; // real API turns are slow

async function liveChat(base: string, message: string) {
  const r = await fetch(`${base}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message }),
  });
  const { frames } = splitSSE(await r.text()) as { frames: { event: string; data: string }[] };
  const done = frames.find((f) => f.event === "done");
  if (!done) throw new Error("no done event: " + (await r.status));
  const tools = frames.filter((f) => f.event === "tool").map((f) => JSON.parse(f.data).name);
  return { ...JSON.parse(done.data), tools } as {
    text: string;
    citations: { path?: string; url?: string }[];
    tools: string[];
    toolCallCount: number;
    model: string;
  };
}
const focus = (base: string, repo: string) =>
  fetch(`${base}/api/focus`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ repo }),
  });

describe.skipIf(!LIVE)("LIVE — real agent in the loop", () => {
  // Tier 1 — a simple question, answered by the model actually reading the KB.
  it("reads the KB to answer a simple question, with a citation", async () => {
    const agent = await Agent.create(makeConfig()); // no mock → real reasoner
    const tools: string[] = [];
    const r = await agent.ask({
      message: "What does this knowledge base say about apples? Cite the source file.",
      onToolCall: (n) => tools.push(n),
    });
    console.log(`\n  [T1] tools=[${tools.join(", ")}]  model=${r.model}\n  [T1] ${r.text.slice(0, 200)}\n  [T1] cites=${r.citations.map((c) => c.path ?? c.url).join(", ")}`);
    expect(tools.length).toBeGreaterThan(0); // it actually used a tool
    expect(r.text.toLowerCase()).toMatch(/apple|fruit|fiber|vitamin/);
    expect(r.citations.some((c) => c.path?.includes("Apple"))).toBe(true);
  }, T);

  // Tier 2 — cross-workspace: focus one KB, ask; focus another, ask. Structured
  // tools only (no shell) so focus strictly scopes what the agent can read.
  it("answers from the focused KB, then from a different KB after switching", async () => {
    const ctx = await createApp(makeWorkspaceConfig({ allowShell: false }));
    const server = await startServer(ctx, 0);
    const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
    try {
      expect((await focus(base, "kb-alpha")).status).toBe(200);
      const a = await liveChat(base, "What animal is documented in this knowledge base, and what are its markings? Cite the file.");
      console.log(`\n  [T2 alpha] tools=[${a.tools.join(", ")}]\n  [T2 alpha] ${a.text.slice(0, 180)}\n  [T2 alpha] cites=${a.citations.map((c) => c.path).join(", ")}`);
      expect(a.text.toLowerCase()).toMatch(/zebra|strip/);
      expect(a.citations.some((c) => c.path?.includes("Zebra"))).toBe(true);

      expect((await focus(base, "kb-beta")).status).toBe(200);
      const b = await liveChat(base, "What food is documented in this knowledge base, and what is it made from? Cite the file.");
      console.log(`\n  [T2 beta] tools=[${b.tools.join(", ")}]\n  [T2 beta] ${b.text.slice(0, 180)}\n  [T2 beta] cites=${b.citations.map((c) => c.path).join(", ")}`);
      expect(b.text.toLowerCase()).toMatch(/pancake|batter|flour/);
      expect(b.citations.some((c) => c.path?.includes("Pancakes"))).toBe(true);
    } finally {
      server.close();
    }
  }, T * 2);

  // Regression for the switch-workspaces bug: focus_repo must take effect in the
  // SAME turn, so "switch to X and tell me about it" reads X with clean
  // repo-relative paths (not a workspace-prefixed workaround, and no mixed repos).
  it("focus_repo takes effect immediately (switch + read in one turn)", async () => {
    const ctx = await createApp(makeWorkspaceConfig({ allowShell: false }));
    const server = await startServer(ctx, 0);
    const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
    try {
      const done = await liveChat(
        base,
        "Switch to the kb-beta knowledge base and tell me what food is documented there. Cite the file.",
      );
      console.log(`\n  [immediate-focus] tools=[${done.tools.join(", ")}]  cites=${done.citations.map((c) => c.path).join(", ")}`);
      expect(done.tools).toContain("focus_repo");
      expect(done.text.toLowerCase()).toMatch(/pancake|batter|flour/);
      // KEY: the read is scoped to the focused repo (clean relative path), not
      // worked around via the workspace dir (kb-beta/recipes/…).
      expect(done.citations.some((c) => c.path === "recipes/Pancakes.md")).toBe(true);
      expect(done.citations.every((c) => !c.path?.startsWith("kb-beta/"))).toBe(true);
    } finally {
      server.close();
    }
  }, T * 2);

  // Tier 5 — the voice path: consult_knowledge runs the real agent in voice mode.
  it("voice consult_knowledge runs the real agent and cites a source", async () => {
    const ctx = await createApp(makeConfig());
    const out = await executeNamedTool(ctx, "consult_knowledge", {
      question: "In a sentence, what is an apple?",
    });
    console.log(`\n  [T5] ${out.content.slice(0, 180)}\n  [T5] cites=${out.citations.map((c) => c.path).join(", ")}`);
    expect(out.content.toLowerCase()).toMatch(/apple|fruit/);
    expect(out.citations.length).toBeGreaterThan(0);
  }, T);
});
