---
description: Reference note about bananas.
sources:
  - "https://example.com/banana-facts"
---

# Banana

The banana is an elongated, edible fruit. Unlike the [[Apple]], it is rich in
potassium.
