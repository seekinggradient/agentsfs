---
description: Reference note about apples.
sources:
  - "https://example.com/apple-facts"
  - "[[Banana]]"
---

# Apple

The apple is a sweet, edible fruit produced by an apple tree. Apples are rich in
fiber and vitamin C. See also [[Banana]] for a comparison.
