---
description: Example reference notes about fruit.
---

# Notes
