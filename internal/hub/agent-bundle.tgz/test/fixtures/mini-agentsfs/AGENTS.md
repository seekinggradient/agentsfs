---
description: Tiny test AgentsFS instance for agentsfs-chat unit and integration tests.
agentsfs_contract: 0.2.0
---

# This folder is an agentsfs

A minimal fixture used by the test suite. It mimics the AgentsFS contract:
self-describing files, INDEX.md per directory, and [[wikilinks]].
