---
description: Root index for the mini test instance.
---

# Mini test instance

- notes/ — example reference notes
- stocks/ — minimal stocks structure to exercise capability detection
