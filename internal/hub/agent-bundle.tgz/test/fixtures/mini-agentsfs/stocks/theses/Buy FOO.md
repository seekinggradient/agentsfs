---
description: Test thesis to buy FOO.
thesis_id: thesis-buy-foo-test
stance: buy
conviction: high
instruments: [FOO]
sources:
  - "https://example.com/foo-earnings"
---

# Buy FOO

FOO is a fictional company used in tests. The bear case is that FOO is fictional.
Invalidate if FOO stops being a useful test fixture.
