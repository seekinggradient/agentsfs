---
description: Minimal thesis directory for capability-detection tests.
---

# Theses
