---
description: Alpha knowledge base — animals. Test fixture for workspace-mode tests.
agentsfs_contract: 0.2.0
---

# This folder is an agentsfs

The "alpha" workspace fixture. Its distinctive note is [[Zebra]] (which exists
only here), so a cross-workspace test can tell which KB is focused.
