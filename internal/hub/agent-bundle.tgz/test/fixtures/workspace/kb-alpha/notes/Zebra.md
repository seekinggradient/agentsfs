---
description: Reference note about zebras (alpha KB only).
---

# Zebra

A zebra is an African equine with distinctive black-and-white stripes. This note
exists only in the alpha knowledge base.
