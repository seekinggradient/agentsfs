---
description: Beta knowledge base — recipes. Test fixture for workspace-mode tests.
agentsfs_contract: 0.2.0
---

# This folder is an agentsfs

The "beta" workspace fixture. Its distinctive note is [[Pancakes]] (which exists
only here), so a cross-workspace test can tell which KB is focused.
