---
description: Reference note about pancakes (beta KB only).
---

# Pancakes

Pancakes are a flat cake of fried batter (flour, eggs, milk). This note exists
only in the beta knowledge base.
