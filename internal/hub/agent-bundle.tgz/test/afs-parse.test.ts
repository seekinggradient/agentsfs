import { describe, expect, it } from "vitest";
import { parseBacklinks, parseSearch } from "../src/agentsfs/afs.js";

describe("parseSearch", () => {
  it("parses full-text results with section and snippet", () => {
    const out = `1. work/Apple.md
   section: Valuation
   …trades at a forward «P» «E» of 28×…

2. work/Microsoft.md
   …competitive «moat» around Azure…`;
    const r = parseSearch(out);
    expect(r).toHaveLength(2);
    expect(r[0]).toMatchObject({ rank: 1, path: "work/Apple.md", section: "Valuation" });
    expect(r[0]!.snippet).toContain("forward");
    expect(r[1]!.path).toBe("work/Microsoft.md");
    expect(r[1]!.section).toBeUndefined();
  });

  it("parses semantic results with score and paths containing spaces", () => {
    const out = `1. theses/Buy DDOG and SNOW.md  score 0.842
   section: Moat
   ecosystem lock-in...`;
    const r = parseSearch(out);
    expect(r[0]!.path).toBe("theses/Buy DDOG and SNOW.md");
    expect(r[0]!.score).toBeCloseTo(0.842);
  });

  it("returns [] on no matches", () => {
    expect(parseSearch("no matches (try fewer or different words)")).toEqual([]);
    expect(parseSearch("")).toEqual([]);
  });
});

describe("parseBacklinks", () => {
  it("parses source:line [[target]]", () => {
    const out = `work/Microsoft.md:42  [[Apple]]
reference/notes.md:7  [[work/Apple]]`;
    const r = parseBacklinks(out);
    expect(r).toHaveLength(2);
    expect(r[0]).toEqual({ source: "work/Microsoft.md", line: 42, target: "Apple" });
    expect(r[1]!.target).toBe("work/Apple");
  });

  it("returns [] when no links", () => {
    expect(parseBacklinks('no links to "Apple" found')).toEqual([]);
  });
});
