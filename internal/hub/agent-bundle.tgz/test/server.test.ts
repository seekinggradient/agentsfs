import type { AddressInfo } from "node:net";
import type { Server } from "node:http";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { createApp, startServer } from "../src/server/server.js";
import { FIXTURE, makeConfig, MockReasoner } from "./helpers.js";
// @ts-expect-error - plain JS module
import { splitSSE } from "../src/web/lib.js";

let server: Server;
let base: string;

beforeAll(async () => {
  const cfg = makeConfig();
  const reasoner = new MockReasoner(
    [{ name: "read_file", args: { path: "notes/Apple.md" } }],
    "Apples are a fruit.",
  );
  const ctx = await createApp(cfg, reasoner);
  server = await startServer(ctx, 0);
  const port = (server.address() as AddressInfo).port;
  base = `http://127.0.0.1:${port}`;
});

afterAll(() => {
  server?.close();
});

describe("server endpoints", () => {
  it("GET /api/health", async () => {
    const r = await fetch(`${base}/api/health`);
    const j = await r.json();
    expect(j.ok).toBe(true);
    expect(j.instanceName).toBe("mini-agentsfs");
  });

  it("GET /api/config exposes capabilities and suggestions", async () => {
    const j = await (await fetch(`${base}/api/config`)).json();
    expect(j.capabilities.theses).toBe(true);
    expect(Array.isArray(j.suggestedPrompts)).toBe(true);
    expect(j.realtime.model).toBeTruthy();
  });

  it("serves the web UI", async () => {
    const html = await (await fetch(`${base}/`)).text();
    expect(html).toContain("<title>agentsfs-chat</title>");
    const js = await fetch(`${base}/app.js`);
    expect(js.headers.get("content-type")).toContain("javascript");
    expect((await fetch(`${base}/lib.js`)).status).toBe(200);
  });

  it("POST /api/tools/call runs a tool with citations", async () => {
    const r = await fetch(`${base}/api/tools/call`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: "read_file", args: { path: "notes/Apple.md" } }),
    });
    const j = await r.json();
    expect(j.content).toContain("# Apple");
    expect(j.citations.some((c: { path?: string }) => c.path === "notes/Apple.md")).toBe(true);
  });

  it("POST /api/tools/call consult_knowledge runs the agent", async () => {
    const r = await fetch(`${base}/api/tools/call`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: "consult_knowledge", args: { question: "apples?" } }),
    });
    const j = await r.json();
    expect(j.content).toBe("Apples are a fruit.");
    expect(j.citations.length).toBeGreaterThan(0);
    expect(j.usage).toEqual({ inputTokens: 100, outputTokens: 20 });
  });

  it("POST /api/chat streams SSE deltas, a done event, and citations", async () => {
    const r = await fetch(`${base}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: "tell me about apples" }),
    });
    const text = await r.text();
    const { frames } = splitSSE(text);
    const deltas = frames.filter((f: { event: string }) => f.event === "delta");
    const done = frames.find((f: { event: string }) => f.event === "done");
    const tool = frames.find((f: { event: string }) => f.event === "tool");
    expect(deltas.length).toBeGreaterThan(0);
    expect(tool).toBeTruthy();
    expect(done).toBeTruthy();
    const doneData = JSON.parse(done!.data);
    expect(doneData.text).toBe("Apples are a fruit.");
    expect(doneData.citations.length).toBeGreaterThan(0);
    expect(doneData.usage).toEqual({ inputTokens: 100, outputTokens: 20 });
  });

  it("returns 400 on invalid chat body", async () => {
    const r = await fetch(`${base}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nope: 1 }),
    });
    expect(r.status).toBe(400);
  });

  it("returns 400 on malformed JSON (not a 500)", async () => {
    const r = await fetch(`${base}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "this is not json",
    });
    expect(r.status).toBe(400);
  });

  it("tools/call returns a graceful tool error (not 500) on a bad path", async () => {
    const r = await fetch(`${base}/api/tools/call`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: "read_file", args: { path: "../../../etc/passwd" } }),
    });
    expect(r.status).toBe(200);
    const j = await r.json();
    expect(j.content).toMatch(/tool error/i);
  });

  it("404s unknown routes", async () => {
    expect((await fetch(`${base}/nope`)).status).toBe(404);
  });

  it("GET /api/instances includes the active instance", async () => {
    const j = await (await fetch(`${base}/api/instances`)).json();
    expect(j.current).toContain("mini-agentsfs");
    expect(j.instances.some((i: { name: string }) => i.name === "mini-agentsfs")).toBe(true);
  });

  it("POST /api/instance rejects a non-agentsfs path", async () => {
    const r = await fetch(`${base}/api/instance`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path: "/tmp" }),
    });
    expect(r.status).toBe(400);
  });

  it("POST /api/instance switches to a valid agentsfs", async () => {
    const r = await fetch(`${base}/api/instance`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path: FIXTURE }),
    });
    expect(r.status).toBe(200);
    const j = await r.json();
    expect(j.instanceName).toBe("mini-agentsfs");
  });
});
