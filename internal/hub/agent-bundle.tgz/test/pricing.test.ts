import { describe, expect, it } from "vitest";
import { estimateTextCostUsd, fmtUsd, priceFor } from "../src/pricing.js";

describe("pricing", () => {
  it("matches dated model snapshots by longest prefix", () => {
    expect(priceFor("gpt-5.1-2025-11-13")).toEqual(priceFor("gpt-5.1"));
    // mini must win over the shorter 'gpt-realtime' prefix
    expect(priceFor("gpt-realtime-mini")?.audioInPerM).toBe(10);
    expect(priceFor("gpt-realtime")?.audioInPerM).toBe(32);
  });

  it("returns undefined for unknown models", () => {
    expect(priceFor("totally-unknown")).toBeUndefined();
  });

  it("estimates text cost from token counts", () => {
    // gpt-4.1: $2/M in + $8/M out → 1M+1M = $10
    expect(estimateTextCostUsd("gpt-4.1", 1_000_000, 1_000_000)).toBeCloseTo(10);
    expect(estimateTextCostUsd("unknown-model", 1, 1)).toBeNull();
  });

  it("formats small and large USD figures", () => {
    expect(fmtUsd(0.0012)).toBe("$0.0012");
    expect(fmtUsd(1.5)).toBe("$1.500");
  });
});
