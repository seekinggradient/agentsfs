import { execFileSync } from "node:child_process";
import { describe, expect, it } from "vitest";
import { afsAvailable } from "../src/agentsfs/afs.js";
import { buildToolRegistry } from "../src/tools/registry.js";
import type { ToolContext } from "../src/tools/types.js";
import { detectCapabilities } from "../src/agentsfs/capabilities.js";
import { FIXTURE, makeConfig } from "./helpers.js";

const cfg = makeConfig();
const ctx: ToolContext = { cfg, caps: detectCapabilities(FIXTURE) };
const { byName } = buildToolRegistry(cfg);

// Build a full-text index for the fixture so search_wiki works (afs only).
const AFS_OK = await afsAvailable();
if (AFS_OK) {
  try {
    execFileSync("afs", ["reindex", FIXTURE], { stdio: "ignore" });
  } catch {
    /* ignore */
  }
}

const call = (name: string, args: Record<string, unknown> = {}) =>
  byName.get(name)!.handler(args, ctx);

describe("generic tools", () => {
  it("read_file returns content and citations (file + url)", async () => {
    const r = await call("read_file", { path: "notes/Apple.md" });
    expect(r.content).toContain("# Apple");
    expect(r.citations?.some((c) => c.path === "notes/Apple.md")).toBe(true);
    expect(r.citations?.some((c) => c.url?.includes("apple-facts"))).toBe(true);
  });

  it("read_file rejects path escapes", async () => {
    await expect(call("read_file", { path: "../../etc/passwd" })).rejects.toThrow();
  });

  it("grep finds matches", async () => {
    const r = await call("grep", { pattern: "potassium" });
    expect(r.content).toMatch(/Banana\.md:\d+/);
    expect(r.citations?.length).toBeGreaterThan(0);
  });

  it("list_dir shows directory descriptions", async () => {
    const r = await call("list_dir", { path: "." });
    expect(r.content).toMatch(/notes\//);
  });

  it("tree returns a map", async () => {
    const r = await call("tree", {});
    expect(typeof r.content).toBe("string");
  });
});

describe("structured (theses) tools", () => {
  it("are present because the fixture has a theses table", () => {
    expect(byName.has("list_theses")).toBe(true);
    expect(byName.has("get_thesis")).toBe(true);
  });

  it("list_theses lists and filters by stance", async () => {
    const all = await call("list_theses", {});
    expect(all.content).toMatch(/Buy FOO/);
    expect(all.content).toMatch(/Avoid BAR/);
    const buys = await call("list_theses", { stance: "buy" });
    expect(buys.content).toMatch(/Buy FOO/);
    expect(buys.content).not.toMatch(/Avoid BAR/);
  });

  it("get_thesis resolves by ticker and reads the file", async () => {
    const r = await call("get_thesis", { query: "FOO" });
    expect(r.content).toContain("# Buy FOO");
    expect(r.citations?.some((c) => c.path === "stocks/theses/Buy FOO.md")).toBe(true);
  });

  it("get_thesis falls back to the snapshot when the file is missing", async () => {
    const r = await call("get_thesis", { query: "thesis-avoid-bar-test" });
    expect(r.content).toMatch(/Avoid BAR/);
  });
});

describe.skipIf(!AFS_OK)("search_wiki (requires afs)", () => {
  it("finds a note by full-text", async () => {
    const r = await call("search_wiki", { query: "potassium", limit: 5 });
    expect(r.content).toMatch(/Banana\.md/);
    expect(r.citations?.length).toBeGreaterThan(0);
  });
});
