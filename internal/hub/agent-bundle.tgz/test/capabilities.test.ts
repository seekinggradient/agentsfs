import { describe, expect, it } from "vitest";
import { detectCapabilities } from "../src/agentsfs/capabilities.js";
import { FIXTURE } from "./helpers.js";

describe("detectCapabilities", () => {
  it("detects domains and the theses table", () => {
    const caps = detectCapabilities(FIXTURE);
    expect(caps.domains).toContain("notes");
    expect(caps.domains).toContain("stocks");
    expect(caps.thesesJsonPath).toBe("stocks/theses/history/current-theses.json");
    expect(caps.hasPortfolio).toBe(false);
    expect(caps.hasEducation).toBe(false);
  });
});
