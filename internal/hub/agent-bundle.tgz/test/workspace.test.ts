import type { AddressInfo } from "node:net";
import type { Server } from "node:http";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { Agent } from "../src/agent/session.js";
import { createApp, startServer } from "../src/server/server.js";
import { buildToolRegistry } from "../src/tools/registry.js";
import { detectCapabilities } from "../src/agentsfs/capabilities.js";
import type { ToolContext } from "../src/tools/types.js";
// @ts-expect-error - plain JS module
import { splitSSE } from "../src/web/lib.js";
import { makeConfig, makeWorkspaceConfig, ScriptedReasoner } from "./helpers.js";

describe("workspace mode — agent + tool wiring", () => {
  // T2.1
  it("boots unfocused; the system prompt lists the KBs and asks which to use", async () => {
    const cfg = makeWorkspaceConfig();
    const reasoner = new ScriptedReasoner([{ text: "Which knowledge base?" }]);
    const agent = await Agent.create(cfg, reasoner);
    expect(agent.instanceName).toBe("workspace"); // the workspace dir, not a KB
    await agent.ask({ message: "hi" });
    const sys = reasoner.calls[0]!.system;
    expect(sys).toContain("kb-alpha");
    expect(sys).toContain("kb-beta");
    expect(sys.toLowerCase()).toMatch(/which|ask/);
  });

  // T2.2
  it("list_repos lists both knowledge bases", async () => {
    const cfg = makeWorkspaceConfig();
    const ctx: ToolContext = {
      cfg,
      caps: detectCapabilities(cfg.agentsfsRoot),
      session: { root: cfg.agentsfsRoot },
    };
    const r = await buildToolRegistry(cfg).byName.get("list_repos")!.handler({}, ctx);
    expect(r.content).toContain("kb-alpha");
    expect(r.content).toContain("kb-beta");
  });

  // T2.3 — the focus_repo tool invokes the injected focus callback and confirms.
  it("focus_repo calls the focus callback and confirms", async () => {
    const focused: string[] = [];
    const reasoner = new ScriptedReasoner([
      { script: [{ name: "focus_repo", args: { repo: "kb-beta" } }], text: "Focusing." },
    ]);
    const agent = await Agent.create(makeWorkspaceConfig(), reasoner, {
      onFocusRepo: async (t) => {
        focused.push(t);
        return { name: t };
      },
    });
    await agent.ask({ message: "let's work in beta" });
    expect(focused).toEqual(["kb-beta"]);
    expect(reasoner.calls[0]!.toolResults[0]!).toMatch(/Focused on/i);
  });

  // T2.7 / T6.1 — tool set is gated by mode + flags; single mode is unchanged.
  it("gates tools by mode and flags", () => {
    const ws = buildToolRegistry(makeWorkspaceConfig()).byName; // workspace + shell + writes
    expect(ws.has("list_repos")).toBe(true);
    expect(ws.has("focus_repo")).toBe(true);
    expect(ws.has("run_bash")).toBe(true);
    expect(ws.has("write_file")).toBe(true);
    expect(ws.has("git_pull")).toBe(false); // subsumed by run_bash when the shell is on
    expect(ws.has("git_commit")).toBe(false);

    const single = buildToolRegistry(makeConfig()).byName; // single, no shell/writes
    expect(single.has("focus_repo")).toBe(false);
    expect(single.has("list_repos")).toBe(false);
    expect(single.has("run_bash")).toBe(false);
    expect(single.has("write_file")).toBe(false);
    expect(single.has("git_pull")).toBe(true); // present when there's no shell
    expect(single.has("git_status")).toBe(true);
  });
});

describe("cross-workspace (server) — start in one KB, ask in another", () => {
  let server: Server;
  let base: string;
  let reasoner: ScriptedReasoner;

  beforeAll(async () => {
    // Turn 0 reads a note that exists ONLY in kb-alpha; turn 1 reads one that
    // exists ONLY in kb-beta. If focus didn't actually switch the active root,
    // the second read would resolve against the wrong KB and miss.
    reasoner = new ScriptedReasoner([
      { script: [{ name: "read_file", args: { path: "notes/Zebra.md" } }], text: "Zebras have stripes." },
      { script: [{ name: "read_file", args: { path: "recipes/Pancakes.md" } }], text: "Pancakes are flat." },
    ]);
    const ctx = await createApp(makeWorkspaceConfig(), reasoner);
    server = await startServer(ctx, 0);
    base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  });
  afterAll(() => server?.close());

  const focus = (repo: string) =>
    fetch(`${base}/api/focus`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ repo }),
    });
  const chat = async (message: string) => {
    const r = await fetch(`${base}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
    const { frames } = splitSSE(await r.text());
    return JSON.parse(frames.find((f: { event: string }) => f.event === "done")!.data);
  };

  // T2.6 + first half of T2.5
  it("focus kb-alpha → reads the alpha-only note; prompt names alpha", async () => {
    const f = await focus("kb-alpha");
    expect(f.status).toBe(200);
    expect((await f.json()).instanceName).toBe("kb-alpha");
    const done = await chat("tell me about zebras");
    expect(done.text).toContain("Zebras");
    expect(done.citations.some((c: { path?: string }) => c.path === "notes/Zebra.md")).toBe(true);
    expect(reasoner.calls[0]!.system).toContain("kb-alpha");
  });

  // T2.5 — the marquee: switch workspaces mid-conversation.
  it("focus kb-beta → now reads the beta-only note; prompt names beta", async () => {
    const f = await focus("kb-beta");
    expect((await f.json()).instanceName).toBe("kb-beta");
    const done = await chat("how do I make pancakes");
    expect(done.citations.some((c: { path?: string }) => c.path === "recipes/Pancakes.md")).toBe(true);
    expect(reasoner.calls[1]!.system).toContain("kb-beta");
  });

  // T2.4
  it("rejects focusing an unknown repo", async () => {
    const r = await focus("does-not-exist");
    expect(r.status).toBe(400);
  });
});
