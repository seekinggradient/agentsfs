import { describe, expect, it, vi } from "vitest";
import { loadConfig } from "../src/config.js";
import { FIXTURE } from "./helpers.js";

// T4 — proxy mode: model calls route through the hub, so the sprite needs no
// OpenAI key. loadConfig reflects that.
describe("proxy mode config", () => {
  it("loads with NO OpenAI key; the key becomes the hub PAT", () => {
    vi.stubEnv("OPENAI_API_KEY", "");
    vi.stubEnv("ANTHROPIC_API_KEY", "");
    vi.stubEnv("AGENTSFS_LLM_BASE_URL", "https://hub.example/v1/agent-llm");
    vi.stubEnv("AGENTSFS_LLM_KEY", "afs_testpat");
    const cfg = loadConfig({ agentsfsRoot: FIXTURE });
    expect(cfg.provider).toBe("openai");
    expect(cfg.llmBaseUrl).toBe("https://hub.example/v1/agent-llm");
    expect(cfg.openaiApiKey).toBe("afs_testpat"); // the PAT, not a real key
    vi.unstubAllEnvs();
  });

  it("throws when there's no key and no proxy configured", () => {
    vi.stubEnv("OPENAI_API_KEY", "");
    vi.stubEnv("ANTHROPIC_API_KEY", "");
    vi.stubEnv("AGENTSFS_LLM_BASE_URL", "");
    expect(() => loadConfig({ agentsfsRoot: FIXTURE })).toThrow();
    vi.unstubAllEnvs();
  });
});
