import { dirname } from "node:path";
import { describe, expect, it } from "vitest";
import { discoverInstances, isAgentsfs } from "../src/agentsfs/discover.js";
import { FIXTURE } from "./helpers.js";

describe("isAgentsfs", () => {
  it("recognizes an agentsfs via the AGENTS.md marker", () => {
    expect(isAgentsfs(FIXTURE)).toBe(true);
  });
  it("rejects a non-agentsfs directory", () => {
    expect(isAgentsfs(dirname(FIXTURE))).toBe(false); // test/fixtures itself
  });
});

describe("discoverInstances", () => {
  it("finds the fixture instance under its parent directory", () => {
    const found = discoverInstances(dirname(FIXTURE), 2);
    const hit = found.find((i) => i.path === FIXTURE);
    expect(hit).toBeDefined();
    expect(hit?.name).toBe("mini-agentsfs");
  });
});
